export const environment = {
  production: true,
  envName: "Kochrezepte",
  version: "1.0.0",
  logo: '../assets/logo.png',
  test: false,
  success: "Der Prozess wurde erfolgreich durchgeführt",
  error:"Der Prozess wurde unerwartet beendet",

  sso: {
    issuer: 'https://vision.wurm.de:44126',
    //issuer: 'https://identity.wurm.de',
    redirectUri: window.location.origin,
    clientId : 'P3Tool',
    silentRefreshRedirectUri:window.location.origin + '/refresh.html',
    useSilentRefresh: true,
    dummyClientSecret: '9f140b56-7312-4b35-b703-3203959095ef',
    scope: 'openid profile email name offline_access',
    postLogoutRedirectUri: 'https://p3toolnightly.wurm.de',
    showDebugInformation: true,
    requireHttps: false,
    responseType: 'code',
    logoutUrl: 'https://p3toolnightly.wurm.de',
    silentRefreshTimeout: 2, // For faster testing
    //sessionChecksEnabled: true,
    timeoutFactor: 0.25,
    oidc: true
  }
};
