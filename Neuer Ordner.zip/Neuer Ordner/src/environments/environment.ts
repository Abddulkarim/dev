export const environment = {
  production: false,
  envName: "Kochrezepte",
  version:"1.0.0",
  logo: '../assets/logo.png',
  sso: {
    issuer: 'https://vision.wurm.de:44126',
    //issuer: 'https://identity.wurm.de',
    clientId : 'P3Tool',
    responseType: 'code',
    //redirectUri: window.location.origin,
    redirectUri: window.location.origin ,
    silentRefreshRedirectUri:window.location.origin + '/refresh.html',
    dummyClientSecret: '9f140b56-7312-4b35-b703-3203959095ef',
    scope: 'openid profile email name offline_access',
    postLogoutRedirectUri: 'http://localhost:4200',
    logoutUrl: 'http://localhost:4200/home',
    useSilentRefresh: true,// Needed for Code Flow to suggest using iframe-based refreshes
    silentRefreshTimeout: 5000, // For faster testing
    timeoutFactor: 0.25,// For faster testing
    silentRefreshShowIFrame: true,
    sessionChecksEnabled: true,
    showDebugInformation: true,
    clearHashAfterLogin: false,
    requireHttps: true,
    oidc: true
  }
};

