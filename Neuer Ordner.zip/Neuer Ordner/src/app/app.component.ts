import {Component,Inject,LOCALE_ID,OnInit,TemplateRef,ViewChild,} from '@angular/core';
import { environment as env } from '../environments/environment';
import { AuthService } from './services/auth.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  title = $localize`kochrezepte-p3-app`;
  isProd = env.production;
  envName = env.envName;
  version = env.version;
  year = new Date().getFullYear();
  logo = '../assets/logo.png';  
  @ViewChild('secondDialog', { static: true }) secondDialog: TemplateRef<any>;
  constructor(@Inject(LOCALE_ID) protected localeId: string,
    private authService: AuthService) {}
  ngOnInit(): void {
    this.authService.configure();
    // if (this.oauthService.events.pipe(filter(e => e.type === 'token_expires'))) {
    //   this.refreshTokenOnLoadIfNeeded();
    // }
  }
}
