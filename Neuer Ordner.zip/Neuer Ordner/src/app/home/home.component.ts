import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Evaluation, Warehouse, DataType, Resolution, Type, Unit } from '../models/entities';
import { CategoryService, DataTypeService, EvaluationService, ResolutionService, TypeService, UnitService, } from '../services/resource.service';

import * as DataTypesActions from '../store/actions/dataType.action';
import * as ResolutionsActions from '../store/actions/resolution.action';
import * as EvaluationActions from '../store/actions/evaluation.action';
import * as UnitsActions from '../store/actions/unit.action';
import * as CategoriesActions from '../store/actions/category.action';
import * as TypeActions from '../store/actions/type.action';
//import * as DeviceActions from '../store/actions/device.action';
import { OAuthService } from 'angular-oauth2-oidc';
import { NavigationEnd, Router } from '@angular/router';

@Component({
  selector: 'p3-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  constructor(
    private oauthService: OAuthService,

    private store: Store,
    private evaluationService: EvaluationService,
    private unitService: UnitService,
    private typeService: TypeService,
    private dataTypeService: DataTypeService,
    private resolutionService: ResolutionService,
    private categoryService: CategoryService,
    private router: Router
  ) { }

  ngOnInit() {
  }

  public loadData() {
    //Kagegorien
    this.categoryService.findAll().subscribe((data: Warehouse[]) => {
      this.store.dispatch(CategoriesActions.loadItemsAction({ payload: data }));
    });

    //Evaluationen
    this.evaluationService.findAll().subscribe((data: Evaluation[]) => {
      this.store.dispatch(EvaluationActions.loadItemsAction({ payload: data }));
    });

    //Einheiten
    this.unitService.findAll().subscribe((data: Unit[]) => {
      this.store.dispatch(UnitsActions.loadItemsAction({ payload: data }));
    });

    //Typen
    this.typeService.findAll().subscribe((data: Type[]) => {
      this.store.dispatch(TypeActions.loadItemsAction({ payload: data }));
    });

    //Datentype
    this.dataTypeService.findAll().subscribe((data: DataType[]) => {
      this.store.dispatch(DataTypesActions.loadItemsAction({ payload: data }));
    });

    //Auflösungen
    this.resolutionService.findAll().subscribe((data: Resolution[]) => {
      this.store.dispatch(ResolutionsActions.loadItemsAction({ payload: data }));
    });
  }
}
