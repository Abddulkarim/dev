import { AuthConfig } from 'angular-oauth2-oidc';
import { environment as en} from 'src/environments/environment';

export const authConfig: AuthConfig = {

  issuer: en.sso.issuer,
  redirectUri: en.sso.redirectUri,
  postLogoutRedirectUri: en.sso.postLogoutRedirectUri,
  // URL of the SPA to redirect the user after silent refresh
 // silentRefreshRedirectUri: en.sso.silentRefreshRedirectUri,
  useSilentRefresh: true,
  responseType:'code',
  // The SPA's id. The SPA is registerd with this id at the auth-server
  //clientId: 'implicit',
  clientId: en.sso.clientId,
  dummyClientSecret: en.sso.dummyClientSecret,
  silentRefreshRedirectUri:window.location.origin + 'src/refresh.html',
  // set the scope for the permissions the client should request
  // The first three are defined by OIDC. The 4th is a usecase-specific one
  scope:  en.sso.scope,
  //silentRefreshShowIFrame: true,
  showDebugInformation: true,
 //sessionChecksEnabled: true,
  timeoutFactor: 0.25,
  silentRefreshTimeout: 2, // For faster testing
  logoutUrl:en.sso.logoutUrl,
  clearHashAfterLogin: false,
  oidc: true
}