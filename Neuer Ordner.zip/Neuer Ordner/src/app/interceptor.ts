import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, throwError } from 'rxjs';
import { AuthService } from './services/auth.service';
import { Store } from '@ngrx/store';
import { WebLanguageService } from './services/webLanguageService';
import { Router } from '@angular/router';

@Injectable()
export class P3Interceptor implements HttpInterceptor {
    constructor(private authService: AuthService, private router: Router, private store: Store, private webLanguageService: WebLanguageService,) { }
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        //request = request.clone({ headers: request.headers.set('Content-Type', 'application/json') });
        if (this.authService.isLoggedIn()) {
            request = request.clone({ setHeaders: { Authorization: `Bearer ${this.authService.getAccessToken()}`, }, });
        }
        if (!request.headers.has('Accept')) {
            request = request.clone({ headers: request.headers.set('Accept', 'application/json') });
        }
        const webLanguage = this.webLanguageService.getLanguage("en");
        request = request.clone({ headers: request.headers.set('Accept-Language', webLanguage) });
        //return next.handle(request);
        return next.handle(request).pipe(
            catchError((error) => {
              if (error.status === 401) {
                const url = localStorage.getItem('return-url')
                this.authService.tryLogin(url)
                if (url) this.router.navigateByUrl(url)
              }
              return throwError(() => new Error(error.error));
            })
          );

    }

}