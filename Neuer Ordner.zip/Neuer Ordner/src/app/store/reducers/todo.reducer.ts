import { UnitActions, UnitActionTypes } from "../actions/todo.action";

export interface ToDo {
  userId: number,
  id: number,
  title: string,
  completed: boolean;
}


export interface TodosState {
    units: ToDo[];
} 

const initialUnitsState: TodosState = {
    units: [],
}

export function unitReducer(state = initialUnitsState, action: UnitActions) {
    switch (action.type) {
  
      case UnitActionTypes.AddAction:
        return {
            units: action.payload
        };
  
      case UnitActionTypes.DeleteAction:
          return {
            units: []
          };
  
      default:
        return state;
    }
  }
  