import { createReducer, on } from '@ngrx/store';
import { EvaluationVersion } from 'src/app/models/entities';
import * as  EvaluationVersionActions from '../actions/evaluationVersion.action';


export interface EvaluationVersionsState {
  dataList: EvaluationVersion[];
}

const initialState: EvaluationVersionsState = {
  dataList: [],
};

export const evaluationVersionReducer = createReducer(
  initialState,
  on(EvaluationVersionActions.AddItemsAction, (state, action) => ({dataList: action.payload,})),
  on(EvaluationVersionActions.addItemAction, (state, action) => ({dataList: [action.payload,...state.dataList],})),
  on(EvaluationVersionActions.updateItemAction, (state, action) => {
    return {
      ...state,
      dataList: state.dataList.map((data) =>
        action.payload.index === data.index ? action.payload : data
      ),
    };
  }),
  on(EvaluationVersionActions.deleteItemAction, (state, action) => {
    return {
      ...state,
      dataList: state.dataList.filter(
        (data) => data.index !== action.payload.index
      ),
    };
  }),
  on(EvaluationVersionActions.removeItemsAction, () => initialState)
);