import { createReducer, on } from '@ngrx/store';
import * as DataActions from '../actions/data.action';

export interface DataState {
  data: any
}

export const initialState: DataState = {
  data: undefined
};


export const dataReducer = createReducer(
  initialState,
  on(DataActions.DataAddAction, (state, action) => {
    return {
      data: action.payload
    };
  }),
  on(DataActions.DataDelecteAction, () => initialState) 
);
