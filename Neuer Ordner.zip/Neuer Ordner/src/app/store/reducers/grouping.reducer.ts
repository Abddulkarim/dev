import { createReducer, on } from '@ngrx/store';
import * as GroupingActions  from '../actions/grouping.action';

export interface GroupingState {
  dataList: string[];
}

const initialState: GroupingState = {
  dataList: [],
};

export const groupingReducer = createReducer(
  initialState,
  on(GroupingActions.loadItemsAction, (state, action) => ({dataList: action.payload,})),
  on(GroupingActions.addItemAction, (state, action) => ({dataList: [...state.dataList, action.payload],})),
  on(GroupingActions.updateItemAction, (state, action) => {
    return {
      ...state,
      dataList: state.dataList.map((data) =>
        action.payload === data? action.payload : data
      ),
    };
  }),
  on(GroupingActions.deleteItemAction, (state, action) => {
    return {
      ...state,
      dataList: state.dataList.filter(
        (data) => data !== action.payload
      ),
    };
  }),
  on(GroupingActions.removeItemsAction, () => initialState)
);