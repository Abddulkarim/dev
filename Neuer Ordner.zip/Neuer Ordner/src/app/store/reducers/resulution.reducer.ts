import { createReducer, on } from '@ngrx/store';
import { Resolution } from 'src/app/models/entities';
import * as ResolutionActions  from '../actions/resolution.action';


export interface ResolutionsState {
  dataList: Resolution[];
}

const initialState: ResolutionsState = {
  dataList: [],
};

export const resolutionReducer = createReducer(
  initialState,
  on(ResolutionActions.loadItemsAction, (state, action) => ({dataList: action.payload,})),
  on(ResolutionActions.addItemAction, (state, action) => ({dataList: [...state.dataList, action.payload],})),
  on(ResolutionActions.updateItemAction, (state, action) => {
    return {
      ...state,
      dataList: state.dataList.map((data) =>
        action.payload.index === data.index ? action.payload : data
      ),
    };
  }),
  on(ResolutionActions.deleteItemAction, (state, action) => {
    return {
      ...state,
      dataList: state.dataList.filter(
        (data) => data.index !== action.payload.index
      ),
    };
  }),
  on(ResolutionActions.removeItemsAction, () => initialState)
);
// export function resolutionReducer(state = initialResolutionsState, action: ResolutionActions) {
//   switch (action.type) {
//     case ResolutionActionTypes.AddItemsAction:
//       return {
//         dataList: action.payload,
//       };

//     case ResolutionActionTypes.AddItemAction:
//       return Object.assign({}, state, {
//         dataList: [...state.dataList, action.payload],
//       });

//     case ResolutionActionTypes.UpdateItemAction:
//       return Object.assign({}, state, {
//         dataList: state.dataList.map((data) => {
//           if (data.index === action.payload.index) {
//             return Object.assign({}, action.payload, {});
//           }
//           return data;
//         }),
//       });

//     case ResolutionActionTypes.DeleteItemAction:
//       return  {
//         ...state,
//         dataList: state.dataList.filter(data=>data.index!==action.payload.index),
//       };

//     case ResolutionActionTypes.ClearItemsAction:
//       return {
//         dataList: [],
//       };

//     default:
//       return state;
//   }
// }