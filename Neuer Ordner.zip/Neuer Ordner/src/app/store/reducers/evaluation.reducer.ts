import { createReducer, on } from '@ngrx/store';
import { Evaluation } from 'src/app/models/entities';
import  * as EvaluationActions  from '../actions/evaluation.action';


export interface EvaluationsState {
  dataList: Evaluation[];
}

const initialState: EvaluationsState = {
  dataList: [],
};
export const evaluationReducer = createReducer(
  initialState,
  on(EvaluationActions.loadItemsAction, (state, action) => ({dataList: action.payload,})),
  on(EvaluationActions.addItemAction, (state, action) => ({dataList: [action.payload,...state.dataList],})),
  on(EvaluationActions.updateItemAction, (state, action) => {
    return {
      ...state,
      dataList: state.dataList.map((data) =>
        action.payload.index === data.index ? action.payload : data
      ),
    };
  }),
  on(EvaluationActions.deleteItemAction, (state, action) => {
    return {
      ...state,
      dataList: state.dataList.filter(
        (data) => data.index !== action.payload.index
      ),
    };
  }),
  on(EvaluationActions.removeItemsAction, () => initialState)
);
// export function evaluationReducer(state = initialEvaluationsState, action: EvaluationActions) {
//   switch (action.type) {
//     case EvaluationActionTypes.AddItemsAction:
//       return {
//         evaluations: action.payload,
//       };

//     case EvaluationActionTypes.AddItemAction:
//       return Object.assign({}, state, {
//         evaluations: [...state.evaluations, action.payload],
//       });

//     case EvaluationActionTypes.UpdateItemAction:
//       return Object.assign({}, state, {
//         evaluations: state.evaluations.map((evaluation) => {
//           if (evaluation.index === action.payload.index) {
//             return Object.assign({}, action.payload, {});
//           }
//           return evaluation;
//         }),
//       });
//     case EvaluationActionTypes.DeleteItemAction:
//       return  {
//         ...state,
//         evaluations: state.evaluations.filter(evaluation=>evaluation.index!==action.payload.index),
//       }
//     case EvaluationActionTypes.ClearAllAction:
//       return {
//         evaluations: [],
//       };

//     default:
//       return state;
//   }
// }