import { createReducer, on } from '@ngrx/store';
import * as LanguageActions from '../actions/language.action';

export interface Language {
  code: string;
}

let initialState = {
  code: navigator.language,
};

export const languageReducer = createReducer(
  initialState,
  on(LanguageActions.addLanguageAction, (state, action) => {
    return {
      ...state,
      code: action.payload,
    };
  }),
  on(LanguageActions.defaultLaguageAction, () => initialState)
);