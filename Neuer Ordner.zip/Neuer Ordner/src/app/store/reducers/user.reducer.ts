import { Action, createReducer, on } from '@ngrx/store';
import { User } from 'src/app/models/entities';
import * as AuthActions from '../actions/user.action';

export interface AuthState {
  loggedIn: boolean,
  user: User
}

export const initialState: AuthState = {
  loggedIn: false,
  user: undefined
};


export const userReducer = createReducer(
  initialState,
  on(AuthActions.LoginAction, (state, action) => {
    return {
      loggedIn: true,
      user: action.payload
    };
  }),
  on(AuthActions.LogoutAction, () => initialState)
);
