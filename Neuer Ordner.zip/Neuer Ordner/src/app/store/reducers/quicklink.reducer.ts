import { createReducer, on } from '@ngrx/store';
import { Device, Quicklink } from 'src/app/models/entities';
import * as QuicklinkActions from '../actions/quicklink.actions';


export interface QuicklinksState {
  dataList: Quicklink[];
}

const initialState: QuicklinksState = {
  dataList: [],
};

export const quicklinkReducer = createReducer(
  initialState,
  on(QuicklinkActions.loadItemsAction, (state, action) => ({dataList: action.payload,})),
  on(QuicklinkActions.removeItemsAction, () => initialState)
);