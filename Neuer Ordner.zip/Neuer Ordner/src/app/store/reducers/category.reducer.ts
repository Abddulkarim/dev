import { createReducer, on } from '@ngrx/store';
import { Warehouse } from 'src/app/models/entities';
import * as CategoryActions from '../actions/category.action';


export interface CategoriesState {
  dataList: Warehouse[];
}

const initialState: CategoriesState = {
  dataList: [],
};

export const categoryReducer = createReducer(
  initialState,
  on(CategoryActions.loadItemsAction, (state, action) => ({dataList: action.payload,})),
  on(CategoryActions.addItemAction, (state, action) => ({dataList: [action.payload,...state.dataList],})),
  on(CategoryActions.updateItemAction, (state, action) => {
    return {
      ...state,
      dataList: state.dataList.map((data) =>
        action.payload.index === data.index ? action.payload : data
      ),
    };
  }),
  on(CategoryActions.deleteItemAction, (state, action) => {
    return {
      ...state,
      dataList: state.dataList.filter(
        (data) => data.index !== action.payload.index
      ),
    };
  }),
  on(CategoryActions.removeItemsAction, () => initialState)
);

// export function categoryReducer(state = initialCategoriesState, action: CategoryActions) {
//   switch (action.type) {
//     case CategoryActionTypes.AddItemsAction:
//       return {
//         dataList: action.payload,
//       };

//     case CategoryActionTypes.AddItemAction:
//       return Object.assign({}, state, {
//         dataList: [...state.dataList, action.payload],
//       });

//     case CategoryActionTypes.UpdateItemAction:
//       return Object.assign({}, state, {
//         dataList: state.dataList.map((data) => {
//           if (data.index === action.payload.index) {
//             return Object.assign({}, action.payload, {});
//           }
//           return data;
//         }),
//       });
//     case CategoryActionTypes.DeleteItemAction:
//       return  {
//         ...state,
//         dataList: state.dataList.filter(data=>data.index!==action.payload.index),
//       };
//     case CategoryActionTypes.ClearItemsAction:
//       return {
//         dataList: [],
//       };

//     default:
//       return state;
//   }
// }