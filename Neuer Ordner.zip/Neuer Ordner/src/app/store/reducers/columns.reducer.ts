import { createReducer, on } from '@ngrx/store';
import * as ColumnsActions  from '../actions/columns.action';

export interface ColumnsState {
  dataList: string[];
}

const initialState: ColumnsState = {
  dataList: [],
};

export const columnsReducer = createReducer(
  initialState,
  on(ColumnsActions.loadItemsAction, (state, action) => ({dataList: action.payload,})),
  on(ColumnsActions.addItemAction, (state, action) => ({dataList: [...state.dataList, action.payload],})),
  on(ColumnsActions.updateItemAction, (state, action) => {
    return {
      ...state,
      dataList: state.dataList.map((data) =>
        action.payload === data? action.payload : data
      ),
    };
  }),
  on(ColumnsActions.deleteItemAction, (state, action) => {
    return {
      ...state,
      dataList: state.dataList.filter(
        (data) => data !== action.payload
      ),
    };
  }),
  on(ColumnsActions.removeItemsAction, () => initialState)
);