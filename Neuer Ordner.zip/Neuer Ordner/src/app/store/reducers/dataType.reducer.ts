import { createReducer, on } from '@ngrx/store';
import { DataType } from 'src/app/models/entities';
import * as DataTypeActions  from '../actions/dataType.action';

export interface DataTypesState {
  dataList: DataType[];
}

const initialState: DataTypesState = {
  dataList: [],
};

export const dataTypeReducer = createReducer(
  initialState,
  on(DataTypeActions.loadItemsAction, (state, action) => ({dataList: action.payload,})),
  on(DataTypeActions.addItemAction, (state, action) => ({dataList: [...state.dataList, action.payload],})),
  on(DataTypeActions.updateItemAction, (state, action) => {
    return {
      ...state,
      dataList: state.dataList.map((data) =>
        action.payload.index === data.index ? action.payload : data
      ),
    };
  }),
  on(DataTypeActions.deleteItemAction, (state, action) => {
    return {
      ...state,
      dataList: state.dataList.filter(
        (data) => data.index !== action.payload.index
      ),
    };
  }),
  on(DataTypeActions.removeItemsAction, () => initialState)
);
