import * as CounterActions from '../actions/counter.actions';
import { on, createReducer } from '@ngrx/store';
import { User } from 'src/app/models/entities';

export const counterFeatureKey = 'counter';

export interface CounterState {
  user: User;
}

export const initialState: CounterState = {
  user: null
};

export const counterReducer = createReducer(
  initialState,
  on(CounterActions.increment, (state,action) => ({ user:  action.user})),
  on(CounterActions.decrement, (state,action) => ({ user: null })),
  on(CounterActions.reset, () => initialState),
);