import { Type } from 'src/app/models/entities';
import * as TypeActions from '../actions/type.action';
import { on, createReducer } from '@ngrx/store';

export interface TypesState {
  dataList: Type[];
}

const initialState: TypesState = {
  dataList: [],
};

export const typeReducer = createReducer(
  initialState,
  on(TypeActions.loadItemsAction, (state, action) => ({dataList: action.payload,})),
  on(TypeActions.addItemAction, (state, action) => ({dataList: [...state.dataList, action.payload],})),
  on(TypeActions.updateItemAction, (state, action) => {
    return {
      ...state,
      dataList: state.dataList.map((data) =>
        action.payload.index === data.index ? action.payload : data
      ),
    };
  }),
  on(TypeActions.deleteItemAction, (state, action) => {
    return {
      ...state,
      dataList: state.dataList.filter(
        (data) => data.index !== action.payload.index
      ),
    };
  }),
  on(TypeActions.removeItemsAction, () => initialState)
);
// export function typeReducer1(state = initialTypesState, action: TypeActions) {
//   switch (action.type) {
//     case TypeActionTypes.AddItemsAction:
//       return {
//         dataList: action.payload,
//       };

//     case TypeActionTypes.AddItemAction:
//       return Object.assign({}, state, {
//         dataList: [...state.dataList, action.payload],
//       });

//     case TypeActionTypes.UpdateItemAction:
//       return Object.assign({}, state, {
//         dataList: state.dataList.map((data) => {
//           if (data.index === action.payload.index) {
//             return Object.assign({}, action.payload, {});
//           }
//           return data;
//         }),
//       });
//     case TypeActionTypes.DeleteItemAction:
//       return {
//         ...state,
//         dataList: state.dataList.filter(
//           (data) => data.index !== action.payload.index
//         ),
//       };
//     case TypeActionTypes.ClearItemsAction:
//       return {
//         dataList: [],
//       };

//     default:
//       return state;
//   }
// }
