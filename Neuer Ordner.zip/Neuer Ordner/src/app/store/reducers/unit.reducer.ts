import { createReducer, on } from '@ngrx/store';
import { Unit } from 'src/app/models/entities';
import * as UnitActions  from '../actions/unit.action';

export interface UnitsState {
  dataList: Unit[];
}

const initialState: UnitsState = {
  dataList: [],
};

export const unitReducer = createReducer(
  initialState,
  on(UnitActions.loadItemsAction, (state, action) => ({dataList: action.payload,})),
  on(UnitActions.addItemAction, (state, action) => ({dataList: [...state.dataList, action.payload],})),
  on(UnitActions.updateItemAction, (state, action) => {
    return {
      ...state,
      dataList: state.dataList.map((data) =>
        action.payload.index === data.index ? action.payload : data
      ),
    };
  }),
  on(UnitActions.deleteItemAction, (state, action) => {
    return {
      ...state,
      dataList: state.dataList.filter(
        (data) => data.index !== action.payload.index
      ),
    };
  }),
  on(UnitActions.removeItemsAction, () => initialState)
);

// export function unitReducer(state = initialUnitsState, action: UnitActions) {
//   switch (action.type) {
//     case UnitActionTypes.AddUnitListAction:
//       return {
//         units: action.payload,
//       };

//     case UnitActionTypes.AddItemAction:
//       return Object.assign({}, state, {
//         units: [...state.units, action.payload],
//       });

//     case UnitActionTypes.UpdateItemAction:
//       return Object.assign({}, state, {
//         units: state.units.map((unitItem) => {
//           if (unitItem.index === action.payload.index) {
//             return Object.assign({}, action.payload, {});
//           }
//           return unitItem;
//         }),
//       });
//     case UnitActionTypes.DeleteAction:
//       return  {
//         ...state,
//         units: state.units.filter(unit=>unit.index!==action.payload.index),
//       }
//     case UnitActionTypes.ClearAction:
//       return {
//         units: [],
//       };

//     default:
//       return state;
//   }
// }