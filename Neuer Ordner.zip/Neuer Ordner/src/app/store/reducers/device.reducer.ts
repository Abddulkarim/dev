import { createReducer, on } from '@ngrx/store';
import { Device } from 'src/app/models/entities';
import * as DeviceActions from '../actions/device.action';


export interface DevicesState {
  dataList: Device[];
}

const initialState: DevicesState = {
  dataList: [],
};

export const deviceReducer = createReducer(
  initialState,
  on(DeviceActions.loadItemsAction, (state, action) => ({dataList: action.payload,})),
  on(DeviceActions.removeItemsAction, () => initialState)
);