import { Action, ActionReducer, ActionReducerMap, INIT, UPDATE } from "@ngrx/store";
import { dataTypeReducer, DataTypesState } from "../store/reducers/dataType.reducer";
import { CategoriesState, categoryReducer } from "./reducers/category.reducer";
import { counterReducer, CounterState } from "./reducers/counter.reducer";
import { dataReducer, DataState } from "./reducers/data.reducer";
import { deviceReducer, DevicesState } from "./reducers/device.reducer";
import { evaluationReducer, EvaluationsState } from "./reducers/evaluation.reducer";
import { evaluationVersionReducer, EvaluationVersionsState } from "./reducers/evaluationVersion.reducer";

import { Language, languageReducer } from "./reducers/language.reducer";
import { quicklinkReducer, QuicklinksState } from "./reducers/quicklink.reducer";
import { resolutionReducer, ResolutionsState } from "./reducers/resulution.reducer";
import { typeReducer, TypesState } from "./reducers/type.reducer";
import { unitReducer, UnitsState } from "./reducers/unit.reducer";

import { userReducer, AuthState } from "./reducers/user.reducer";
import { ColumnsState, columnsReducer } from "./reducers/columns.reducer";
import { GroupingState, groupingReducer } from "./reducers/grouping.reducer";

export interface StoreInterface {
    language: Language;
    authState:AuthState;
    categoriesState:CategoriesState,
    columnsState:ColumnsState,
    groupingState:GroupingState,
    evaluationsState:EvaluationsState,
    evaluationVersionsState:EvaluationVersionsState,
    devicesState:DevicesState,
    typesState:TypesState,
    dataTypesState:DataTypesState,
    resolutionsState:ResolutionsState,
    unitsState:UnitsState,
    counterState:CounterState,
    quicklinksState:QuicklinksState,
    dataState:DataState
}

export interface CustomAction extends Action{
    payload: string,
}

export const reducers:ActionReducerMap<StoreInterface,any>={
  language:languageReducer,
  authState:userReducer,
  categoriesState:categoryReducer,
  columnsState:columnsReducer,
  groupingState:groupingReducer,
  evaluationsState:evaluationReducer,
  evaluationVersionsState:evaluationVersionReducer,
  devicesState:deviceReducer,
  typesState:typeReducer,
  dataTypesState:dataTypeReducer,
  resolutionsState:resolutionReducer,
  unitsState:unitReducer,
  counterState:counterReducer,
  quicklinksState:quicklinkReducer,
  dataState:dataReducer
}


export const metaReducerLocalStorage = (reducer: ActionReducer<any>): ActionReducer<any> => {
    return (state, action) => {
      if (action.type === INIT || action.type == UPDATE) {
        const storageValue = localStorage.getItem("state2");
        if (storageValue) {
          try {
            return JSON.parse(storageValue);
          } catch {
            localStorage.removeItem("state2");
          }
        }
      }
      const nextState = reducer(state, action);
      localStorage.setItem("state2", JSON.stringify(nextState));
      return nextState;
    };
  };