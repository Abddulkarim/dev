import { createAction, props } from "@ngrx/store";

export const loadItemsAction =createAction('[Columns] Load Items',props<{payload:string[]}>());
export const addItemAction =createAction('[Columns] add Item',props<{payload:string}>());
export const updateItemAction = createAction('[Columns] Update Item', props<{payload: string}>());
export const deleteItemAction = createAction('[Columns] Delete Item', props<{payload: string}>());
export const removeItemsAction = createAction('[Columns] Remove Items');