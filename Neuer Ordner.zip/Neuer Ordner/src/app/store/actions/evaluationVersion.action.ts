import { createAction, props } from '@ngrx/store';
import { EvaluationVersion } from 'src/app/models/entities';

export const AddItemsAction = createAction('[EvaluationVersion] Add Items', props<{payload: EvaluationVersion[]}>());
export const addItemAction = createAction('[EvaluationVersion] add Item', props<{payload: EvaluationVersion}>());
export const updateItemAction = createAction('[EvaluationVersion] update Item', props<{payload: EvaluationVersion}>());
export const deleteItemAction = createAction('[EvaluationVersion] delete Item', props<{payload: EvaluationVersion}>())
export const removeItemsAction = createAction('[EvaluationVersion] Remove ITems');

