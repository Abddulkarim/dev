import { Action } from "@ngrx/store";
import { ToDo } from "../reducers/todo.reducer";


export enum UnitActionTypes {
  LOADAction = '[Unit] load',
  AddAction = '[Unit] add',
  DeleteAction = '[Unit] delete',
  FaildAction = '[Unit] failed',
}

export class LoadUnitAction {
  type: string = UnitActionTypes.LOADAction;
}

export class SuccessUnitAction implements Action {

  readonly type = UnitActionTypes.AddAction;
  payload: ToDo[];

  constructor( payload: ToDo[] ) {
    this.payload=payload;
  }
}

export class FaildUnitAction implements Action {

  readonly type = UnitActionTypes.FaildAction;
  payload: any;
  constructor(payload: any) {
    this.payload=payload;
  }
}


export class UnitDeleteAction implements Action {

  readonly type = UnitActionTypes.DeleteAction;
}


export type UnitActions = SuccessUnitAction | UnitDeleteAction;