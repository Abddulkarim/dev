import { createAction, props } from '@ngrx/store';
import { Type } from 'src/app/models/entities';


export const loadItemsAction = createAction('[Type] Load Items', props<{payload: Type[]}>());
export const addItemAction = createAction('[Type] add Item', props<{payload: Type}>());
export const updateItemAction = createAction('[Type] update Item', props<{payload: Type}>());
export const deleteItemAction = createAction('[Type] delete Item', props<{payload: Type}>())
export const removeItemsAction = createAction('[Type] Remove ITems');

// export enum TypeActionTypes {
//   AddItemsAction = '[Type] List add',
//   AddItemAction = '[Type] add',
//   UpdateItemAction = '[Type] update',
//   DeleteItemAction = '[Type] delete',
//   ClearItemsAction = '[Type] clear all',
// }
// export class AddTypesAction implements Action {
//   readonly type = TypeActionTypes.AddItemsAction;
//   payload: Type[];

//   constructor(payload: Type[]) {
//     this.payload = payload;
//   }
// }

// export class AddTypeAction implements Action {
//   readonly type = TypeActionTypes.AddItemAction;
//   payload: Type;

//   constructor(payload: Type) {
//     this.payload = payload;
//   }
// }
// export class UpdateTypeAction implements Action {
//   readonly type = TypeActionTypes.UpdateItemAction;
//   payload: Type;

//   constructor(payload: Type) {
//     this.payload = payload;
//   }
// }

// export class DeleteTypeAction implements Action {
//   readonly type = TypeActionTypes.DeleteItemAction;
//   payload: Type;

//   constructor(payload: Type) {
//     this.payload = payload;
//   }
// }

// export class ClearTypeseAction implements Action {
//   readonly type = TypeActionTypes.ClearItemsAction;
// }

// export type TypeActions=
//   | AddTypesAction
//   | AddTypeAction
//   | UpdateTypeAction
//   | DeleteTypeAction
//   | ClearTypeseAction
