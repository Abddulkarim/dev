import { Action, createAction, props } from '@ngrx/store';
import { User } from 'src/app/models/entities';

export const increment = createAction('[Counter Component] Increment', props<{user: User}>());
export const decrement = createAction('[Counter Component] Decrement');
export const reset = createAction('[Counter Component] Reset')


// export class IncrementAction implements Action {

//     readonly type:string=decrement().type;
//     payload: number;
//     constructor( payload: number) {
//       this.payload=payload;
//     }
//   }
//   export class DecrementAction implements Action {

//     readonly type:string=increment().type;
//     payload: number;
//     constructor( payload: number) {
//       this.payload=payload;
//     }
//   }

//   export type MyCounterActions=
//   IncrementAction
//   | DecrementAction