import { createAction, props } from "@ngrx/store";

export const addLanguageAction = createAction('[Language] Add', props<{payload: string}>());
export const defaultLaguageAction = createAction('[Language] Default');