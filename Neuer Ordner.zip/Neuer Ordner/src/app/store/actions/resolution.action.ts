import { createAction, props } from '@ngrx/store';
import { Resolution } from 'src/app/models/entities';

export const loadItemsAction = createAction('[Resolution] Load Items', props<{payload: Resolution[]}>());
export const addItemAction = createAction('[Resolution] add Item', props<{payload: Resolution}>());
export const updateItemAction = createAction('[Resolution] update Item', props<{payload: Resolution}>());
export const deleteItemAction = createAction('[Resolution] delete Item', props<{payload: Resolution}>())
export const removeItemsAction = createAction('[Resolution] Remove ITems');