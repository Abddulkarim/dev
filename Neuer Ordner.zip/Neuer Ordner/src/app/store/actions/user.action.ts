import { Action, createAction, props } from '@ngrx/store';
import { User } from 'src/app/models/entities';

export const LoginAction =createAction('[User] add Item',props<{payload:User}>());
export const LogoutAction = createAction('[User] Remove Items');
