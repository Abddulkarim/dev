import { createAction, props } from '@ngrx/store';
import { DataType } from 'src/app/models/entities';

export const loadItemsAction = createAction('[DataType] Load Items', props<{payload: DataType[]}>());
export const addItemAction = createAction('[DataType] add Item', props<{payload: DataType}>());
export const updateItemAction = createAction('[DataType] update Item', props<{payload: DataType}>());
export const deleteItemAction = createAction('[DataType] delete Item', props<{payload: DataType}>())
export const removeItemsAction = createAction('[DataType] Remove ITems');
