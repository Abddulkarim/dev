import { createAction, props } from "@ngrx/store";

export const loadItemsAction =createAction('[Grouping] Load Items',props<{payload:string[]}>());
export const addItemAction =createAction('[Grouping] add Item',props<{payload:string}>());
export const updateItemAction = createAction('[Grouping] Update Item', props<{payload: string}>());
export const deleteItemAction = createAction('[Grouping] Delete Item', props<{payload: string}>());
export const removeItemsAction = createAction('[Grouping] Remove Items');