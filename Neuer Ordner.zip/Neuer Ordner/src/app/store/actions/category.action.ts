import { Action, createAction, props } from '@ngrx/store';
import { Warehouse } from 'src/app/models/entities';

export const loadItemsAction =createAction('[Category] Load Items',props<{payload:Warehouse[]}>());
export const addItemAction =createAction('[Category] add Item',props<{payload:Warehouse}>());
export const updateItemAction = createAction('[Category] Update Item', props<{payload: Warehouse}>());
export const deleteItemAction = createAction('[Category] Delete Item', props<{payload: Warehouse}>());
export const removeItemsAction = createAction('[Category] Remove Items');

// export enum CategoryActionTypes {
//   AddItemsAction = '[Category] List add',
//   AddItemAction = '[Category] add',
//   UpdateItemAction = '[Category] update',
//   DeleteItemAction = '[Category] delete',
//   ClearItemsAction = '[Category] clear all',
// }
// export class AddCategoriesAction implements Action {
//   readonly type = CategoryActionTypes.AddItemsAction;
//   payload: Category[];

//   constructor(payload: Category[]) {
//     this.payload = payload;
//   }
// }

// export class AddCategoryAction implements Action {
//   readonly type = CategoryActionTypes.AddItemAction;
//   payload: Category;

//   constructor(payload: Category) {
//     this.payload = payload;
//   }
// }
// export class UpdateCategoryAction implements Action {
//   readonly type = CategoryActionTypes.UpdateItemAction;
//   payload: Category;

//   constructor(payload: Category) {
//     this.payload = payload;
//   }
// }

// export class DeleteCategoryAction implements Action {
//   readonly type = CategoryActionTypes.DeleteItemAction;
//   payload: Category;

//   constructor(payload: Category) {
//     this.payload = payload;
//   }
// }

// export class ClearCategorieseAction implements Action {
//   readonly type = CategoryActionTypes.ClearItemsAction;
// }

// export type CategoryActions=
//   | AddCategoriesAction
//   | AddCategoryAction
//   | UpdateCategoryAction
//   | DeleteCategoryAction
//   | ClearCategorieseAction
