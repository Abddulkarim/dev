import {createAction, props } from '@ngrx/store';

export const DataAddAction =createAction('[Data] add Item',props<{payload:any}>());
export const DataDelecteAction = createAction('[Data] Remove Item');
