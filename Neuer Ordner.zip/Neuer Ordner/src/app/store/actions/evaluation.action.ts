import { createAction, props } from '@ngrx/store';
import { Evaluation } from 'src/app/models/entities';

export const loadItemsAction = createAction('[Evaluation] Load Items', props<{payload: Evaluation[]}>());
export const addItemAction = createAction('[Evaluation] add Item', props<{payload: Evaluation}>());
export const updateItemAction = createAction('[Evaluation] update Item', props<{payload: Evaluation}>());
export const deleteItemAction = createAction('[Evaluation] delete Item', props<{payload: Evaluation}>())
export const removeItemsAction = createAction('[Evaluation] Remove ITems');

// export enum EvaluationActionTypes {
//   AddItemsAction = '[Evaluation] List add',
//   AddItemAction = '[Evaluation] add',
//   UpdateItemAction = '[Evaluation] update',
//   DeleteItemAction = '[Evaluation] delete',
//   ClearAllAction = '[Evaluation] clear all',
// }

// export class AddEvaluationsAction implements Action {
//   readonly type = EvaluationActionTypes.AddItemsAction;
//   payload: Evaluation[];

//   constructor(payload: Evaluation[]) {
//     this.payload = payload;
//   }
// }

// export class AddEvaluationAction implements Action {
//   readonly type = EvaluationActionTypes.AddItemAction;
//   payload: Evaluation;

//   constructor(payload: Evaluation) {
//     this.payload = payload;
//   }
// }
// export class UpdateEvaluationAction implements Action {
//   readonly type = EvaluationActionTypes.UpdateItemAction;
//   payload: Evaluation;

//   constructor(payload: Evaluation) {
//     this.payload = payload;
//   }
// }

// export class DeleteEvaluationAction implements Action {
//   readonly type = EvaluationActionTypes.DeleteItemAction;
//   payload: Evaluation;

//   constructor(payload: Evaluation) {
//     this.payload = payload;
//   }
// }

// export class ClearEvaluationsAction implements Action {
//   readonly type = EvaluationActionTypes.ClearAllAction;
// }

// export type EvaluationActions =
//   | AddEvaluationsAction
//   | AddEvaluationAction
//   | UpdateEvaluationAction
//   | DeleteEvaluationAction
//   | ClearEvaluationsAction;
