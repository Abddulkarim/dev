import { createAction, props } from '@ngrx/store';
import { Device } from 'src/app/models/entities';

export const loadItemsAction = createAction('[Device] Load Items', props<{payload: Device[]}>());
export const removeItemsAction = createAction('[Device] Remove ITems');

