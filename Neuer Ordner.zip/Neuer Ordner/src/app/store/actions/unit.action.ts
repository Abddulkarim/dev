import { createAction, props } from "@ngrx/store";
import { Unit } from "src/app/models/entities";


export const loadItemsAction =createAction('[Unit] Load Items',props<{payload:Unit[]}>());
export const addItemAction =createAction('[Unit] add Item',props<{payload:Unit}>());
export const updateItemAction = createAction('[Unit] Update Item', props<{payload: Unit}>());
export const deleteItemAction = createAction('[Unit] Delete Item', props<{payload: Unit}>());
export const removeItemsAction = createAction('[Unit] Remove Items');

// export enum UnitActionTypes {
//   LOADAction = '[Unit] load',
//   AddUnitListAction = '[Unit] List add',
//   AddItemAction = '[Unit] add',
//   UpdateItemAction = '[Unit] update',
//   DeleteAction = '[Unit] delete',
//   ClearAction = '[Unit] clear',
//   FaildAction = '[Unit] failed',
// }

// export class LoadUnitAction {
//   type: string = UnitActionTypes.LOADAction;
// }

// export class SuccessUnitAction implements Action {

//   readonly type = UnitActionTypes.AddUnitListAction;
//   payload: Unit[];

//   constructor( payload: Unit[] ) {
//     this.payload=payload;
//   }
// }

// export class AddUnitItemAction implements Action {

//   readonly type = UnitActionTypes.AddItemAction;
//   payload: Unit;

//   constructor( payload: Unit) {
//     this.payload=payload;
//   }
// }
// export class UpdateUnitItemAction implements Action {

//   readonly type = UnitActionTypes.UpdateItemAction;
//   payload: Unit;

//   constructor( payload: Unit) {
//     this.payload=payload;
//   }
// }

// export class DeleteUnitItemAction implements Action {

//   readonly type = UnitActionTypes.DeleteAction;
//   payload: Unit;

//   constructor( payload: Unit) {
//     this.payload=payload;
//   }
// }

// export class FaildUnitAction implements Action {

//   readonly type = UnitActionTypes.FaildAction;
//   payload: any;
//   constructor(payload: any) {
//     this.payload=payload;
//   }
// }


// export class ClearUniteAction implements Action {

//   readonly type = UnitActionTypes.ClearAction;
// }


// export type UnitActions = SuccessUnitAction |AddUnitItemAction|UpdateUnitItemAction|DeleteUnitItemAction|ClearUniteAction;