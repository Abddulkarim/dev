import {createFeatureSelector, createSelector} from '@ngrx/store';
import { EvaluationVersionsState } from '../reducers/evaluationVersion.reducer';

let selectEvaluationversionsState= createFeatureSelector<EvaluationVersionsState>('evaluationVersionsState');
export let selectEvaluationversions=createSelector(selectEvaluationversionsState, state=>state.dataList);