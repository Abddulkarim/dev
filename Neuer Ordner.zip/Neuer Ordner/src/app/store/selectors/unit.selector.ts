import {createFeatureSelector, createSelector} from '@ngrx/store';
import { UnitsState } from '../reducers/unit.reducer';


let selectUnitState= createFeatureSelector<UnitsState>('unitsState');
export let selectUnit=createSelector(selectUnitState, state=>state.dataList);