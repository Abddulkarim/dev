import {createFeatureSelector, createSelector} from '@ngrx/store';
import { AuthState } from '../reducers/user.reducer';


let selectAuthState= createFeatureSelector<AuthState>('authState');

export const isLoggedIn = createSelector(selectAuthState,auth => auth.loggedIn);
export const isLoggedOut = createSelector(isLoggedIn,loggedIn => !loggedIn);
export const userRoles = createSelector(selectAuthState,auth => auth.user.roles);
