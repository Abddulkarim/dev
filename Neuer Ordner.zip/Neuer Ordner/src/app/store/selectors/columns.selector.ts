import {createFeatureSelector, createSelector} from '@ngrx/store';
import { ColumnsState } from '../reducers/columns.reducer';


let selectColumnsState= createFeatureSelector<ColumnsState>('columnsState');
export let selectColumns=createSelector(selectColumnsState, state=>state.dataList);