import {createFeatureSelector, createSelector} from '@ngrx/store';
import { GroupingState } from '../reducers/grouping.reducer';


let selectGroupingState= createFeatureSelector<GroupingState>('groupingState');
export let selectGrouping=createSelector(selectGroupingState, state=>state.dataList);