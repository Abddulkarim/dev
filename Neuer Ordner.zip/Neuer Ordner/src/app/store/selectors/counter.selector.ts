
import {createFeatureSelector,createSelector} from '@ngrx/store';
import { CounterState } from "../reducers/counter.reducer";

  let selectCounterState= createFeatureSelector<CounterState>('counterState');
export let selectCounter=createSelector(selectCounterState, state=>state.user);
