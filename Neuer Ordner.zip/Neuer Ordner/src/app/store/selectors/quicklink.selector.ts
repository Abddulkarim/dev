import {createFeatureSelector, createSelector} from '@ngrx/store';
import { QuicklinksState } from '../reducers/quicklink.reducer';

let selectQuicklinksState= createFeatureSelector<QuicklinksState>('quicklinksState');
export let selectQuicklink=createSelector(selectQuicklinksState, state=>state.dataList);
export let findQuiclink = (quiclinkId: string) =>
createSelector(selectQuicklink, (data) => data.find(data => data.quicklinkId===quiclinkId));