import {createFeatureSelector, createSelector} from '@ngrx/store';
import { ResolutionsState } from '../reducers/resulution.reducer';

let selectResolutionsState= createFeatureSelector<ResolutionsState>('resolutionsState');
export let selectResolution=createSelector(selectResolutionsState, state=>state.dataList);