import {createFeatureSelector, createSelector} from '@ngrx/store';
import { EvaluationsState } from '../reducers/evaluation.reducer';

let selectEvaluationState= createFeatureSelector<EvaluationsState>('evaluationsState');
export let selectEvaluation=createSelector(selectEvaluationState, state=>state.dataList);

export const findItemByIndex = (index:number) => createSelector(selectEvaluation, (items) => {
    if (items) {
      return items.find(item => {
        return item.index === index;
      });
    } else {
      return null;
    }
  });