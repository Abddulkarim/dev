import {createFeatureSelector, createSelector} from '@ngrx/store';
import { CategoriesState } from '../reducers/category.reducer';

let selectCategoriesState= createFeatureSelector<CategoriesState>('categoriesState');
export let selectCategories=createSelector(selectCategoriesState, state=>state.dataList);
export let filterByName = (text: string) =>
  createSelector(selectCategories, (data) => data.filter(data => data.name.toUpperCase().includes(text.toUpperCase())));

  export const getItemByIndex = (index:number) => createSelector(selectCategories, (allItems) => {
    if (allItems) {
      return allItems.find(item => {
        return item.index === index;
      });
    } else {
      return {};
    }
  });