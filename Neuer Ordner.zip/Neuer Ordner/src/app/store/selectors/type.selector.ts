import {createFeatureSelector, createSelector} from '@ngrx/store';
import { TypesState } from '../reducers/type.reducer';

let selectTypesState= createFeatureSelector<TypesState>('typesState');
export let selectType=createSelector(selectTypesState, state=>state.dataList);