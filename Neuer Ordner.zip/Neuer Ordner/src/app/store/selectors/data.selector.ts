import {createFeatureSelector, createSelector} from '@ngrx/store';
import { DataState } from '../reducers/data.reducer';


let selectDataState= createFeatureSelector<DataState>('dataState');
export let selectData=createSelector(selectDataState, state=>state.data);
