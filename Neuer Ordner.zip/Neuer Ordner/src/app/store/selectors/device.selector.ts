import {createFeatureSelector, createSelector} from '@ngrx/store';
import { DevicesState } from '../reducers/device.reducer';

let selectDevicessState= createFeatureSelector<DevicesState>('devicesState');
export let selectDevices=createSelector(selectDevicessState, state=>state.dataList);

export let selectCustomer = (text: string) =>
  createSelector(selectDevices, (data) => data.filter(data => data.name.toUpperCase().includes(text.toUpperCase())));
  export let findDevice = (text: string) =>
  createSelector(selectDevices, (data) => data.filter(data => data.name.toUpperCase()===text.toUpperCase()));