import {createFeatureSelector, createSelector} from '@ngrx/store';
import { DataTypesState } from '../reducers/dataType.reducer';

let selectDataTypesState= createFeatureSelector<DataTypesState>('dataTypesState');
export let selectDataType=createSelector(selectDataTypesState, state=>state.dataList);