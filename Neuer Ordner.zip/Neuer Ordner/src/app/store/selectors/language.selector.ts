import { createFeatureSelector, createSelector } from "@ngrx/store";
import { Language } from "../reducers/language.reducer";

let reducerFSLanguage= createFeatureSelector<Language>('language');
export let selectLanguageCode=createSelector(reducerFSLanguage, state=>state.code);
