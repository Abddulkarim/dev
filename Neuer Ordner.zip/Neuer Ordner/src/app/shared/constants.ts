export class Constants {

    //private static API_URL = "https://localhost:44382/p3api/v1/";
    //private static API_URL = "https://p3apinightly.wurm.de/p3api/v1/";

    private static API_URL = "https://p3apinightly.wurm.de/";
    //private static API_URL = "https://localhost:7175/";

    public static API_WAREHOUSES = Constants.API_URL + "warehouses";
    public static API_WAREHOUSE = Constants.API_URL + "warehouse";

    public static API_EVALUATIONS = Constants.API_URL + "evaluations";
    public static API_EVALUATION = Constants.API_URL + "evaluation";


    public static API_EVALUATION_VERSIONS = Constants.API_URL + "evaluationversions";
    public static API_EVALUATION_VERSION = Constants.API_URL + "evaluationversion";

    public static PARAMETERS = "parameters";
    public static IGNORE = "ignore";
    public static API_PARAMETERS = Constants.API_URL +Constants.PARAMETERS;
    public static API_PARAMETER = Constants.API_URL + "parameter";
    public static API_PARAMETERS_BY_EVALUATION = Constants.API_EVALUATION + "/"+Constants.PARAMETERS;
    public static API_PARAMETERS_BY_EVALUATION_VERSION = Constants.API_EVALUATION_VERSION + "/"+Constants.PARAMETERS;


    public static API_SIGNAL_PARAMETERS = Constants.API_URL + "signalparameters";
    public static API_SIGNAL_PARAMETER = Constants.API_URL + "signalparameter";
    public static API_SCHEME_RELEASES_SIGNAL_PARAMETER = "signalparameter";
    public static API_SCHEME_RELEASES_SIGNAL_PARAMETERS = "signalparameters";

    public static PARAMETERGROUP = "parametergroup";
    public static API_PARAMETERGROUPS = Constants.API_URL + "parametergroups";
    public static API_PARAMETERGROUP = Constants.API_URL + "parametergroup";
    public static API_SCHEME_RELEASES_PARAMETERGROUPS = "parametergroups";


    public static API_SCHEMA_RELEASE_BASE = Constants.API_URL + "schemerelease";
    public static API_SCHEME_RELEASES = Constants.API_URL + "schemereleases";
    public static API_SCHEME_RELEASE = Constants.API_URL + "schemerelease";
    public static API_SCHEME_RELEASE_QL_FILE = "qlfile";

    public static API_TYPES = Constants.API_URL + "types";
    public static API_TYPE = Constants.API_URL + "type";

    public static API_DATATYPES = Constants.API_URL + "datatypes";
    public static API_DATATYPE = Constants.API_URL + "datatype";

    public static API_UNITS = Constants.API_URL + "units";
    public static API_UNIT = Constants.API_URL + "unit";

    public static API_DEVICES = Constants.API_URL + "devices";
    public static API_DEVICE = Constants.API_URL + "device";

    public static API_RESOLUTIONS = Constants.API_URL + "resolutions";
    public static API_RESOLUTION = Constants.API_URL + "resolution";

    public static API_PROJECTS = Constants.API_URL + "projects";
    public static API_PROJECT = Constants.API_URL + "project";

    public static API_PARAMETER_IGNORE = Constants.API_SCHEME_RELEASE ;
}
export enum ContextmenuParameter {
    COPY = "COPY",
    EXCEL = "EXCEL",
    DELETE = "DELETE",
    RELEASE_IGNORE = "RELEASE_IGNORE",
    PARAMETERGROUP_IGNORE = "PARAMETERGROUP_IGNORE",
    PDF = "PDF",
    STATISTICS = "STATISTICS",
}
