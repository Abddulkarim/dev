import { ModuleWithProviders, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { EffectsModule } from '@ngrx/effects';
import { KendoModule } from './kendo.module';
import { DropdownFilterComponent } from './dropdown-filter/dropdown-filter.component';



@NgModule({
  declarations: [
    //AfterValueChangedDirective,
    DropdownFilterComponent,
  ],
  imports: [
    CommonModule,
    RouterModule,
    EffectsModule,
    KendoModule
   // TranslatModule,

  ],
  exports: [
    CommonModule,
    RouterModule,
    EffectsModule,
    KendoModule,
    DropdownFilterComponent,
    //AfterValueChangedDirective,
    //TranslatModule,
  ],
  providers: [
    //{ provide: RouterStateSerializer }
  ],
})
export class SharedModule { }

//   static forRoot(): ModuleWithProviders<SharedModule> {
//     return {
//       ngModule: SharedModule,
//     };
//   }


  
//   static forChild(): ModuleWithProviders<SharedModule>  {
//     return {
//       ngModule: SharedModule
//     };
//   }
// }


// export const shredModuleWithoutConfig: ModuleWithProviders<SharedModule> = {
//   ngModule: SharedModule
// };