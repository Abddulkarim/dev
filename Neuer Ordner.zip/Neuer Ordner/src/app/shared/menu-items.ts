import { trashIcon, filePdfIcon, fileExcelIcon, SVGIcon, copyIcon, chartColumnStackedIcon, bordersShowHideIcon, eyeSlashIcon } from '@progress/kendo-svg-icons';
import { ContextmenuParameter } from './constants';

export interface MenuItems {
    text?: string;
    tooltip?: string;
    checkText?: any;
    svgIcon?: SVGIcon;
    children?: childMenuItem[];
    separator?: boolean;
    items?: MenuItems[];
}

export interface childMenuItem {
    childText?: string;
    svgIcon?: SVGIcon;
}
let menuItemCopy:MenuItems={ text: $localize`Kopieren`, tooltip: $localize`In eine andere Parametergruppe kopieren`, checkText: ContextmenuParameter.COPY, svgIcon: copyIcon };
let menuItemDelete:MenuItems={ text: $localize`Verknüpfung entfernen`, tooltip: $localize`Die Verknüpfung der selektierten Einträgen entfernen`, checkText: ContextmenuParameter.DELETE, svgIcon: trashIcon };
let menuItemReleaseShow:MenuItems={ text: $localize`In die Freigabe einblenden`, tooltip: $localize`Die selektierten Parameter einblenden`, checkText: ContextmenuParameter.RELEASE_IGNORE, svgIcon: eyeSlashIcon };
let menuItemReleaseHite:MenuItems={ text: $localize`In die Freigabe ausblenden`, tooltip: $localize`Die selektierten Parameter ausblenden`, checkText: ContextmenuParameter.RELEASE_IGNORE, svgIcon: eyeSlashIcon };
let menuItemGroupShow:MenuItems={ text: $localize`In die verknüpfte Parametergruppe einblenden`, tooltip: $localize`Die selektierten Parameter in die verknüpfte Parametergruppe einblenden`, checkText: ContextmenuParameter.PARAMETERGROUP_IGNORE, svgIcon: eyeSlashIcon};
let menuItemGroupHite:MenuItems={ text: $localize`In die verknüpfte Parametergruppe ausblenden`, tooltip: $localize`Die selektierten Parameter in die verknüpfte Parametergruppe ausblenden`, checkText: ContextmenuParameter.PARAMETERGROUP_IGNORE, svgIcon: eyeSlashIcon};
let menuItemPDF:MenuItems={ text: $localize`Als PDF exportieren`, tooltip: $localize`Die selektierten Einträge Als PDF exportieren`, checkText: ContextmenuParameter.PDF, svgIcon: filePdfIcon };
let menuItemExcel:MenuItems={ text: $localize`Als Excel exportieren`, tooltip: $localize`Die selektierten Einträge Als Excel exportieren`, checkText: ContextmenuParameter.EXCEL, svgIcon: fileExcelIcon };
let menuItemStatistic:MenuItems={ text: $localize`Statistik`, tooltip: $localize`Statistik anzeigen`, checkText: ContextmenuParameter.STATISTICS, svgIcon: chartColumnStackedIcon };
// export let menuItems: MenuItems[] = [
//     { text: $localize`Kopieren`, tooltip: $localize`In eine andere Parametergruppe kopieren`, checkText: ContextmenuParameter.COPY, svgIcon: copyIcon },
//     { text: $localize`Verknüpfung entfernen`, tooltip: $localize`Die Verknüpfung der selektierten Einträgen entfernen`, checkText: ContextmenuParameter.DELETE, svgIcon: trashIcon },
//     { text: $localize`In die Freigabe einblenden`, tooltip: $localize`Die selektierten Parameter einblenden`, checkText: ContextmenuParameter.RELEASE_IGNORE, svgIcon: eyeSlashIcon },
//     { text: $localize`In die Freigabe ausblenden`, tooltip: $localize`Die selektierten Parameter ausblenden`, checkText: ContextmenuParameter.RELEASE_IGNORE, svgIcon: eyeSlashIcon },
//     { text: $localize`In die verknüpfte Parametergruppe einblenden`, tooltip: $localize`Die selektierten Parameter in die verknüpfte Parametergruppe einblenden`, checkText: ContextmenuParameter.PARAMETERGROUP_IGNORE, svgIcon: eyeSlashIcon},
//     { text: $localize`In die verknüpfte Parametergruppe ausblenden`, tooltip: $localize`Die selektierten Parameter in die verknüpfte Parametergruppe ausblenden`, checkText: ContextmenuParameter.PARAMETERGROUP_IGNORE, svgIcon: eyeSlashIcon},
//     { text: $localize`Als PDF exportieren`, tooltip: $localize`Die selektierten Einträge Als PDF exportieren`, checkText: ContextmenuParameter.PDF, svgIcon: filePdfIcon },
//     { text: $localize`Als Excel exportieren`, tooltip: $localize`Die selektierten Einträge Als Excel exportieren`, checkText: ContextmenuParameter.EXCEL, svgIcon: fileExcelIcon },
//     { text: $localize`Statistik`, tooltip: $localize`Statistik anzeigen`, checkText: ContextmenuParameter.STATISTICS, svgIcon: chartColumnStackedIcon },
// ];
export let menuItems1: MenuItems[] = [menuItemCopy,menuItemDelete,menuItemPDF,menuItemExcel, menuItemStatistic];
export let menuItems2: MenuItems[] = [menuItemCopy,menuItemReleaseShow,menuItemGroupShow,menuItemPDF,menuItemExcel, menuItemStatistic];
export let menuItems3: MenuItems[] = [menuItemCopy,menuItemReleaseHite,menuItemGroupHite,menuItemPDF,menuItemExcel, menuItemStatistic];