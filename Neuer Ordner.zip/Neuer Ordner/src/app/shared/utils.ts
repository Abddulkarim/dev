//import { FlatTreeControl } from "@angular/cdk/tree";
import { ItemNode } from "./dialogs/evaluations-dialog/evaluations-dialog";


export default class Utils {
  static groupBy<K, V>(array: V[], grouper: (item: V) => K) {
    const initial: { key: K; values: V[] }[] = [];
    return array.reduce((store, item) => {
      const key = grouper(item);
      const foundItem = store.find((i) => i.key === key);
      if (foundItem != null) {
        foundItem.values.push(item);
      } else {
        store.push({ key, values: [item] });
      }
      return store;
    }, initial);
  }



  static createNodes<K>(items: K[], childrenSelector: (item: K) => K[] | any[], itemNodeCreator: (item: K | any) => ItemNode, parent: ItemNode = null): ItemNode[] {
    const result: ItemNode[] = [];

    items?.forEach(item => {
      const resultNode = itemNodeCreator(item);

      if (resultNode != null) {
        const childs = childrenSelector(item);
        if (childs?.length > 0) {
          resultNode.children = this.createNodes(childs, childrenSelector, itemNodeCreator, resultNode);
        }
      }

      result.push(resultNode);
    });

    return result;
  }

  public static sort(array: any[]): any[] {
    return array.sort((a, b) => (a.name > b.name) ? 1 : -1);
  }
}