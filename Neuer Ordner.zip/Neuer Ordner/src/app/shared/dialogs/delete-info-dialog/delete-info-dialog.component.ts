import { Component, Input, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import {
  DialogRef,
  DialogContentBase,
  PreventableEvent,
} from "@progress/kendo-angular-dialog";
@Component({
  selector: 'app-delete-info-dialog',
  templateUrl: './delete-info-dialog.component.html',
  styleUrls: ['./delete-info-dialog.component.css']
})
export class DeleteInfoDialog extends DialogContentBase implements OnInit {

  @Input() public data: any;


  constructor(public override dialog: DialogRef) {
    super(dialog);
  }

  public ngOnInit(): void {
    const allocationsInfo = this.dialog.content.instance;
   
  }
  

  public onClose(ev: PreventableEvent): void {
    // prevent dialog from closing on clicking the `X` (close) button
    ev.preventDefault();
  }

  public onCancelAction(): void {
    this.dialog.close("Cancel");
  }

  public onConfirmAction(): void {
    this.dialog.close("Yes");
  }

}

