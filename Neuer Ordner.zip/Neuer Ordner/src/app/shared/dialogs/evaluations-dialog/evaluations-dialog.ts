import { Component, EventEmitter, Input, OnInit, Optional, Output } from '@angular/core';
import { Store } from '@ngrx/store';
import { DialogContentBase, DialogRef } from '@progress/kendo-angular-dialog';
import { map } from 'rxjs';
import { EvaluationVersion } from 'src/app/models/entities';
import { selectEvaluation } from 'src/app/store/selectors/evaluation.selector';
import Utils from '../../utils';

export interface ItemNode {
  index: number | string;
  name: string;
  checked?: boolean;
  expanded?:boolean;
  evaluationVersion?: EvaluationVersion;
  children?: ItemNode[] | null;
}

@Component({
  selector: 'evaluations-dialog',
  templateUrl: './evaluations-dialog.html',
  styleUrls: ['./evaluations-dialog.css']
})
export class EvaluationsDialog extends DialogContentBase implements OnInit {
  @Input() public evaluationVersionData: EvaluationVersion[]=[];
  public checkedKeys: string[] = ['0'];
  @Input()
 public checkedItems: Array<any> = [];
 data: ItemNode[] = [];
 evaluationVersionsResult: EvaluationVersion[] = [];
  @Output() versionChecked: EventEmitter<{ version: EvaluationVersion, checked: boolean }[]> = new EventEmitter<{ version: EvaluationVersion, checked: boolean }[]>();

  constructor(private store: Store, @Optional() public override dialog: DialogRef) {  
    super(dialog); }

  ngOnInit(): void {
    this.store.select(selectEvaluation).pipe(
        map((data) => {
          return Utils.groupBy(data, (i) => i.warehouse?.index);
        }),
        map((group) => {
          const result: ItemNode[] = group.map((gr) => {
            const item: ItemNode = {
              index: gr.key as number,
              name: gr.values.find((i) => i !== undefined)?.warehouse
                ?.name as string,
              expanded:this.isCategoryChecked( gr.values),
              checked:this.isCategoryChecked( gr.values),
              children: gr.values.map((evaluation) => ({
                index: evaluation.index as number,
                name: evaluation.name,
                level: 1,
                expanded: evaluation.versions.findIndex(b => this.evaluationVersionData.findIndex(c => c.index === b.index) >= 0) >= 0,
                checked: evaluation.versions.findIndex(b => this.evaluationVersionData.findIndex(c => c.index === b.index) >= 0) >= 0,
                children: evaluation.versions?.map((evaluationVersion) => ({
                  index: evaluationVersion.index as number,
                  name: evaluationVersion.versionAuto,
                  evaluationVersion: evaluationVersion,
                  checked: this.isChecked(evaluationVersion, evaluationVersion.evaluationIndex),
                  children: undefined,
                  level: 2,
                })),
              })),
            };
            return item;
          });
          return result;
        })
      )
      .subscribe((result) => {
        this.data = result;
      });
  }

  
  isCategoryChecked(values: any[]) {
    const result = values.flatMap(i => i.versions).findIndex(b => this.evaluationVersionData.findIndex(c => c.index === b.index) >= 0) >= 0;
    return result;
  }

  isChecked(evaluationVersion: EvaluationVersion, parent: number) {
    let value = false;
    this.evaluationVersionData.forEach((data: any) => {
      if (data.index === evaluationVersion.index) {
        value = true;
      }
    });
    return value;
  }

  public onChange(event: Event, index: any): void {
    const result = this.data.flatMap(i => i.children).flatMap(i => i.children)
      .map(i => ({ version: i.evaluationVersion, checked: i.checked }));
    this.versionChecked.emit(result);
    result.forEach(data => {
      data
      if (data.checked === true) {
        this.evaluationVersionsResult.push(data.version);
      }
    })
  }

  // public isExpanded = (dataItem: any, index: string) => {
  //   const item: ItemNode = dataItem as ItemNode;
  //   return item.checked === true || (item.children !== undefined &&
  //     item.children.findIndex(i => i.checked === true || (i.children !== undefined &&
  //       i.children.findIndex(a => a.checked === true))) >= 0)
  // };

  public isExpanded = (dataItem: any, index: string) => {
    const item: ItemNode = dataItem as ItemNode;
    return item.expanded === true;
  };


  public onCancelAction(): void {
    this.dialog.close("Cancel");
  }

  public onConfirmAction(): void {
    this.dialog.close(this.evaluationVersionsResult);
  }

}
