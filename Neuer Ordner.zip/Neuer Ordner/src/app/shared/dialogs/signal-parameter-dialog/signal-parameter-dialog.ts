import { Component, Input, OnInit } from '@angular/core';
import { DialogRef, DialogContentBase } from '@progress/kendo-angular-dialog';
import { ParameterGroup, SignalParameter } from 'src/app/models/entities';
import { Observable, Subject, map } from 'rxjs';
@Component({
    selector: 'signal-parameter-dialog',
    templateUrl: './signal-parameter-dialog.html',
    styleUrls: ['./signal-parameter-dialog.css'],
})
export class SignalParameterDialog extends DialogContentBase implements OnInit {
    private subject: Subject<any> = new Subject();
    @Input() public parameterGroups: ParameterGroup[] = [];
    private _parameterGroup: ParameterGroup;
    private _group: string;
    private _quicklinkNumber: number = 2;
    public listGroups: Array<string> = ["__.__.__.__","__.X1.__.__", "__.__.X2.__", "__.__.__.X3"];
    public items: SignalParameter[];
    clonedItems: SignalParameter[];
    data: Array<{ index: number; name: string }>;
    constructor(public override dialog: DialogRef) {
        super(dialog);
    }
    
    public ngOnInit(): void {
        this.data=this.parameterGroups;
        this.parameterGroup = this.parameterGroups[0];
        this.group = '__.__.__.__';
        this.quicklinkNumber = -1;
    }

    @Input() public set parameterGroup(value: ParameterGroup) {
        this._parameterGroup = value;
    }

    public get parameterGroup(): ParameterGroup {
        return this._parameterGroup;
    }

    @Input() public set group(value: string) {
        this._group = value;
    }

    public get group(): string {
        return this._group;
    }

    @Input() public set quicklinkNumber(value: number) {
        this._quicklinkNumber = value;
    }

    public get quicklinkNumber(): number {
        return this._quicklinkNumber;
    }
    public valueNormalizer = (text: Observable<string>) => text.pipe(map((content: string) => {
        return {
            index: 0,
            name: content
        };
    }));


    public onCancelAction(): void {
        this.dialog.close({ text: 'Cancel' });
    }

    public onConfirmAction(): void {
       this.changeQuicklink(this.group,this.quicklinkNumber,this.parameterGroup);
        this.dialog.close({ text: 'Submit', items: this.clonedItems });
    }

    changeQuicklink(group: string, id: number,parameterGroup:ParameterGroup) {
        this.clonedItems = JSON.parse(JSON.stringify(this.items));
        this.clonedItems.forEach((obj:SignalParameter) => {
            obj.parameterGroup=parameterGroup;
            obj.index=undefined;
            obj.quickLinkExists=undefined;
            if (group == this.listGroups[1])
                obj.qlGroup1Id = id;
            else if (group == this.listGroups[2])
                obj.qlGroup2Id = id;
            else if (group == this.listGroups[3])
                obj.qlParameterId = id;
        });
    }
    
    handleFilter(value: string) {
        this.data = this.parameterGroups.filter(
            (data) => data.name.toLowerCase().indexOf(value.toLowerCase()) !== -1
        );
    }
    ngOnDestroy(): void {
        this.subject.next(null);
        this.subject.complete();
    }
}
