import { NgModule } from '@angular/core'; 
import { ExcelModule, GridModule, PDFModule } from '@progress/kendo-angular-grid';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { TreeViewModule } from '@progress/kendo-angular-treeview';
import { DialogsModule } from '@progress/kendo-angular-dialog';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { TreeListModule } from '@progress/kendo-angular-treelist';
import { TooltipsModule } from '@progress/kendo-angular-tooltip';
import { LabelModule } from '@progress/kendo-angular-label';
import { PopupModule } from "@progress/kendo-angular-popup";
import { TooltipModule } from '@progress/kendo-angular-tooltip';
import { FileSelectModule, UploadsModule } from '@progress/kendo-angular-upload';
import { LayoutModule } from "@progress/kendo-angular-layout";
import { ICON_SETTINGS, IconsModule } from "@progress/kendo-angular-icons";
// Load all required data for the bg locale
import "@progress/kendo-angular-intl/locales/bg/all";
import "@progress/kendo-angular-intl/locales/de/all";
import "@progress/kendo-angular-intl/locales/en/all";
import "@progress/kendo-angular-intl/locales/fr/all";
// Load the required calendar data for the de locale
import "@progress/kendo-angular-intl/locales/de/calendar";
import { NavigationModule } from '@progress/kendo-angular-navigation';
import { IndicatorsModule } from '@progress/kendo-angular-indicators';
import { ContextMenuModule, MenuModule } from '@progress/kendo-angular-menu';
import { NotificationModule } from '@progress/kendo-angular-notification';
import { ToolBarModule } from '@progress/kendo-angular-toolbar';
import { MessageService } from '@progress/kendo-angular-l10n';
import { FormsModule } from '@angular/forms';


const MODULE_ALL= [

  InputsModule,
  GridModule,
  ButtonsModule,
  DateInputsModule,
  LabelModule,
  TreeListModule,
  DropDownsModule,
  TreeViewModule,
  TooltipsModule,
  DialogsModule,
  UploadsModule,
  PopupModule,
  TooltipModule,
  IconsModule,
  NavigationModule,
  IndicatorsModule,
  LayoutModule,
  MenuModule,
  FileSelectModule,
  NotificationModule,
  ToolBarModule,
  FormsModule,
  ContextMenuModule,
  ExcelModule,
  PDFModule
];
@NgModule({
  declarations: [],
  imports: [MODULE_ALL],
  exports: [MODULE_ALL],
  providers:[MessageService,{ provide: ICON_SETTINGS, useValue: { type: 'font' } }],
})
export class KendoModule { }
