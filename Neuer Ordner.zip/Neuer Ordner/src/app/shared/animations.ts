import { style, animate, trigger, state, transition, query, stagger, sequence, AUTO_STYLE } from "@angular/animations";
const DEFAULT_DURATION = 300;

// einblenden/ausblenden
export let collapseAnimation = trigger('collapse', [
  state('false', style({ height: AUTO_STYLE, visibility: AUTO_STYLE })),
  state('true', style({ height: '0', visibility: 'hidden' })),
  transition('false => true', animate(DEFAULT_DURATION + 'ms ease-in')),
  transition('true => false', animate(DEFAULT_DURATION + 'ms ease-out'))
])

export let slideInAnimation = trigger('slideIn', [
  state('*', style({ 'overflow-y': 'hidden' })),
  state('void', style({ 'overflow-y': 'hidden' })),
  transition('* => void', [style({ height: '*' }), animate(800, style({ height: 100 }))]),
  transition('void => *', [style({ height: '0' }), animate(500, style({ height: '*' }))])
])

export let listAnimation = trigger('listAnimation', [
  transition('* <=> *', [
    query(':enter', [style({ opacity: 0 }), stagger('60ms', animate('600ms ease-out', style({ opacity: 1 })))], { optional: true }),
    query(':leave', animate('200ms', style({ opacity: 0 })), { optional: true })
  ])
]);

// export let enterAnimation = trigger('enterAnimation', [
//   transition(':enter', [style({ transform: 'translateX(100%)', opacity: 0 }), animate('500ms', style({ transform: 'translateX(0)', opacity: 1, 'overflow-x': 'hidden' }))]),
//   transition(':leave', [style({ transform: 'translateX(0)', opacity: 1 }), animate('500ms', style({ transform: 'translateX(100%)', opacity: 0 }))])
// ]);

// export const rowsAnimation = trigger('rowsAnimation', [
//   transition('void => *', [
//     style({ height: '*', opacity: '0', transform: 'translateX(-550px)', 'box-shadow': 'none' }),
//     sequence([
//       animate(".35s ease", style({ height: '*', opacity: '.2', transform: 'translateX(0)', 'box-shadow': 'none' })),
//       animate(".35s ease", style({ height: '*', opacity: 1, transform: 'translateX(0)' }))
//     ])
//   ])
// ]);