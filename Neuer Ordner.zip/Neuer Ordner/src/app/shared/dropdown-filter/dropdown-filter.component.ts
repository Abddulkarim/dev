import { AfterViewInit, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FilterService } from '@progress/kendo-angular-grid';
import { FilterDescriptor } from '@progress/kendo-data-query';

@Component({
  selector: 'dropdown-filter',
  templateUrl: './dropdown-filter.component.html',
  styleUrls: ['./dropdown-filter.component.css']
})
export class DropdownFilterComponent implements OnInit, AfterViewInit {
  @Input() public isPrimitive: boolean;
  @Input() public currentFilter: any;
  @Input() public data: any;
  @Input() public textField: any;
  @Input() public valueField: any;
  @Input() public filterService: FilterService;
  @Input() public field: string;
  @Output() public valueChange = new EventEmitter<any[]>();
  public currentData: any;
  public showFilter = true;
  public value: any;
  constructor() { }

  ngOnInit(): void {
  }
  public onValueChange(value: any): void {
    this.filterService.filter({ filters: [{ field: this.field, operator: "eq", value: value.name }], logic: "and", });
  }

  public ngAfterViewInit(): void {
    this.currentData = this.data;
    const currentColumnFilter: FilterDescriptor =
      this.currentFilter.filters.find(
        (filter: FilterDescriptor) => filter.field === this.field);
    if (currentColumnFilter) {
      this.value = this.data.find((x: any) => x.name === currentColumnFilter.value);
    }
  }
}
