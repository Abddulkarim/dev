import { ChangeDetectionStrategy, Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AdminComponent implements OnInit, OnDestroy {
  routes = [
    { link: 'categories', label: $localize`Kategorien` },
    { link: 'units', label: $localize`Einheiten` },
    { link: 'resolutions', label: $localize`Auflösungen` },
    { link: 'types', label: $localize`Typen` },
    { link: 'dataTypes', label: $localize`dataTypen` },
    { link: 'parametergroups', label: $localize`parametergruppen` },
    { link: 'devices', label: $localize`Verwendungen` },
    { link: 'projects', label: $localize`Projekte` },
  ];
  constructor(public router: Router) {}
  ngOnInit(): void {}

  ngOnDestroy(): void {}

  public onTabSelect(e: any) {
    let route = this.routes[e.index];
    this.router.navigate(['admin/' + route.link]);
  }

  // check route
  public isRouteSelected(route: string): boolean {
    return this.router.url.endsWith(route);
  }
}
