import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AdminComponent } from './admin.component';
import { DataTypesComponent } from './data-types/data-types.component';
import { ParameterGroupComponent } from './parameter-group/parameter-group.component';
import { ResolutionsComponent } from './resolutions/resolutions.component';
import { TypesComponent } from './types/types.component';
import { UnitComponent } from './units/unit.component';
import { WarehousesComponent } from './warehouses/warehouses.component';
import { AuthGuard } from '../services/authGuard';
import { DeviceWarehousesComponent } from './device-warehouses/device-warehouses.component';
import { ProjectWarehousesComponent } from './project-warehouses/project-warehouses.component';


const routes: Routes = [
  {
    path: '',component: AdminComponent,
    children: [
      {path: '',redirectTo: 'categories',pathMatch: 'full'},
      {path: 'categories', component: WarehousesComponent,data: { title: 'de.router.categories' },canActivate:[AuthGuard]},
      {path: 'units',component: UnitComponent,data: { title: 'de.router.units' },canActivate:[AuthGuard]},
      {path: 'resolutions', component: ResolutionsComponent,data: { title: 'de.router.resolutions' },canActivate:[AuthGuard]},
      {path: 'types', component: TypesComponent,data: { title: 'de.router.types' },canActivate:[AuthGuard]},
      {path: 'dataTypes', component: DataTypesComponent,data: { title: 'de.router.dataTypes' },canActivate:[AuthGuard]},
      {path: 'parametergroups', component: ParameterGroupComponent,data: { title: 'de.router.parametergroups' },canActivate:[AuthGuard]},
      {path: 'devices', component: DeviceWarehousesComponent,data: { title: 'de.router.devices' },canActivate:[AuthGuard]},
      {path: 'projects', component: ProjectWarehousesComponent,data: { title: 'de.router.projects' },canActivate:[AuthGuard]},
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
