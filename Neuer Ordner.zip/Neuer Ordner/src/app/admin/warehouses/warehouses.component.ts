import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import { State } from '@progress/kendo-data-query';
import { DialogRef, DialogService } from '@progress/kendo-angular-dialog';
import { AddEvent, CancelEvent, DataStateChangeEvent, EditEvent, GridDataResult, RemoveEvent, RowClassArgs, SaveEvent } from '@progress/kendo-angular-grid';
import { BehaviorSubject, Subject, takeUntil } from 'rxjs';
import { Warehouse } from 'src/app/models/entities';
import { NotificationService } from 'src/app/services/notification.service';
import { CategoryService } from 'src/app/services/resource.service';
import * as CategoryActions from 'src/app/store/actions/category.action';
import { MessagesService } from 'src/app/services/messages.service';
import { DeleteInfoDialog } from 'src/app/shared/dialogs/delete-info-dialog/delete-info-dialog.component';
import { slideInAnimation } from 'src/app/shared/animations';
@Component({
  selector: 'app-warehouses',
  templateUrl: './warehouses.component.html',
  styleUrls: ['./warehouses.component.css'],
  animations: [slideInAnimation]
})
export class WarehousesComponent implements OnInit {

  private subject: Subject<any> = new Subject();
  dataSourceNew: BehaviorSubject<GridDataResult> = new BehaviorSubject(null);
  formGroup: FormGroup;
  loading = new BehaviorSubject<boolean>(false);
  state: State = { skip: 0, take: 50, group: [], filter: { filters: [], logic: "and" }, sort: [{ field: "name", dir: "asc" }], };
  constructor(
    private messagesService: MessagesService,
    private store: Store,
    private categoryService: CategoryService,
    private dialogService: DialogService,
    private notificationService: NotificationService) { }

  ngOnInit(): void {
    this.getCategories();
  }

  dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.getCategories();
  }

  getCategories(): void {
    this.loading.next(true);
    this.categoryService.findItemsByParamsDataSource(this.state, null).pipe(takeUntil(this.subject)).subscribe((data) => {
      this.dataSourceNew.next(data);
      this.loading.next(false);
    });
  }

  //neuen Eintrag erstellen
  addHandler({ sender, dataItem, rowIndex }: AddEvent): void {
    this.formGroup = new FormGroup({
      name: new FormControl('', [Validators.required, Validators.minLength(4)]),
    });
    sender.addRow(this.formGroup);
  }

  //Einen (neuen) Eintrag erstellen/editieren
  public saveHandler({ sender, rowIndex, dataItem, isNew }: SaveEvent): void {
    const category = Object.assign({}, dataItem) as Warehouse;
    category.name = this.formGroup.get('name').value;
    if (isNew) {
      this.categoryService.save(category).pipe(takeUntil(this.subject)).subscribe({
        next: (categoryData) => {
          const data = this.dataSourceNew.value as GridDataResult;
          data.data.unshift(categoryData);
          this.dataSourceNew.next(data);
          this.notificationService.success(this.messagesService.getMessage());
          this.store.dispatch(CategoryActions.addItemAction({ payload: Object.assign({}, categoryData) }));
        },
        error: (error) => {
          this.error(error);
        },
      });
    } else {
      this.categoryService.update(category.index, category).pipe(takeUntil(this.subject)).subscribe({
        next: (categoryData) => {
          dataItem.name = categoryData.name;
          const data = this.dataSourceNew.value as GridDataResult;
          this.dataSourceNew.next(data);
          this.notificationService.success(this.messagesService.getMessage());
          this.store.dispatch(CategoryActions.updateItemAction({ payload: category }));
        },
        error: (error) => {
          this.error(error);
        },
      });
    }
    sender.closeRow(rowIndex);
  }

  public editHandler({ sender, rowIndex, dataItem }: EditEvent): void {
    this.formGroup = new FormGroup({
      name: new FormControl(dataItem.name, [Validators.required, Validators.minLength(4)]),
    });

    sender.editRow(rowIndex, this.formGroup);
  }

  //Einen Eintrag entfernen
  removeHandler({ sender, rowIndex, dataItem }: RemoveEvent) {
    const category: Warehouse = dataItem;
    const dialogRef: DialogRef = this.dialogService.open({ content: DeleteInfoDialog });
    const dataInfo = dialogRef.content.instance as DeleteInfoDialog;
    dataInfo.data = category;
    dialogRef.result.subscribe((dialogResult) => {
      if (dialogResult == 'Yes') {
        this.categoryService.delete(category.index).pipe(takeUntil(this.subject)).subscribe({
          next: (categoryData) => {
            const data = this.dataSourceNew.value as GridDataResult;
            //data.data.splice(rowIndex, 1);
            data.data.forEach((item, index) => {
              if (item.index === category.index) { data.data.splice(index, 1); }
            });
            this.dataSourceNew.next(data);
            this.notificationService.success(this.messagesService.getMessage());
            this.store.dispatch(CategoryActions.deleteItemAction({ payload: category }));
          },
          error: (error) => {
            this.error(error);
          },
        });
      }
    });
  }

  public cancelHandler({ sender, rowIndex }: CancelEvent): void {
    sender.closeRow(rowIndex);
    this.formGroup = null;
  }

  public rowCallback = (context: RowClassArgs) => {
    const isEven = context.index % 2 == 0;
    return {
      even: isEven,
      odd: !isEven
    };
  }

  ngOnDestroy(): void {
    this.subject.next(null);
    this.subject.complete();
  }

  error(error: any) {
    //const title = this.messagesService.getErrorMessage(Number(error?.message));
    this.notificationService.error(error?.message);
  }
}
