import { Component, OnInit } from '@angular/core';
import { NotificationService } from 'src/app/services/notification.service';
import { State } from '@progress/kendo-data-query';
import { BehaviorSubject, Subject, takeUntil } from 'rxjs';
import { CancelEvent, DataStateChangeEvent, EditEvent, GridDataResult, RemoveEvent, RowClassArgs, SaveEvent, } from '@progress/kendo-angular-grid';
import { FormControl, FormGroup } from '@angular/forms';
import { Project, Warehouse } from '../../models/entities';
import { MessagesService } from 'src/app/services/messages.service';
import { CategoryService, ProjectService } from 'src/app/services/resource.service';
import Utils from 'src/app/shared/utils';
import { DialogRef, DialogService } from '@progress/kendo-angular-dialog';
import { DeleteInfoDialog } from 'src/app/shared/dialogs/delete-info-dialog/delete-info-dialog.component';

@Component({
  selector: 'app-project-warehouses',
  templateUrl: './project-warehouses.component.html',
  styleUrls: ['./project-warehouses.component.css']
})
export class ProjectWarehousesComponent implements OnInit {

  private subject: Subject<any> = new Subject();
  dataSourceNew: BehaviorSubject<GridDataResult> = new BehaviorSubject(null);
  formGroup: FormGroup;
  categories: Warehouse[];
  loading = new BehaviorSubject<boolean>(false);
  state: State = { skip: 0, take: 50, group: [], filter: { filters: [], logic: 'and' }, sort: [{ field: "name", dir: "asc" }], };
  constructor(
    private projectService: ProjectService,
    private messagesService: MessagesService,
    private categoryService: CategoryService,
    private dialogService: DialogService,
    private notificationService: NotificationService) { }

  ngOnInit(): void {
    this.categoryService.findAll().subscribe((data) => { this.categories = Utils.sort(data) });
    this.getProjects();
  }

  dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.getProjects();
  }

  getProjects(): void {
    this.loading.next(true);
    this.projectService.findItemsByParamsDataSource(this.state, null).pipe(takeUntil(this.subject)).subscribe((data) => {
      this.dataSourceNew.next(data);
      this.loading.next(false);
    });
  }

  //Einen (neuen) Eintrag erstellen/editieren
  public saveHandler({ sender, rowIndex, dataItem, isNew }: SaveEvent): void {
    const project = Object.assign({}, dataItem) as Project;
    project.warehouses = this.formGroup.get('warehouses').value;
    if (isNew) {
      this.projectService.save(project).pipe(takeUntil(this.subject)).subscribe({
        next: (dataTypeData) => {
          const data = this.dataSourceNew.value as GridDataResult;
          data.data.unshift(dataTypeData);
          this.dataSourceNew.next(data);
          this.notificationService.success(this.messagesService.getMessage());
        },
        error: (error) => {
          this.error(error);
        },
      });
    } else {
      this.projectService.update(project.index, project).pipe(takeUntil(this.subject)).subscribe({
        next: (projectData) => {
          dataItem.warehouses = projectData.warehouses;
          const data = this.dataSourceNew.value as GridDataResult;
          this.dataSourceNew.next(data);
          this.notificationService.success(this.messagesService.getMessage());
        },
        error: (error) => {
          this.error(error);
        },
      });
    }
    sender.closeRow(rowIndex);
  }

  //Einen Eintrag entfernen
  removeHandler({ sender, rowIndex, dataItem }: RemoveEvent) {
    const project: Project = dataItem;
    const dialogRef: DialogRef = this.dialogService.open({
      content: DeleteInfoDialog,
    });
    const dataInfo = dialogRef.content.instance as DeleteInfoDialog;
    dataInfo.data = project;
    dialogRef.result.subscribe((dialogResult) => {
      if (dialogResult == 'Yes') {
        this.projectService.delete(project.index).pipe(takeUntil(this.subject)).subscribe({
          next: (resolutionData) => {
            const data = this.dataSourceNew.value as GridDataResult;
            //data.data.splice(rowIndex, 1);
            data.data.forEach((item, index) => {
              if (item.index === project.index) { data.data.splice(index, 1); }
            });
            this.dataSourceNew.next(data);
            this.notificationService.success(this.messagesService.getMessage());
          },
          error: (error) => {
            this.error(error);
          },
        });
      }
    });
  }
  
  public editHandler({ sender, rowIndex, dataItem }: EditEvent): void {
    this.formGroup = new FormGroup({
      warehouses: new FormControl(dataItem.warehouses),
    });

    sender.editRow(rowIndex, this.formGroup);
  }
  public cancelHandler({ sender, rowIndex }: CancelEvent): void {
    sender.closeRow(rowIndex);
    this.formGroup = null;
  }

  public rowCallback = (context: RowClassArgs) => {
    const isEven = context.index % 2 == 0;
    return {
      even: isEven,
      odd: !isEven,
    };
  };

  ngOnDestroy(): void {
    this.subject.next(null);
    this.subject.complete();
  }

  error(error: any) {
    //const title = this.messagesService.getErrorMessage(Number(error?.message));
    this.notificationService.error(error?.message);
  }

}
