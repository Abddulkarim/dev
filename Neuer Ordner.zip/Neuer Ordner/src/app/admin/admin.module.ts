import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { AdminComponent } from './admin.component';
import { UnitComponent } from './units/unit.component';
import { SharedModule } from '../shared/shared.module';
import { ResolutionsComponent } from './resolutions/resolutions.component';
import { TypesComponent } from './types/types.component';
import { DataTypesComponent } from './data-types/data-types.component';
import { WarehousesComponent } from './warehouses/warehouses.component';
import { ParameterGroupComponent } from './parameter-group/parameter-group.component';
import { DeviceWarehousesComponent } from './device-warehouses/device-warehouses.component';
import { ProjectWarehousesComponent } from './project-warehouses/project-warehouses.component';


@NgModule({
  declarations: [
    AdminComponent,
    UnitComponent,
    ResolutionsComponent,
    TypesComponent,
    DataTypesComponent,
    WarehousesComponent,
    ParameterGroupComponent,
    DeviceWarehousesComponent,
    ProjectWarehousesComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    SharedModule,
  ]
})
export class AdminModule { }
