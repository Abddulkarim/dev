import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { CancelEvent, DataStateChangeEvent, EditEvent, GridDataResult, RowClassArgs, SaveEvent, } from '@progress/kendo-angular-grid';
import { State } from '@progress/kendo-data-query';
import { BehaviorSubject, Subject, takeUntil } from 'rxjs';
import { Device, Warehouse } from 'src/app/models/entities';
import { MessagesService } from 'src/app/services/messages.service';
import { NotificationService } from 'src/app/services/notification.service';
import { CategoryService, DeviceService } from 'src/app/services/resource.service';
import Utils from 'src/app/shared/utils';

@Component({
  selector: 'app-devive-warehous',
  templateUrl: './device-warehouses.component.html',
  styleUrls: ['./device-warehouses.component.css']
})
export class DeviceWarehousesComponent implements OnInit {
  private subject: Subject<any> = new Subject();
  dataSourceNew: BehaviorSubject<GridDataResult> = new BehaviorSubject(null);
  loading = new BehaviorSubject<boolean>(false);
  state: State = { skip: 0, take: 50, group: [], filter: { filters: [], logic: 'and' }, sort: [{ field: "name", dir: "asc" }], };
  formGroup: FormGroup;
  selectedFile: File = null;
  filesNames: Array<String> = [];
  isValidFile: boolean = false;
  addedfiles: Array<any> = [];
  categories: Warehouse[];
  warehouses: Warehouse[];
  constructor(
    private deviceService: DeviceService,
    private categoryService: CategoryService,
    private notificationService: NotificationService,
    private messagesService: MessagesService) { }

  ngOnInit(): void {
    this.categoryService.findAll().subscribe((data) => { 
      this.categories = Utils.sort(data);
      this.warehouses= Object.assign({}, this.categories) as Warehouse[];
    });
    this.getDevices();
  }

  dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.getDevices();
  }

  getDevices(): void {
    let map = { onlyReleasedDevices: true };
    this.loading.next(true);
    this.deviceService.findItemsByParamsDataSource(this.state, map).pipe(takeUntil(this.subject)).subscribe((data) => {
      this.dataSourceNew.next(data);
      this.loading.next(false);
    });
  }
  //Einen (neuen) Eintrag erstellen/editieren
  public saveHandler({ sender, rowIndex, dataItem, isNew }: SaveEvent): void {
    const device = Object.assign({}, dataItem) as Device;
    device.warehouses = this.formGroup.get('warehouses').value;
    if (isNew) {
      this.deviceService.save(device).pipe(takeUntil(this.subject)).subscribe({
        next: (deviceData) => {
          const data = this.dataSourceNew.value as GridDataResult;
          data.data.unshift(deviceData);
          this.dataSourceNew.next(data);
          this.notificationService.success(this.messagesService.getMessage());
        },
        error: (error) => {
          this.error(error);
        },
      });
    } else {
      this.deviceService.update(device.index, device).pipe(takeUntil(this.subject)).subscribe({
        next: (deviceData) => {
          dataItem.warehouses = deviceData.warehouses;
          const data = this.dataSourceNew.value as GridDataResult;
          this.dataSourceNew.next(data);
          this.notificationService.success(this.messagesService.getMessage());
        },
        error: (error) => {
          this.error(error);
        },
      });
    }
    sender.closeRow(rowIndex);
  }

  public editHandler({ sender, rowIndex, dataItem }: EditEvent): void {
    this.formGroup = new FormGroup({
      warehouses: new FormControl(dataItem.warehouses),
    });

    sender.editRow(rowIndex, this.formGroup);
  }

  public cancelHandler({ sender, rowIndex }: CancelEvent): void {
    sender.closeRow(rowIndex);
    this.formGroup = null;
    this.categories = Object.assign([], this.warehouses);
  }

  public expandDetailsBy = (dataItem: Device): number => {
    return dataItem.index;
  };

  public rowCallback = (context: RowClassArgs) => {
    const isEven = context.index % 2 == 0;
    return { even: isEven, odd: !isEven };
  }
  
  changeWarehouses(warehouses: Warehouse[]) {
    this.categories = Object.assign([], this.warehouses);
    warehouses.forEach((newItem: any, key: any) => {
      let indexToUpdate = this.categories.findIndex(item => item.index === newItem.index);
      this.categories[indexToUpdate] = newItem;
    }
    )
    this.categories = Object.assign([], this.categories);

  }

  public itemDisabled(warehouses: any) {
    return warehouses.dataItem.hasProject == true; // disable the 3rd item
  }

  ngOnDestroy(): void {
    this.subject.next(null);
    this.subject.complete();
  }

  error(error: any) {
    //const title = this.messagesService.getErrorMessage(Number(error?.message));
    this.notificationService.error(error?.message);
  }

}
