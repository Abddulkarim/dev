import { Component, OnInit, ViewChild } from '@angular/core';
import { Store } from '@ngrx/store';
import { NotificationService } from 'src/app/services/notification.service';
import { DialogRef, DialogService } from '@progress/kendo-angular-dialog';
import { State } from '@progress/kendo-data-query';
import { BehaviorSubject, Subject, takeUntil } from 'rxjs';
import { AddEvent, CancelEvent, DataStateChangeEvent, EditEvent, GridComponent, GridDataResult, RemoveEvent, RowClassArgs, SaveEvent, } from '@progress/kendo-angular-grid';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import * as ResolutionsActions from '../../store/actions/resolution.action';
import { Resolution } from '../../models/entities';
import { DeleteInfoDialog } from 'src/app/shared/dialogs/delete-info-dialog/delete-info-dialog.component';
import { ResolutionService } from 'src/app/services/resource.service';
import { MessagesService } from 'src/app/services/messages.service';
import { EditEventImp, SaveEventImp } from 'src/app/models/gridEventImp';
import { slideInAnimation } from 'src/app/shared/animations';

@Component({
  selector: 'app-resolutions',
  templateUrl: './resolutions.component.html',
  styleUrls: ['./resolutions.component.css'],
  animations: [slideInAnimation]
})
export class ResolutionsComponent implements OnInit {

  private subject: Subject<any> = new Subject();
  dataSourceNew: BehaviorSubject<GridDataResult> = new BehaviorSubject(null);
  @ViewChild('grid') grid: GridComponent;
  isEditMode = false;
  formGroup: FormGroup;
  loading = new BehaviorSubject<boolean>(false);
  map = new Map();
  state: State = { skip: 0, take: 50, group: [], filter: { filters: [], logic: 'and' }, sort: [{ field: "name", dir: "asc" }], };
  constructor(
    private messagesService: MessagesService,
    private resolutionService: ResolutionService,
    private store: Store,
    private dialogService: DialogService,
    private notificationService: NotificationService) { }

  ngOnInit(): void {

    this.getTypes();
  }

  dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.getTypes();
  }

  getTypes(): void {
    this.loading.next(true);
    this.resolutionService.findItemsByParamsDataSource(this.state, null).pipe(takeUntil(this.subject)).subscribe((data) => {
      this.dataSourceNew.next(data);
      this.loading.next(false);
    });
  }
  
  // set all rows to edit mode to display form fields
  onEditAll() {
    this.map = new Map();
    this.dataSourceNew.value.data.forEach((x, i) => {
      const editEventImp = new EditEventImp(x, false, i, this.grid,);
      this.editHandler(editEventImp);
    });
    this.isEditMode = true;
  }


  // save all rows
  onSaveAll() {
    this.dataSourceNew.value.data.forEach((x, i) => {
      const saveEventImp = new SaveEventImp(x, false, i, this.grid,);
      this.formGroup
      this.initFormGroup(i);
      this.saveHandler(saveEventImp);
    });
    this.map = new Map();
    this.isEditMode = false;
  }

  // close all rows to display readonly view of data
  onCancelAll() {
    this.dataSourceNew.value.data.forEach((x, i) => {
      this.grid.closeRow(i);
    });
    this.isEditMode = false;
  }

  // init a new form group containing controls and validators for a product
  private initFormGroup(rowIndex: any): void {
    if (this.map.size > 0) {
      this.formGroup = this.map.get(rowIndex);
    }
  }


  //neuen Eintrag erstellen
  addHandler({ sender, dataItem, rowIndex }: AddEvent): void {
    this.formGroup = new FormGroup({
      name: new FormControl('', [Validators.required, Validators.minLength(4)]),
    });
    sender.addRow(this.formGroup);
  }

  //Einen (neuen) Eintrag erstellen/editieren
  public saveHandler({ sender, rowIndex, dataItem, isNew }: SaveEvent): void {
    const resolution = Object.assign({}, dataItem) as Resolution;
    resolution.name = this.formGroup.get('name').value;
    if (isNew) {
      this.resolutionService.save(resolution).pipe(takeUntil(this.subject)).subscribe({
        next: (resolutionData) => {
          const data = this.dataSourceNew.value as GridDataResult;
          data.data.unshift(resolutionData);
          this.dataSourceNew.next(data);
          this.notificationService.success(this.messagesService.getMessage());
          this.store.dispatch(ResolutionsActions.addItemAction({ payload: Object.assign({}, resolutionData) }));
        },
        error: (error) => {
          this.error(error);
        },
      });
    } else {
      this.resolutionService.update(resolution.index, resolution).pipe(takeUntil(this.subject)).subscribe({
        next: (resolutionData) => {
          dataItem.name = resolutionData.name;
          const data = this.dataSourceNew.value as GridDataResult;
          this.dataSourceNew.next(data);
          this.notificationService.success(this.messagesService.getMessage());
          this.store.dispatch(ResolutionsActions.updateItemAction({ payload: resolutionData }));
        },
        error: (error) => {
          this.error(error);
        },
      });
    }
    sender.closeRow(rowIndex);
  }

  // Eintra editieren
  public editHandler({ sender, rowIndex, dataItem }: EditEvent): void {
    //this.map = new Map();
    this.formGroup = new FormGroup({
      name: new FormControl(dataItem.name, [
        Validators.required,
        Validators.minLength(4),
      ]),
    });
    this.map.set(rowIndex, this.formGroup)
    sender.editRow(rowIndex, this.formGroup);
  }

  //Einen Eintrag entfernen
  removeHandler({ sender, rowIndex, dataItem }: RemoveEvent) {
    const resolution: Resolution = dataItem;
    const dialogRef: DialogRef = this.dialogService.open({
      content: DeleteInfoDialog,
    });
    const dataInfo = dialogRef.content.instance as DeleteInfoDialog;
    dataInfo.data = resolution;
    dialogRef.result.subscribe((dialogResult) => {
      if (dialogResult == 'Yes') {
        this.resolutionService.delete(resolution.index).pipe(takeUntil(this.subject)).subscribe({
          next: (resolutionData) => {
            const data = this.dataSourceNew.value as GridDataResult;
            //data.data.splice(rowIndex, 1);
            data.data.forEach((item, index) => {
              if (item.index === resolution.index) { data.data.splice(index, 1); }
            });
            this.dataSourceNew.next(data);
            this.notificationService.success(this.messagesService.getMessage());
            this.store.dispatch(ResolutionsActions.deleteItemAction({ payload: resolution }));
          },
          error: (error) => {
            this.error(error);
          },
        });
      }
    });
  }

  public cancelHandler({ sender, rowIndex }: CancelEvent): void {
    sender.closeRow(rowIndex);
    this.formGroup = null;
  }
  public rowCallback = (context: RowClassArgs) => {
    const isEven = context.index % 2 == 0;
    return {
      even: isEven,
      odd: !isEven,
    };
  };

  ngOnDestroy(): void {
    this.subject.next(null);
    this.subject.complete();
  }
  
  error(error: any) {
    //const title = this.messagesService.getErrorMessage(Number(error?.message));
    this.notificationService.error(error?.message);
  }
}
