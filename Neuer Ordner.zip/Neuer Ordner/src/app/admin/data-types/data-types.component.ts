import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { NotificationService } from 'src/app/services/notification.service';
import { DialogRef, DialogService } from '@progress/kendo-angular-dialog';
import { State } from '@progress/kendo-data-query';
import { BehaviorSubject, Subject, takeUntil } from 'rxjs';
import { AddEvent, CancelEvent, DataStateChangeEvent, EditEvent, GridDataResult, RemoveEvent, RowClassArgs, SaveEvent, } from '@progress/kendo-angular-grid';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import * as DataTypesActions from '../../store/actions/dataType.action';
import { DataType } from '../../models/entities';
import { DeleteInfoDialog } from 'src/app/shared/dialogs/delete-info-dialog/delete-info-dialog.component';
import { DataTypeService } from 'src/app/services/resource.service';
import { MessagesService } from 'src/app/services/messages.service';
import { slideInAnimation } from 'src/app/shared/animations';

@Component({
  selector: 'app-data-types',
  templateUrl: './data-types.component.html',
  styleUrls: ['./data-types.component.css'],
  animations: [slideInAnimation]
})
export class DataTypesComponent implements OnInit{

  private subject: Subject<any> = new Subject();
  dataSourceNew: BehaviorSubject<GridDataResult> = new BehaviorSubject(null);
  formGroup: FormGroup;
  loading = new BehaviorSubject<boolean>(false);
  state: State = { skip: 0, take: 50, group: [], filter: { filters: [], logic: 'and' }, sort: [{ field: "name", dir: "asc" }], };
  constructor(
    private messagesService: MessagesService,
    private dataTypeService: DataTypeService,
    private store: Store,
    private dialogService: DialogService,
    private notificationService: NotificationService) { }

  ngOnInit(): void {
    this.getDataTypes();
  }

  dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.getDataTypes();
  }

  getDataTypes(): void {
    this.loading.next(true);
    this.dataTypeService.findItemsByParamsDataSource(this.state, null).pipe(takeUntil(this.subject)).subscribe((data) => {
      this.dataSourceNew.next(data);
      this.loading.next(false);
    });
  }
  //neuen Eintrag erstellen
  addHandler({ sender, dataItem, rowIndex }: AddEvent): void {
    this.formGroup = new FormGroup({
      name: new FormControl('', [Validators.required, Validators.minLength(4)]),
    });
    sender.addRow(this.formGroup);
  }

  //Einen (neuen) Eintrag erstellen/editieren
  public saveHandler({ sender, rowIndex, dataItem, isNew }: SaveEvent): void {
    const dataType = Object.assign({}, dataItem) as DataType;
    dataType.name = this.formGroup.get('name').value;
    if (isNew) {
      this.dataTypeService.save(dataType).pipe(takeUntil(this.subject)).subscribe({
        next: (dataTypeData) => {
          const data = this.dataSourceNew.value as GridDataResult;
          data.data.unshift(dataTypeData);
          this.dataSourceNew.next(data);
          this.notificationService.success(this.messagesService.getMessage());
          this.store.dispatch(DataTypesActions.addItemAction({ payload: Object.assign({}, dataTypeData) }));
        },
        error: (error) => {
          this.error(error);
        },
      });
    } else {
      this.dataTypeService.update(dataType.index, dataType).pipe(takeUntil(this.subject)).subscribe({
        next: (dataTypeData) => {
          dataItem.name = dataTypeData.name;
          const data = this.dataSourceNew.value as GridDataResult;
          this.dataSourceNew.next(data);
          this.notificationService.success(this.messagesService.getMessage());
          this.store.dispatch(DataTypesActions.updateItemAction({ payload: dataTypeData }));
        },
        error: (error) => {
          this.error(error);
        },
      });
    }
    sender.closeRow(rowIndex);
  }

  public editHandler({ sender, rowIndex, dataItem }: EditEvent): void {
    this.formGroup = new FormGroup({
      name: new FormControl(dataItem.name, [
        Validators.required,
        Validators.minLength(4),
      ]),
    });

    sender.editRow(rowIndex, this.formGroup);
  }

  //Einen Eintrag entfernen
  removeHandler({ sender, rowIndex, dataItem }: RemoveEvent) {
    const dataType: DataType = dataItem;
    const dialogRef: DialogRef = this.dialogService.open({
      content: DeleteInfoDialog,
    });
    const dataInfo = dialogRef.content.instance as DeleteInfoDialog;
    dataInfo.data = dataType;
    dialogRef.result.subscribe((dialogResult) => {
      if (dialogResult == 'Yes') {
        this.dataTypeService.delete(dataType.index).pipe(takeUntil(this.subject)).subscribe({
          next: (dataTypeData) => {
            const data = this.dataSourceNew.value as GridDataResult;
            data.data.forEach((item, index) => {
              if (item.index === dataType.index) { data.data.splice(index, 1); }
            });
            this.dataSourceNew.next(data);
            this.notificationService.success(this.messagesService.getMessage());
            this.store.dispatch(DataTypesActions.deleteItemAction({ payload: dataType }));
          },
          error: (error) => {
            this.error(error);
          },
        });
      }
    });
  }

  public cancelHandler({ sender, rowIndex }: CancelEvent): void {
    sender.closeRow(rowIndex);
    this.formGroup = null;
  }
  public rowCallback = (context: RowClassArgs) => {
    const isEven = context.index % 2 == 0;
    return {
      even: isEven,
      odd: !isEven,
    };
  };

  ngOnDestroy(): void {
    this.subject.next(null);
    this.subject.complete();
  }

  error(error: any) {
    //const title = this.messagesService.getErrorMessage(Number(error?.message));
    this.notificationService.error(error?.message);
  }
}
