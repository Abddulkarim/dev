import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataStateChangeEvent, GridDataResult, RowClassArgs } from '@progress/kendo-angular-grid';
import { State } from '@progress/kendo-data-query';
import { BehaviorSubject, Subject, takeUntil } from 'rxjs';
import { Device, Warehouse } from 'src/app/models/entities';
import { CurrentDeviceService } from 'src/app/services/currentDevice.service';
import { CategoryService, DeviceService } from 'src/app/services/resource.service';
import Utils from 'src/app/shared/utils';

@Component({
  selector: 'app-scheme-release-device',
  templateUrl: './releases.component.html',
  styleUrls: ['./releases.component.css'],
})
export class ReleasesComponent implements OnInit {
  private subject: Subject<any> = new Subject();
  public expandedDetailKeys: number[] = [0];
  selectedRowArray: number[] = [];
  dataSourceNew: BehaviorSubject<GridDataResult> = new BehaviorSubject(null);
  public state: State = { skip: 0, group: [], filter: { filters: [], logic: 'and' }, sort: [{ field: "name", dir: "asc" }], };
  public loading = new BehaviorSubject<boolean>(false);
  categories: Warehouse[];
  constructor(
    private deviceService: DeviceService,
    private currentDeviceService: CurrentDeviceService,
    private router: Router,
    private categoryService: CategoryService) { }

  ngOnInit(): void {
    this.expandedDetailKeys.push(this.currentDeviceService.deviceValue.value);
    this.selectedRowArray.push(this.currentDeviceService.deviceValue.value);
    this.categoryService.findAll().subscribe((data) => { this.categories = Utils.sort(data) });
    this.getDevices();
  }


  dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.expandedDetailKeys=[];
    this.getDevices();
    this.selectedRowArray= [];
  }

  getDevices(): void {
    let map = { onlyReleasedDevices: false };
    this.loading.next(true);
    this.deviceService.findItemsByParamsDataSource(this.state, map).pipe(takeUntil(this.subject)).subscribe((data) => {
      this.dataSourceNew.next(data);
      this.loading.next(false);
      this.setSelectedRow();
    });
  }

  //Navigattion zu projekte/Geräte
  navigateTo(warehouse: Warehouse) {
    if (warehouse?.hasProject) this.router.navigate(['../admin/projects']);
    else this.router.navigate(['../admin/devices']);
  }

  public expandDetailsBy = (dataItem: Device): number => {
    return dataItem.index;
  }

  public rowCallback = (context: RowClassArgs) => {
    const isEven = context.index % 2 == 0;
    return { even: isEven, odd: !isEven };
  }


  ngOnDestroy(): void {
    this.subject.next(null);
    this.subject.complete();
  }

  setSelectedRow() {
    setTimeout(() => {
      const scrollTo = document.querySelector(".k-selected");
      if (scrollTo) {
        scrollTo.scrollIntoView();
      }
    });
  }
}
