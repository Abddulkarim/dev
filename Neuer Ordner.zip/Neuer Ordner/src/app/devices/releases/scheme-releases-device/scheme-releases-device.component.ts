import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { State } from '@progress/kendo-data-query';
import { DialogRef, DialogService } from '@progress/kendo-angular-dialog';
import { AddEvent, CancelEvent, DataStateChangeEvent, EditEvent, GridComponent, GridDataResult, RemoveEvent, RowClassArgs, SaveEvent, } from '@progress/kendo-angular-grid';
import { BehaviorSubject, Subject, takeUntil } from 'rxjs';
import { Warehouse, Device, SchemeRelease, } from 'src/app/models/entities';
import { NotificationService } from 'src/app/services/notification.service';
import { ParameterGroupService, SchemeReleaseService } from 'src/app/services/resource.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MessagesService } from 'src/app/services/messages.service';
import { DeleteInfoDialog } from 'src/app/shared/dialogs/delete-info-dialog/delete-info-dialog.component';
import { CurrentDeviceService } from 'src/app/services/currentDevice.service';
import { Store } from '@ngrx/store';

@Component({
  selector: 'p3-scheme-release',
  templateUrl: './scheme-releases-device.component.html',
  styleUrls: ['./scheme-releases-device.component.css'],
})
export class SchemeReleasesDeviceComponent implements OnInit {
  private subject: Subject<any> = new Subject();
  @Input() public deviceData: Device;
  @ViewChild(GridComponent) grid: GridComponent;
  dataSourceNew: BehaviorSubject<GridDataResult | SchemeRelease[]> = new BehaviorSubject(null);
  formGroup: FormGroup;
  isLoading = false;
  state: State = { skip: 0, group: [], filter: { filters: [], logic: 'and' }, sort: [], };
  evaluations: { index: number; evaluation: string; versionAuto: string }[] = [];
  constructor(
    private messagesService: MessagesService,
    private schemeReleaseService: SchemeReleaseService,
    private router: Router,
    private store: Store,
    private route: ActivatedRoute,
    private notificationService: NotificationService,
    private currentDeviceService: CurrentDeviceService,
    private parameterGroupService: ParameterGroupService,
    private dialogService: DialogService) { }

  ngOnInit(): void {
    this.getSchemeReleases();
  }

  dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.getSchemeReleases();
  }

  getSchemeReleases(): void {
    this.isLoading = true;
    this.schemeReleaseService.findItemsByParamsDataSource(this.state, { deviceIndex: this.deviceData.index, }).pipe(takeUntil(this.subject)).subscribe((data) => {
      this.dataSourceNew.next(data);
      this.isLoading = false;
    });
  }

  navigateTo(schemeRelease: SchemeRelease) {
    // this.router.navigate(['/release-assignment', id]);
    //this.router.navigate(['release-assignment',  id]);
    this.currentDeviceService.nextValue(this.deviceData.index);
    this.router.navigate(['../devices/schemerelease', schemeRelease.index], { relativeTo: this.route });
    //this.router.navigateByUrl(`/release-assignment/${id}`);
    //this.getQLFile(schemeRelease.index);
  }

  //neuen Eintrag erstellen
  addHandler({ sender, dataItem, rowIndex }: AddEvent): void {
    if (this.deviceData.isVisulink) {
      this.formGroup = new FormGroup({
        project: new FormGroup({
          projectName: new FormControl('', [Validators.required]),
          projectId: new FormControl('', [Validators.required])
        }),
        releaseType: new FormControl({ index: 1, name: 'Visulink' }),
        device: new FormControl(this.deviceData, [Validators.required]),
        versionMajor: new FormControl(1, [Validators.required]),
        versionMinor: new FormControl(0, [Validators.required]),
        versionRevision: new FormControl(0, [Validators.required]),
        evaluable: new FormControl(0, [Validators.required]),
      });
    } else {
      this.formGroup = new FormGroup({
        releaseType: new FormControl({ index: 2, name: 'NONE' }),
        device: new FormControl(this.deviceData, [Validators.required]),
        versionMajor: new FormControl(1, [Validators.required]),
        versionMinor: new FormControl(0, [Validators.required]),
        versionRevision: new FormControl(0, [Validators.required]),
        evaluable: new FormControl(0, [Validators.required]),
      });
    }
    //(<FormGroup> this.formGroup .controls['project']).controls['projectName'].value;
    sender.addRow(this.formGroup);
  }

  //Einen (neuen) Eintrag erstellen/editieren
  public saveHandler({ sender, rowIndex, dataItem, isNew }: SaveEvent): void {
    const schemeRelease = Object.assign({}, dataItem) as SchemeRelease;
    schemeRelease.versionMajor = this.formGroup.get('versionMajor').value;
    schemeRelease.versionMinor = this.formGroup.get('versionMinor').value;
    schemeRelease.versionRevision = this.formGroup.get('versionRevision').value;
    schemeRelease.evaluable = schemeRelease.evaluable ? 1 : 0;
    schemeRelease.device = this.deviceData;
    if (isNew) {
      this.schemeReleaseService.save(schemeRelease).pipe(takeUntil(this.subject)).subscribe({
        next: (schemeReleaseData) => {
          const data = this.dataSourceNew.value as GridDataResult;
          data.data.unshift(schemeReleaseData);
          this.dataSourceNew.next(data);
          this.notificationService.success(this.messagesService.getMessage());
        },
        error: (error) => {
          this.error(error);
        },
      });
    } else {
      this.schemeReleaseService.update(schemeRelease.index, schemeRelease).pipe(takeUntil(this.subject)).subscribe({
        next: (schemeReleaseData) => {
          const data = this.dataSourceNew.value as GridDataResult;
          data.data[rowIndex] = { ...data.data[rowIndex], ...schemeReleaseData, };
          this.dataSourceNew.next(data);
          this.notificationService.success(this.messagesService.getMessage());
        },
        error: (error) => {
          this.error(error);
        },
      });
    }
    sender.closeRow(rowIndex);
  }

  public editHandler({ sender, rowIndex, dataItem }: EditEvent): void {
    this.formGroup = new FormGroup({
      releaseType: new FormControl(dataItem.releaseType),
      versionMajor: new FormControl(dataItem.versionMajor, [Validators.required,]),
      versionMinor: new FormControl(dataItem.versionMinor, [Validators.required,]),
      versionRevision: new FormControl(dataItem.versionRevision, [Validators.required,]),
      evaluable: new FormControl(dataItem.evaluable),
    });
    sender.editRow(rowIndex, this.formGroup);
  }

  //Einen Eintrag entfernen
  removeHandler({ sender, rowIndex, dataItem }: RemoveEvent) {
    const category: Warehouse = dataItem;
    const dialogRef: DialogRef = this.dialogService.open({ content: DeleteInfoDialog });
    const dataInfo = dialogRef.content.instance as DeleteInfoDialog;
    dataInfo.data = category;
    dialogRef.result.subscribe((dialogResult) => {
      if (dialogResult == 'Yes') {
        this.schemeReleaseService.delete(category.index).pipe(takeUntil(this.subject)).subscribe({
          next: (data) => {
            this.getSchemeReleases();
            this.notificationService.success(this.messagesService.getMessage());
          },
          error: (error) => {
            this.error(error);
          },
        });
      }
    });
  }

  public cancelHandler({ sender, rowIndex }: CancelEvent): void {
    sender.closeRow(rowIndex);
    this.formGroup = null;
  }

  public toggle(dataItem: any, field: string): void {
    dataItem[field] = !dataItem[field];
  }

  public isHidden(columnName: string): boolean {
    return columnName === 'NONE';
  }

  evaluationTrackByFn = (index: number, item: any) => item.evaluation;
  getEvaluations(index: number, schemeRelease: SchemeRelease): { index: number; evaluation: string; versionAuto: string }[] {
    const evaluations: { index: number; evaluation: string; versionAuto: string; }[] = [];
    schemeRelease?.evaluationVersions?.forEach((ev) => {
      if (evaluations.findIndex((i) => i.index === ev.evaluationIndex) < 0) {
        const version = schemeRelease?.evaluationVersions.filter((i) => i.evaluationIndex === ev.evaluationIndex).map((i) => i.versionAuto).join('\n');
        evaluations.push({ index: ev.evaluationIndex, evaluation: ev.evaluationName, versionAuto: version, });
      }
    });
    return evaluations;
  }

  public expandRow(index: number, dataItem: any) {
    if (dataItem.isRowExpanded === undefined) {
      dataItem.isRowExpanded = false;
    }
    dataItem.isRowExpanded ? this.grid.collapseRow(index) : this.grid.expandRow(index);
    dataItem.isRowExpanded = !dataItem.isRowExpanded;
  }

  public rowCallback = (context: RowClassArgs) => {
    const isEven = context.index % 2 == 0;
    return {
      even: isEven,
      odd: !isEven,
    };
  }

  ngOnDestroy(): void {
    this.subject.next(null);
    this.subject.complete();
  }

  error(error: any) {
    //const title = this.messagesService.getErrorMessage(Number(error?.message));
    this.notificationService.error(error?.message);
  }
}
