import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-devices',
  templateUrl: './devices.component.html',
  styleUrls: ['./devices.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DevicesComponent implements OnInit {
  routes = [
    { link: 'schemerelease', label: 'Regelschema-Freigaben' },
    { link: 'release-assignment', label: 'Quicklink-Zuordnung' },
  ];
  constructor(public router: Router) {}

  ngOnInit(): void {}

  public onTabSelect(e: any) {
    let route = this.routes[e.index];
    this.router.navigate(['releases/' + route.link]);
  }

  public isRouteSelected(route: string): boolean {
    return this.router.url.endsWith(route);
  }

}
