import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DevicesRoutingModule } from './devices-routing.module';
import { DevicesComponent } from './devices.component';
import { QuicklinkAssignmentsComponent } from './release-assignment/assignment.component';
import { SignalParameterComponent } from './release-assignment/signal-parameter/signal-parameter.component';
import { SchemeReleasesDeviceComponent } from './releases/scheme-releases-device/scheme-releases-device.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../shared/shared.module';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { ReleasesComponent } from './releases/releases.component';

@NgModule({
  declarations: [
    ReleasesComponent,
    DevicesComponent,
    QuicklinkAssignmentsComponent,
    SignalParameterComponent,
    SchemeReleasesDeviceComponent,
  ],
  imports: [
    CommonModule,
    DevicesRoutingModule,
    DateInputsModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
  ]
})
export class SchemeReleasesModule { }
