import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DevicesComponent } from './devices.component';
import { QuicklinkAssignmentsComponent } from './release-assignment/assignment.component';

import { ReleasesComponent } from './releases/releases.component';
import { AuthGuard } from '../services/authGuard';

const routes: Routes = [
  {
    path: '',component: DevicesComponent,
    children: [
      {path: '',redirectTo: 'devices',pathMatch: 'full'},
      {path: '',component: ReleasesComponent,data: { title: 'de.menu.schemeRelease' },canActivate:[AuthGuard]},
      {path: 'schemerelease/:id',component: QuicklinkAssignmentsComponent,data: { title: 'de.menu.assignment' },canActivate:[AuthGuard]},
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DevicesRoutingModule { }
