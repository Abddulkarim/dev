import { AfterViewInit, ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { Store } from '@ngrx/store';
import { GridComponent, GridDataResult } from '@progress/kendo-angular-grid';
import { FileInfo, FileRestrictions } from '@progress/kendo-angular-upload';
import { BehaviorSubject, Subject, takeUntil } from 'rxjs';
import { Device, Quicklink, SchemeRelease, SignalParameter, Warehouse } from 'src/app/models/entities';
import { DeviceService, SchemeReleaseService, SignalParameterService, } from 'src/app/services/resource.service';
import * as QuicklinkActions from '../../store/actions/quicklink.actions';
import { NotificationService } from 'src/app/services/notification.service';
import { MessagesService } from 'src/app/services/messages.service';
import { selectQuicklink } from 'src/app/store/selectors/quicklink.selector';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-assignment',
  templateUrl: './assignment.component.html',
  styleUrls: ['./assignment.component.css'],
})
export class QuicklinkAssignmentsComponent implements OnInit, AfterViewInit {
  private subject: Subject<any> = new Subject();
  @ViewChild(GridComponent) grid: GridComponent;
  deviceData: Device;
  schemeRelease: SchemeRelease = undefined;
  dataSourceNew: BehaviorSubject<GridDataResult | SchemeRelease[]> = new BehaviorSubject(null);
  loading = new BehaviorSubject<boolean>(false);
  filesNames: Array<String> = [];
  file: { [key: string]: string | number };
  quicklinks: Quicklink[] = [];
  schemeReleaseIndex: number = null;
  evaluationVersionData: Array<{ name: string; index: number }>;
  constructor(
    public messagesService: MessagesService,
    private store: Store,
    private router: Router,
    private route: ActivatedRoute,
    private schemeReleaseService: SchemeReleaseService,
    private signalParameterService: SignalParameterService,
    private deviceService: DeviceService,
    private notificationService: NotificationService,
    private changeDetectorRefs: ChangeDetectorRef,
  ) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.schemeReleaseIndex = +params['id'];
    });
    this.getSchemeRelease();
    //this.schemeRelease = this.location.getState() as SchemeRelease;
    this.store.select(selectQuicklink).subscribe((data: Quicklink[]) => {
      this.quicklinks = JSON.parse(JSON.stringify(data));
    });
  }

  ngAfterViewInit(): void {
    this.grid.expandRow(0);
    this.getQLsFile(this.schemeReleaseIndex);
  }

  getSchemeRelease(): void {
    this.loading.next(true);
    this.schemeReleaseService.findOne(this.schemeReleaseIndex).pipe(takeUntil(this.subject)).subscribe((data) => {
      this.schemeRelease = data;
      this.deviceService.findOne(data.deviceIndex).pipe(takeUntil(this.subject)).subscribe((devicedData) => {
        this.deviceData = devicedData;
        this.dataSourceNew.next([data]);
        this.loading.next(false);
      });
    });
  }

  // Quicklinks-Datei auswählen und in DB speichern
  public selectQLsFileAndSave(ev: any, schemeRelease: SchemeRelease): void {
    this.loading.next(true);
    ev.files.forEach((file: FileInfo) => {
      let existFileName = this.filesNames.find((f) => f == file.name);
      if (!existFileName)
        if (file.rawFile) {
          // if a file with the same name doesn't exist{
          const fileReader = new FileReader();
          fileReader.readAsText(file.rawFile, 'UTF-8');
          fileReader.onload = () => {
            this.schemeReleaseService.saveOrUpdateFile(schemeRelease.index, JSON.parse(fileReader.result as string)).pipe(takeUntil(this.subject)).subscribe({
              next: (_data: any) => {
                this.store.dispatch(QuicklinkActions.loadItemsAction({ payload: JSON.parse(fileReader.result as string), }));
                schemeRelease.qlFile = true;
                this.notificationService.success(this.messagesService.getMessage());
              },
              error: (error) => {
                this.error(error);
              },
              complete: () => { this.loading.next(false); },
            });
          };
          fileReader.onerror = (error: any) => {
            this.loading.next(false);
            this.error(error);
          };
        }
    });
  }

  //lädet die Quicklinks-Datei
  getQLsFile(schemeReleaseIndex: number): void {
    this.schemeReleaseService.findFileBySchemerelease(schemeReleaseIndex).pipe(takeUntil(this.subject)).subscribe({
      next: (data: any) => {
        if (data != null) {
          this.store.dispatch(QuicklinkActions.loadItemsAction({ payload: JSON.parse(data) }));
        }
        else {
          this.store.dispatch(QuicklinkActions.removeItemsAction());
        }
      },
      error: (error) => {
        this.error(error);
      },
    });
  }

  fileRestrictions: FileRestrictions = {
    allowedExtensions: ['.json'],
    maxFileSize: 5000000,
  };

  //Quicklinks laden und checken
  checkQLs(schemeRelease: SchemeRelease) {
    this.loading.next(true);
    this.schemeReleaseService.findSignalParametersBySchemeRelease(schemeRelease.index).pipe(takeUntil(this.subject)).subscribe((data: SignalParameter[]) => {
      data.forEach((currentValue: SignalParameter, index: number) => {
        currentValue.quickLinkExists = false;
        this.quicklinks.find((quicklink) => {
          if (quicklink.quicklinkId.trim() === currentValue.quicklinkAuto.trim()) {
            currentValue.quickLinkExists = true;
          }
        });
      });
      this.signalParameterService.saveListUpdate(data).pipe(takeUntil(this.subject)).subscribe({
        next: (data: any) => {
          // this.notificationService.success(this.messagesService.getMessage());
        },
        error: (error) => {
          this.error(error);
        },
        complete: () => {
          this.grid.collapseRow(0);
          this.changeDetectorRefs.detectChanges();
          ; this.loading.next(false);
          this.grid.expandRow(0);
        },
      });
    });
  }

  //Navigattion zu projekte/Geräte
  navigateTo(warehouse: Warehouse) {
    if (warehouse?.hasProject) this.router.navigate(['../admin/projects']);
    else this.router.navigate(['../admin/devices']);
  }

  // Nicht gebrauchte Daten zerstören
  ngOnDestroy(): void {
    this.subject.next(null);
    this.subject.complete();
  }

  // Code-Fehler konvertieren und anzeigen
  error(error: any) {
    //const title = this.messagesService.getErrorMessage(Number(error?.message));
    this.notificationService.error(error?.message);
  }

}