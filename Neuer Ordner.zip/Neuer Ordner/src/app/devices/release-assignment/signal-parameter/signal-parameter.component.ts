import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import { DialogRef, DialogService } from '@progress/kendo-angular-dialog';
import { CancelEvent, ColumnVisibilityChangeEvent, DataStateChangeEvent, EditEvent, GridComponent, GroupKey, GroupRowArgs, RemoveEvent, RowClassArgs, SaveEvent, SelectableSettings } from '@progress/kendo-angular-grid';
import { TextBoxComponent } from "@progress/kendo-angular-inputs";
import { GroupDescriptor, GroupResult, State } from '@progress/kendo-data-query';
import { BehaviorSubject, Subject, takeUntil } from 'rxjs';
import { groupBy } from '@progress/kendo-data-query';
import { Warehouse, DataType, Device, Evaluation, Parameter, ParameterGroup, Quicklink, Resolution, SchemeRelease, SignalParameter, Type, Unit, IgnoreParameter } from 'src/app/models/entities';
import { QueryFilterOperator, QueryParams } from 'src/app/models/query.model';
import { NotificationService } from 'src/app/services/notification.service';
import { CategoryService, DataTypeService, EvaluationService, ParameterGroupService, ResolutionService, SchemeReleaseService, SignalParameterService, TypeService, UnitService } from 'src/app/services/resource.service';
import { findQuiclink, selectQuicklink } from 'src/app/store/selectors/quicklink.selector';
import * as ColumnsActions from '../../../store/actions/columns.action';
import { selectColumns } from '../../../store/selectors/columns.selector';
import { TooltipDirective } from '@progress/kendo-angular-tooltip';
import { HttpParams } from '@angular/common/http';
import { MessagesService } from 'src/app/services/messages.service';
import { DeleteInfoDialog } from 'src/app/shared/dialogs/delete-info-dialog/delete-info-dialog.component';
import { SignalParameterDialog } from 'src/app/shared/dialogs/signal-parameter-dialog/signal-parameter-dialog';
import Utils from 'src/app/shared/utils';
import { collapseAnimation, slideInAnimation } from 'src/app/shared/animations';
import { ContextMenuComponent } from '@progress/kendo-angular-menu';
import { MenuItems, menuItems1, menuItems2, menuItems3 } from 'src/app/shared/menu-items';
import { ContextmenuParameter } from 'src/app/shared/constants';
import { selectGrouping } from 'src/app/store/selectors/grouping.selector';
import * as GroupingActions from '../../../store/actions/grouping.action';
@Component({
  selector: 'app-signal-parameter',
  templateUrl: './signal-parameter.component.html',
  styleUrls: ['./signal-parameter.component.css'],
  animations: [collapseAnimation, slideInAnimation],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SignalParameterComponent implements OnInit {
  @ViewChild('gridmenu') public gridContextMenu: ContextMenuComponent | undefined;
  @ViewChild("grid") public grid: GridComponent;
  @ViewChild("pdfExportGrid") pdfExportGrid: GridComponent | undefined;
  @ViewChild("searchFor") searchFor: TextBoxComponent;
  @ViewChild("replaceWith") replaceWith: TextBoxComponent;
  @Input() public deviceData: Device;
  @Input() public schemeRelease: SchemeRelease;
  @ViewChild(TooltipDirective) public tooltipDir: TooltipDirective;
  subject: Subject<any> = new Subject();
  dataSourceNew: BehaviorSubject<GroupResult[] | SignalParameter[]> = new BehaviorSubject(null);
  loading = new BehaviorSubject<boolean>(false);
  qlComplet = new BehaviorSubject<boolean>(false);
  collapsed = true;
  categories: Warehouse[] = [];
  evaluations: Evaluation[] = [];
  evaluation: Evaluation = { index: 0, name: '' };
  category: Warehouse = { index: 0, name: '' };
  schemeReleaseVersions: SchemeRelease[] = [];
  selectedSchemeRelease: SchemeRelease;
  parameterGroupsOfSchemeRelease: ParameterGroup[] = [];
  selectedParameterGroups: any = [];
  onlyAssigned = false;
  modifiedSignalParameters: SignalParameter[] = [];
  resolutions: Resolution[] = [];
  units: Unit[] = [];
  dataTypes: DataType[] = [];
  types: Type[] = [];
  parameterGroups: ParameterGroup[] = [];
  parameterGroupsOfRelease: ParameterGroup[] = [];
  quicklink: Quicklink = { index: 0, text: '', mainGroupId: 1, group1Id: 1, group2Id: 1, parameterId: 1, quicklinkId: '' };
  mask = '00.0000.0000.0000';
  quicklinks: Quicklink[] = [];
  findQuicklinks: Quicklink[] = [];
  qlReplaceButtonDisabled = new BehaviorSubject<boolean>(true);
  state: State = { skip: 0, group: [], filter: { filters: [], logic: "and" }, sort: [], };
  formGroup: FormGroup;
  cateroryData: Array<Warehouse>;
  evaluationData: Array<Evaluation>;
  selectableSettings: SelectableSettings = { enabled: true, checkboxOnly: true };
  selectedDataItems1: SignalParameter[];
  selectedRowArray: SignalParameter[] = [];
  selectedDataItem: SignalParameter;
  menuItems: MenuItems[] = menuItems1;
  public autoCorrect: boolean = false;
  public statisticsOpened = false;
  expandedGroupKeys: Array<GroupKey> = [];
  showIgnoreParameters: boolean = false;
  public hiddenColumns: string[] = [];
  public parameterGrouping: any[] = [{field:"parameterGroup.name"}];
  public defaultParameterGroup: ParameterGroup;
  public ignoreParameter = IgnoreParameter;
  constructor(
    private messagesService: MessagesService,
    private store: Store,
    private categoryService: CategoryService,
    private evaluationService: EvaluationService,
    private resolutionService: ResolutionService,
    private unitService: UnitService,
    private dataTypeService: DataTypeService,
    private typeService: TypeService,
    private signalParameterService: SignalParameterService,
    private dialogService: DialogService,
    private parameterGroupService: ParameterGroupService,
    private schemeReleaseService: SchemeReleaseService,
    private notificationService: NotificationService,
    private changeDetectorRefs: ChangeDetectorRef,
  ) { }

  ngOnInit(): void {
    this.defaultParameterGroup = { "index": 0, "name": "Default" };
    this.store.select(selectColumns).subscribe((columnsData: string[]) => {this.hiddenColumns = JSON.parse(JSON.stringify(columnsData));});
    this.store.select(selectGrouping).subscribe((groupingData: string[]) => {
      this.parameterGrouping=[];
      groupingData.forEach((element:string) => {this.parameterGrouping.push({ field: element });});
      this.state.group=this.parameterGrouping;
    });
    this.resolutionService.findAll().subscribe((data) => { this.resolutions = Utils.sort(data) });
    this.unitService.findAll().subscribe((data) => { this.units = Utils.sort(data) });
    this.dataTypeService.findAll().subscribe((data) => { this.dataTypes = Utils.sort(data) });
    this.typeService.findAll().subscribe((data) => { this.types = Utils.sort(data) });
    this.categoryService.findAll().subscribe((data) => { this.cateroryData = this.categories = Utils.sort(data) });
    this.evaluationService.findAll().subscribe((data) => { this.evaluationData = this.evaluations = Utils.sort(data) });
    this.parameterGroupService.findAll().subscribe((data: any) => {
      this.parameterGroups = Utils.sort(data.data);
    }); //Bug
    this.findParameterGroupsBySchemeRelease(this.schemeRelease);
    this.findSchemeReleaseVersionsByProjectIndex(this.schemeRelease);
    this.store.select(selectQuicklink).subscribe((quicklinkData: Quicklink[]) => { this.quicklinks = JSON.parse(JSON.stringify(quicklinkData)); });

    this.getSignalParameters();
  }

  dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    if (state.group.length) {
      console.log('group also changed');
    }
    this.getSignalParameters();
  }

  //Daten laden
  getSignalParameters(): void {
    this.loading.next(true);

    let params: any = {};
    let indexes = this.category?.index != 0 ? this.category?.index : "";
    let tmpIndexes = "";
    if (this.deviceData?.warehouses?.length > 0) {
      tmpIndexes = this.deviceData?.warehouses.map((i) => i.index).join(',');
      indexes = indexes ? (indexes + "," + tmpIndexes) : tmpIndexes;
    }
    if (indexes)
      params = { onlyAssigned: this.onlyAssigned, showIgnoreParameters: this.showIgnoreParameters, parameterGroupIndex: this.defaultParameterGroup.index, evaluationIndex: this.evaluation?.index, categoryIndex: indexes };
    else
      params = { onlyAssigned: this.onlyAssigned, showIgnoreParameters: this.showIgnoreParameters, parameterGroupIndex: this.defaultParameterGroup.index, evaluationIndex: this.evaluation?.index };
    const stateTemp = Object.assign({}, this.state) as State;
    stateTemp.group = [];
    this.signalParameterService.findAssignableParameters(stateTemp, this.schemeRelease.index, params).pipe(takeUntil(this.subject)).subscribe(data => {
      let signalParameters: SignalParameter[] = [];
      let userData = new Map<number, Set<number>>();
      let parameterGroupsOfCurrentSchemeRelease = Object.assign([], this.parameterGroupsOfSchemeRelease) as ParameterGroup[];
      if (this.state?.group?.length) {
        parameterGroupsOfCurrentSchemeRelease.push(this.defaultParameterGroup);
      }
        data.data.forEach((signalParameter: SignalParameter, key: number) => {
          if (!signalParameter.quicklinkAuto && !signalParameter.schemeReleaseIndex && signalParameter?.parameterGroup === undefined) {
             parameterGroupsOfCurrentSchemeRelease.forEach((parameterGroupData: ParameterGroup) => {
              
              let signalParameterTemp = Object.assign({}, signalParameter) as SignalParameter;
              let parameterTemp = Object.assign({}, signalParameter.parameter) as Parameter;
              signalParameterTemp.parameterGroup = parameterGroupData;
              signalParameterTemp.parameter= parameterTemp;
              if( signalParameterTemp.parameterGroup===this.defaultParameterGroup){
                signalParameterTemp.parameter.ignore=IgnoreParameter.NONE;
              }
              const ignoreGroup = parameterTemp.ignoreParameterGroups.find((group) => group.index === parameterGroupData.index);
              let dataSet = userData.get(signalParameterTemp.parameterGroup.index);
              if (dataSet === undefined || !dataSet.has(signalParameterTemp.parameter.index)) {
                if (ignoreGroup===undefined) {
                  if(signalParameterTemp.parameter.ignore===IgnoreParameter.PRARAMTERGROUP){
                    signalParameterTemp.parameter.ignoreParameterGroups=[];
                    signalParameterTemp.parameter.ignore=IgnoreParameter.NONE;
                  }
                  signalParameters.push(signalParameterTemp);
                }else if(ignoreGroup && this.showIgnoreParameters){
                  signalParameters.push(signalParameterTemp);
                }
              }
            });
          } else {
            signalParameters.push(signalParameter);
            if (userData.has(signalParameter.parameterGroup.index)) {
              userData.get(signalParameter.parameterGroup.index).add(signalParameter.parameter.index);
            } else {
              let newDataSet = new Set<number>().add(signalParameter?.parameter?.index)
              userData.set(signalParameter.parameterGroup.index, newDataSet);
            }
          }
        });
        data.data = signalParameters;
        data.total = signalParameters.length;
      this.dataSourceNew.next(groupBy(data.data, this.state.group));
      this.loading.next(false);
      this.allData = this.allData.bind(this);
      this.selectedRowArray = [];
    });
  }

  // lädet die freigegebenen Versionen eines Projekts
  findSchemeReleaseVersionsByProjectIndex(schemeRelease: SchemeRelease) {
    let map = new Map().set("projectIndex", schemeRelease.project.index === undefined ? 0 : schemeRelease.project.index).set("deviceIndex", schemeRelease.deviceIndex);
    let queryParams = new QueryParams();
    let signalParameter: any[] = [{ field: "versionAuto", operator: QueryFilterOperator.IsNotEqualTo, value: schemeRelease.versionAuto }]
    queryParams.filter = signalParameter;
    this.schemeReleaseService.findItemsByParams(map, queryParams).pipe(takeUntil(this.subject)).subscribe((data: any) => {
      this.schemeReleaseVersions = data.data.length > 0 ? data.data : [];
    });
  }

  // Signalarametergruppen einer Freigabe kopieren
  copySignalParameterFrom() {
    this.schemeReleaseService.copySignalParameterFrom(this.schemeRelease?.index, this.selectedSchemeRelease?.index).pipe(takeUntil(this.subject)).subscribe({
      next: (parameterGroupData: SignalParameter[]) => {
        this.getSignalParameters();
        this.notificationService.success(this.messagesService.getMessage());
      },
      error: (error) => {
        this.error(error);
      },
      complete: () => { },
    });
  }
  public columnChange(e: ColumnVisibilityChangeEvent) {
    e.columns.forEach(element => {
      if (element.hidden) {
        console.log(element.cssClass.toString());
        this.store.dispatch(ColumnsActions.addItemAction({ payload: element.cssClass.toString()}));
      } else {
        this.store.dispatch(ColumnsActions.deleteItemAction({ payload: element.cssClass.toString() }));
      }
    });
  }
  // public valueChange(schemeRelease: SchemeRelease): void {
  //   this.selectedParameterGroups = [];
  //   if (schemeRelease != null && schemeRelease != undefined) {
  //     this.findParameterGroupsBySchemeRelease(schemeRelease);
  //   } else {
  //     this.parameterGroupsOfSchemeRelease = [];
  //     //this.onClick();
  //   }
  // }

  findParameterGroupsBySchemeRelease(schemeRelease: SchemeRelease): void {
    this.schemeReleaseService.findParameterGroupsBySchemeRelease(schemeRelease.index).pipe(takeUntil(this.subject)).subscribe((data: any) => {
      this.parameterGroupsOfSchemeRelease = data.data.length > 0 ? data.data : [];
      //this.onClick();
    });
  }

  handleCategoriesFilter(value: string) {
    this.cateroryData = this.categories.filter((s) => s.name.toLowerCase().indexOf(value.toLowerCase()) !== -1);
  }

  categoryChange(value: any) {
    if (value === undefined) {
      this.category = { index: 0, name: '' };
    }
  }

  handleEvaluationsFilter(value: string) {
    this.evaluationData = this.evaluations.filter((s) => s.name.toLowerCase().indexOf(value.toLowerCase()) !== -1);
  }

  evaluationChange(value: any) {
    if (value === undefined) {
      this.evaluation = { index: 0, name: '' };
    }
  }

  //Einen (neuen) Eintrag erstellen/editieren
  public saveHandler({ sender, rowIndex, dataItem, isNew }: SaveEvent): void {
    const signalParameter = Object.assign({}, dataItem) as SignalParameter;
    signalParameter.parameterGroup = this.formGroup.get('parameterGroup').value;
    this.prepareDataItem(signalParameter);
    if (signalParameter.schemeReleaseIndex === undefined) {
      signalParameter.schemeReleaseIndex = this.schemeRelease.index;
      const params = new HttpParams().set('parameterIndex', signalParameter?.parameter?.index);
      this.schemeReleaseService.saveSignalParameter(this.schemeRelease?.index, signalParameter, params).pipe(takeUntil(this.subject)).subscribe({
        next: (signalParameterData) => {
          dataItem.index = signalParameterData.index;
          dataItem.quicklinkAuto = signalParameterData.quicklinkAuto;
          //this.schemeRelease.signalParameters.push(signalParameterData);
          //dataItem= signalParameterData;
          this.findParameterGroupsBySchemeRelease(this.schemeRelease);
          this.getSignalParameters();
          this.notificationService.success(this.messagesService.getMessage());
        },
        error: (error) => {
          this.error(error);
        },
        complete: () => {
          this.quicklink = null;
        }
      });
    } else {
      dataItem.quickLinkExists = null;
      signalParameter.quickLinkExists = null;
      this.signalParameterService.update(dataItem.index, signalParameter).pipe(takeUntil(this.subject)).subscribe({
        next: (signalParameterData) => {
          this.modifiedSignalParameters = this.modifiedSignalParameters.filter(item => item.index !== dataItem.index);
          this.getSignalParameters();
          this.notificationService.success(this.messagesService.getMessage());
        },
        error: (error) => {
          this.error(error);
        },
        complete: () => {
          this.quicklink = null;
        }
      });
    }
    sender.closeRow(rowIndex);
  }

  prepareDataItem(dataItem: SignalParameter) {
    if (this.deviceData.isVisulink && this.schemeRelease.qlFile) {
      dataItem.qlMaingroupId = this.quicklink.mainGroupId;
      dataItem.qlGroup1Id = this.quicklink.group1Id;
      dataItem.qlGroup2Id = this.quicklink.group2Id;
      dataItem.qlParameterId = this.quicklink.parameterId;
      dataItem.quicklinkAuto = this.quicklink.quicklinkId;
    } else {
      dataItem.qlMaingroupId = this.quicklink.mainGroupId;
      dataItem.qlGroup1Id = this.quicklink.group1Id;
      dataItem.qlGroup2Id = this.quicklink.group2Id;
      dataItem.qlParameterId = this.quicklink.parameterId;
    }
  }

  // popup Fenster öffnen
  public onCellClick(e: any): void {
    this.selectedDataItem=e.dataItem;
    if(this.selectedDataItem?.quicklinkAuto){
      this.menuItems=menuItems1;
    }else if(!this.selectedDataItem?.quicklinkAuto &&this.selectedDataItem?.parameter.ignore==IgnoreParameter.SCHEMERELEASE){
      this.menuItems=menuItems2;
    }else if(!this.selectedDataItem?.quicklinkAuto &&this.selectedDataItem?.parameter.ignore==IgnoreParameter.PRARAMTERGROUP){
      this.menuItems=menuItems2;
    }else{
      this.menuItems=menuItems3;
    }
    if (this.selectedRowArray.length > 0 && e.type === 'contextmenu') {
      const originalEvent = e.originalEvent;
      originalEvent.preventDefault();
      this.gridContextMenu?.show({
        left: originalEvent.pageX,
        top: originalEvent.pageY,
      });
    }
  }

  // gibt die Objekte der selektierten Rows
  public selectBy(e: any) {
    return e.dataItem;
  }

  public onSelectionChange() {
    setTimeout(() => {
      this.selectedRowArray = [...this.selectedRowArray];
    });
  }

  // Signalparametere klonen oder Export Datein exportieren
  public onSelect(item: any): void {
    if (item.item.checkText === ContextmenuParameter.COPY && this.selectedRowArray.length > 0) {
      let cloneItems = JSON.parse(JSON.stringify(this.selectedRowArray));
      const dialogRef = this.dialogService.open({ content: SignalParameterDialog });
      const userInfo = dialogRef.content.instance as SignalParameterDialog;
      userInfo.items = cloneItems;
      userInfo.parameterGroups = this.parameterGroups;
      userInfo.parameterGroup = this.parameterGroups[0];
      userInfo.group = '__.__.__.__';
      userInfo.quicklinkNumber = 0;
      dialogRef.result.subscribe((data: any) => {
        if (data.text === 'Submit' && data.items) {
          this.cloneSignalParameters(data.items);
          this.findParameterGroupsBySchemeRelease(this.schemeRelease);
        }
      });
    } else if (item.item.checkText === ContextmenuParameter.EXCEL) {
      this.grid?.saveAsExcel();
    } else if (item.item.checkText === ContextmenuParameter.PDF) {
      this.pdfExportGrid?.saveAsPDF();
    } else if (item.item.checkText === ContextmenuParameter.DELETE) {
      this.removeSelected();
    } else if (item.item.checkText === ContextmenuParameter.RELEASE_IGNORE) {
      this.ignoreParameterInRelease(this.selectedDataItem.parameter.ignore==IgnoreParameter.NONE);
    } else if (item.item.checkText === ContextmenuParameter.PARAMETERGROUP_IGNORE) {
      this.ignoreParameterInGroups(this.selectedDataItem.parameter.ignore==IgnoreParameter.NONE);
    } else if (item.item.checkText === ContextmenuParameter.STATISTICS) {
      this.statisticsOpened = true;
    }
  }

  public statisticsClose() {
    this.statisticsOpened = false;
  }

  public editHandler({ sender, rowIndex, dataItem }: EditEvent): void {
    this.formGroup = new FormGroup({
      signalClass: new FormControl(0, [Validators.required]),
      signalUnit: new FormControl(0, [Validators.required]),
      sprachDBIndex: new FormControl(0, [Validators.required]),
      parameterGroup: new FormControl(dataItem.parameterGroup != undefined ? dataItem.parameterGroup : this.parameterGroups[0], [Validators.required]),
    });
    const signalParameter: SignalParameter = dataItem;
    signalParameter.parameterGroup = signalParameter.parameterGroup != undefined ? signalParameter.parameterGroup : this.parameterGroups[0];
    this.findQuicklinks = [];
    if (this.deviceData.isVisulink && this.schemeRelease.qlFile) {
      this.store.select(findQuiclink(signalParameter.quicklinkAuto)).pipe(takeUntil(this.subject)).subscribe((data: Quicklink) => {
        if (data) {
          this.quicklink = Object.assign({}, data);
          this.findQuicklinks.push(this.quicklink);
          this.qlComplet.next(true);
        } else {
          this.qlComplet.next(false);
          if (signalParameter.quicklinkAuto) {
            this.quicklink.quicklinkId = signalParameter.quicklinkAuto;
            this.quicklink.mainGroupId = signalParameter.qlMaingroupId;
            this.quicklink.group1Id = signalParameter.qlGroup1Id;
            this.quicklink.group2Id = signalParameter.qlGroup2Id;
            this.quicklink.parameterId = signalParameter.qlParameterId;
            this.findQuicklinks.push(this.quicklink);
          }
        }
      });
    } else {
      if (signalParameter.quicklinkAuto) {
        this.quicklink.quicklinkId = this.addSpace(signalParameter.qlMaingroupId.toString(), 2) +
          this.addSpace(signalParameter.qlGroup1Id.toString(), 4) +
          this.addSpace(signalParameter.qlGroup2Id.toString(), 4) +
          this.addSpace(signalParameter.qlParameterId.toString(), 4);
        this.quicklink.mainGroupId = signalParameter.qlMaingroupId;
        this.quicklink.group1Id = signalParameter.qlGroup1Id;
        this.quicklink.group2Id = signalParameter.qlGroup2Id;
        this.quicklink.parameterId = signalParameter.qlParameterId;
      }
    }
    sender.editRow(rowIndex, this.formGroup);
  }

  addSpace(text: string, count: number): string {
    let result = text;
    for (let i = 0; i < (count - text.length); i++) {
      result += ' ';
    }
    return result;
  }

  //Einen Eintrag entfernen
  removeHandler({ sender, rowIndex, dataItem }: RemoveEvent) {
    const signalParameter: SignalParameter = dataItem;
    const dialogRef: DialogRef = this.dialogService.open({ content: DeleteInfoDialog, });
    const dataInfo = dialogRef.content.instance as DeleteInfoDialog;
    dataInfo.data = signalParameter;
    dialogRef.result.subscribe((dialogResult) => {
      if (dialogResult == 'Yes') {
        this.signalParameterService.delete(signalParameter.index).pipe(takeUntil(this.subject)).subscribe({
          next: (signalParameterData) => {
            // const data = this.dataSourceNew.value as SignalParameter[];
            // data.splice(rowIndex, 1);
            // this.dataSourceNew.next(data);
            this.findParameterGroupsBySchemeRelease(this.schemeRelease);
            this.getSignalParameters();
            this.notificationService.success(this.messagesService.getMessage());
          },
          error: (error) => {
            this.error(error);
          },
        });
      }
    });
  }
  //Einen Eintrag entfernen
  removeSelected() {
    const dialogRef: DialogRef = this.dialogService.open({ content: DeleteInfoDialog, });
    dialogRef.result.subscribe((dialogResult) => {
      if (dialogResult == 'Yes') {
        this.signalParameterService.deleteList(this.selectedRowArray).pipe(takeUntil(this.subject)).subscribe({
          next: (signalParameterData) => {
            // const data = this.dataSourceNew.value as SignalParameter[];
            // data.splice(rowIndex, 1);
            // this.dataSourceNew.next(data);
            this.getSignalParameters();
            this.notificationService.success(this.messagesService.getMessage());
          },
          error: (error) => {
            this.error(error);
          },
        });
      }
    });
  }

  public cancelHandler({ sender, rowIndex, dataItem }: CancelEvent): void {
    if (dataItem.schemeReleaseIndex === undefined) {
      if (!this.state?.group?.length) {
         dataItem.parameterGroup = undefined;
      }
    }
    sender.closeRow(rowIndex);
    this.formGroup;
  }

  //speichert die SignalParameter einer anderen Version
  cloneSignalParameters(signalParameters: SignalParameter[]) {
    if (signalParameters !== undefined && signalParameters.length > 0) {
      const params = new HttpParams().set('parametergroupindex', signalParameters[0].parameterGroup.index);
      this.schemeReleaseService.cloneSignalParameter(this.schemeRelease?.index, signalParameters, params).pipe(takeUntil(this.subject)).subscribe({
        next: (data: SignalParameter[]) => {
          this.getSignalParameters();
          this.selectedRowArray = [];
          this.notificationService.success(this.messagesService.getMessage());
        },
        error: (error) => {
          this.error(error);
        },
        complete: () => { },
      });
    }
  }

  //updatet die Quicklinks der angepassten SignalParameter
  saveReplacedQLs() {
    const dataResult: GroupResult[] = this.dataSourceNew.value as GroupResult[];
    this.signalParameterService.saveListUpdate(this.modifiedSignalParameters).pipe(takeUntil(this.subject)).subscribe({
      next: (data) => {
        this.modifiedSignalParameters = [];
        this.getSignalParameters();
        this.notificationService.success(this.messagesService.getMessage());
      },
      error: (error) => {
        this.error(error);
      }
    });
  }
  //Einen Eintrag entfernen
  hiteSelected() {
    const dialogRef: DialogRef = this.dialogService.open({ content: DeleteInfoDialog, });
    dialogRef.result.subscribe((dialogResult) => {
      if (dialogResult == 'Yes') {
        this.signalParameterService.deleteList(this.selectedRowArray).pipe(takeUntil(this.subject)).subscribe({
          next: (signalParameterData) => {
            // const data = this.dataSourceNew.value as SignalParameter[];
            // data.splice(rowIndex, 1);
            // this.dataSourceNew.next(data);
            this.getSignalParameters();
            this.notificationService.success(this.messagesService.getMessage());
          },
          error: (error) => {
            this.error(error);
          },
        });
      }
    });
  }

  evaluationTrackByFn = (index: number, item: any) => item.evaluation;
  getEvaluations(parameter: Parameter): { index: number; evaluation: string; versionAuto: string; }[] {
    const evaluations: { index: number; evaluation: string; versionAuto: string; }[] = [];
    parameter?.evaluationVersions?.forEach(ev => {
      if (evaluations.findIndex(i => i.index === ev.evaluationIndex) < 0) {
        const version = parameter.evaluationVersions.filter(i => i.evaluationIndex === ev.evaluationIndex).map(i => i.versionAuto).join('\n');
        evaluations.push({ index: ev.evaluationIndex, evaluation: ev.evaluationName, versionAuto: version });
      }
    });
    return evaluations;
  }

  public replaceQLs() {
    const data = this.dataSourceNew.value as SignalParameter[];
    data.forEach((signal: SignalParameter) => {
      if (signal.quicklinkAuto.startsWith(this.searchFor?.value)) {
        let replaceWithResult = this.replaceWith?.value.split('.');
        let searchForResult = this.searchFor?.value.split('.');
        if (replaceWithResult.length === 4 &&
          (searchForResult[0] != null && signal.qlMaingroupId === Number(searchForResult[0])) &&
          (searchForResult[1] != null && signal.qlGroup1Id === Number(searchForResult[1])) &&
          (searchForResult[2] != null && signal.qlGroup2Id === Number(searchForResult[2])) &&
          (searchForResult[3] != null && signal.qlParameterId === Number(searchForResult[3]))) {
          signal.qlMaingroupId = Number(replaceWithResult[0]);
          signal.qlGroup1Id = Number(replaceWithResult[1]);
          signal.qlGroup2Id = Number(replaceWithResult[2]);
          signal.qlParameterId = Number(replaceWithResult[3]);
          signal.quicklinkAuto = signal.qlMaingroupId + "." + signal.qlGroup1Id + "." + signal.qlGroup2Id + "." + signal.qlParameterId;
          this.modifiedSignalParameters.push(signal);
        }
        if (replaceWithResult.length === 3 &&
          (searchForResult[0] != null && signal.qlMaingroupId === Number(searchForResult[0])) &&
          (searchForResult[1] != null && signal.qlGroup1Id === Number(searchForResult[1])) &&
          (searchForResult[2] != null && signal.qlGroup2Id === Number(searchForResult[2]))) {
          signal.qlMaingroupId = Number(replaceWithResult[0]);
          signal.qlGroup1Id = Number(replaceWithResult[1]);
          signal.qlGroup2Id = Number(replaceWithResult[2]);
          signal.quicklinkAuto = signal.qlMaingroupId + "." + signal.qlGroup1Id + "." + signal.qlGroup2Id + "." + signal.qlParameterId;
          this.modifiedSignalParameters.push(signal);
        }
        if (replaceWithResult.length === 2 &&
          (searchForResult[0] != null && signal.qlMaingroupId === Number(searchForResult[0])) &&
          (searchForResult[1] != null && signal.qlGroup1Id === Number(searchForResult[1]))) {
          signal.qlMaingroupId = Number(replaceWithResult[0]);
          signal.qlGroup1Id = Number(replaceWithResult[1]);
          signal.quicklinkAuto = signal.qlMaingroupId + "." + signal.qlGroup1Id + "." + signal.qlGroup2Id + "." + signal.qlParameterId;
          this.modifiedSignalParameters.push(signal);
        }
        if (replaceWithResult.length === 1 &&
          (searchForResult[0] != null && signal.qlMaingroupId === Number(searchForResult[0]))) {
          signal.qlMaingroupId = Number(replaceWithResult[0]);
          signal.quicklinkAuto = signal.qlMaingroupId + "." + signal.qlGroup1Id + "." + signal.qlGroup2Id + "." + signal.qlParameterId;
          this.modifiedSignalParameters.push(signal);
        }
        signal.quickLinkExists = false;
        this.quicklinks.find((quicklink) => {
          if (quicklink.quicklinkId.trim() === signal.quicklinkAuto.trim()) {
            signal.quickLinkExists = true;
          }
        });
      }
    });
    this.dataSourceNew.next(data);
  }

  onchangeValue() {
    if (this.replaceWith != undefined && this.replaceWith.value != null && this.searchFor != undefined && this.searchFor.value != null) {
      this.replaceWith.value = this.replaceWith.value.trim();
      this.searchFor.value = this.searchFor.value.trim()
      let replaceWithResult = this.replaceWith?.value?.split('.');
      let searchForResult = this.searchFor?.value?.split('.');
      if (replaceWithResult?.length === searchForResult?.length && this.isArrayEmpy(searchForResult) && this.isArrayEmpy(replaceWithResult)) {
        this.qlReplaceButtonDisabled.next(false);
      } else {
        this.qlReplaceButtonDisabled.next(true);
      }
    }
  }

  isArrayEmpy(value: string[]): boolean {
    let result = true;
    value.forEach(data => {
      data = data.trim();
      if (!data && data.trim().length === 0) {
        result = false;
      }
    })
    return result;
  }

  qlValueChanged(value: any, isVl: boolean) {
    if (!isVl) {
      const result = value.split('.', 4);
      if (result.length === 4 && result[0].trim() && result[1].trim() && result[2].trim() && result[3].trim()) {
        this.quicklink.mainGroupId = Number(result[0].replace(/\s/g, ""));
        this.quicklink.group1Id = Number(result[1].replace(/\s/g, ""));
        this.quicklink.group2Id = Number(result[2].replace(/\s/g, ""));
        this.quicklink.parameterId = Number(result[3].replace(/\s/g, ""));
        this.qlComplet.next(true);
      } else {
        this.qlComplet.next(false);
      }
    } else if (value != null) {
      this.qlComplet.next(true);
    } else {
      this.qlComplet.next(false);
    }
  }

  public handleFilterChange(searchTerm: string): void {
    this.qlComplet.next(false);
    const normalizedQuery = searchTerm.toLowerCase();
    const filterExpression = (quicklink: Quicklink) =>
      quicklink.text.toLowerCase().includes(normalizedQuery) ||
      quicklink.quicklinkId.toLowerCase().includes(normalizedQuery) ||
      quicklink.unit?.toLowerCase().includes(normalizedQuery) ||
      quicklink.canOpenIndex?.toString().toLowerCase().includes(normalizedQuery);
    this.findQuicklinks = this.quicklinks.filter(filterExpression);
  }

  //Parameter in eine Freigabe /Parametergruppe ignoreiern
  ignoreParameterInRelease( ignore:boolean) {
    if (this.selectedRowArray !== undefined && this.selectedRowArray.length > 0) {
      let params = new HttpParams();
      params = new HttpParams().set('ignore', ignore);   
      this.schemeReleaseService.ignoreParameterInRelease(this.schemeRelease?.index, this.selectedRowArray, params).pipe(takeUntil(this.subject)).subscribe({
        next: (data: SignalParameter[]) => {
          this.getSignalParameters();
          this.selectedRowArray = [];
          this.notificationService.success(this.messagesService.getMessage());
        },
        error: (error) => {
          this.error(error);
        },
        complete: () => { },
      });
    }
  }

    //Parameter in eine Freigabe /Parametergruppe ignoreiern
    ignoreParameterInGroups(ignore:boolean) {
      if (this.selectedRowArray !== undefined && this.selectedRowArray.length > 0) {
        let params = new HttpParams();
        params = new HttpParams().set('ignore', ignore);
        this.schemeReleaseService.ignoreParameterInGroups(this.schemeRelease?.index, this.selectedRowArray, params).pipe(takeUntil(this.subject)).subscribe({
          next: (data: SignalParameter[]) => {
            this.getSignalParameters();
            this.selectedRowArray = [];
            this.notificationService.success(this.messagesService.getMessage());
          },
          error: (error) => {
            this.error(error);
          },
          complete: () => { },
        });
      }
    }

  public toggleGroup(rowArgs: GroupRowArgs): void {

    console.log(rowArgs);
  }
  public groupChange(groups: GroupDescriptor[]): void {
    this.parameterGrouping=[];
    this.store.dispatch(GroupingActions.removeItemsAction());
    groups.forEach(element => {
        console.log(element.field.toString());
        this.store.dispatch(GroupingActions.addItemAction({ payload: element.field}));
    });
    console.log(groups)
}
  public isSignalParameterModified(signalParameter: SignalParameter): boolean {
    return this.modifiedSignalParameters.findIndex(i => i.index === signalParameter.index) >= 0;
  }

  public isModifiedSignalParameExistInQL(signalParameter: SignalParameter): boolean {
    return this.modifiedSignalParameters.findIndex(data => data.index === signalParameter.index && data.quickLinkExists) >= 0;
  }

  public expandRow(index: number, dataItem: SignalParameter) {
    if (dataItem.isRowExpanded === undefined) {
      dataItem.isRowExpanded = false;
    }
    dataItem.isRowExpanded ? this.grid.collapseRow(index) : this.grid.expandRow(index);
    dataItem.isRowExpanded = !dataItem.isRowExpanded;
  }
  cancelEditRows() {
    // this.replaceWith.value = "";
    // this.searchFor.value = "";
    this.modifiedSignalParameters = [];
    this.getSignalParameters();
  }

  public rowCallback = (context: RowClassArgs) => {
    const isEven = context.index % 2 == 0;
    let result = { even: isEven, odd: !isEven };
    return result;
  }

  public showTooltip(e: MouseEvent): void {
    const element = e.target as HTMLElement;
    if ((element.nodeName === 'TD' || element.nodeName === 'TH') && element.offsetWidth < element.scrollWidth) {
      this.tooltipDir.toggle(element);
    } else {
      this.tooltipDir.hide();
    }
  }

  ngOnDestroy(): void {
    this.subject.next(null);
    this.subject.complete();
  }

  toggle() {
    this.collapsed = !this.collapsed;
  }

  // expand() {
  //   this.collapsed = false;
  // }

  // collapse() {
  //   this.collapsed = true;
  // }

  detectChanges() {
    this.changeDetectorRefs.detectChanges();
  }

  public allData() {
    const result = {
      data: this.selectedRowArray,
    };
    return result;
  }

  error(error: any) {
    //const title = this.messagesService.getErrorMessage(Number(error?.message));
    this.notificationService.error(error?.message);
  }

  //  isNameDup() {
  //   const ValidatorFn = (formArray: FormArray) => {
  //     const totalSelected = formArray.controls
  //       .map(control => control.value);
  //       const names = totalSelected.map(value=> value.username)
  //        const hasDuplicate = names.some(
  //     (name, index) => names.indexOf(name, index + 1) != -1
  //   );
  //      return  hasDuplicate ? { duplicate: true } : null;
  //   }
  //   return false;
  // }

}
