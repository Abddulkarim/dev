import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import { State } from '@progress/kendo-data-query';
import { DialogRef, DialogService } from '@progress/kendo-angular-dialog';
import { AddEvent, CancelEvent, DataBindingDirective, DataStateChangeEvent, EditEvent, GridComponent, GridDataResult, RemoveEvent, RowClassArgs, SaveEvent } from '@progress/kendo-angular-grid';
import { BehaviorSubject, Subject, takeUntil } from 'rxjs';
import { Warehouse, Evaluation, EvaluationVersion } from 'src/app/models/entities';
import { NotificationService } from 'src/app/services/notification.service';
import { ParameterService, EvaluationService, EvaluationVersionService, CategoryService } from 'src/app/services/resource.service';
import { TooltipDirective } from '@progress/kendo-angular-tooltip';
import * as EvaluationActions from '../../store/actions/evaluation.action';
import { HttpParams } from '@angular/common/http';
import { MessagesService } from 'src/app/services/messages.service';
import { DeleteInfoDialog } from 'src/app/shared/dialogs/delete-info-dialog/delete-info-dialog.component';
import Utils from 'src/app/shared/utils';
@Component({
  selector: 'app-evaluation',
  templateUrl: './evaluation.component.html',
  styleUrls: ['./evaluation.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class EvaluationComponent implements OnInit, OnDestroy {
  private subject: Subject<any> = new Subject();
  @ViewChild(GridComponent) grid: GridComponent;
  @ViewChild(TooltipDirective) public tooltipDir: TooltipDirective;
  @ViewChild(DataBindingDirective) dataBinding: DataBindingDirective;
  dataSourceNew: BehaviorSubject<GridDataResult | Evaluation[]> = new BehaviorSubject(null);
  formGroup: FormGroup;
  showCreateVersion: boolean = false;
  versionLinked: boolean = true;
  releaseDate: Date = new Date();
  major = 1;
  minor = 0;
  revesion = 0;
  loading = false;
  state: State = { skip: 0, take: 50, group: [], filter: { filters: [], logic: 'and' }, sort: [{ field: "name", dir: "asc" }], };
  categories: Warehouse[];
  constructor(
    private messagesService: MessagesService,
    private store: Store,
    private evaluationService: EvaluationService,
    private evaluationVersionService: EvaluationVersionService,
    private categoryService: CategoryService,
    private dialogService: DialogService,
    private notificationService: NotificationService,
    private parameterService: ParameterService,
    private changeDetectorRefs: ChangeDetectorRef,
  ) { }

  ngOnInit(): void {
    this.getEvaluations();
    this.categoryService.findAll().subscribe((data) => { this.categories = Utils.sort(data) });
  }

  dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.getEvaluations();
  }

  getEvaluations(): void {
    this.loading = true;
    const stateTemp = Object.assign({}, this.state) as State;
    stateTemp.group = [];
    this.evaluationService.findItemsByParamsDataSource(stateTemp, null).pipe(takeUntil(this.subject)).subscribe((data) => {
      //this.dataSourceNew = data.data.slice(0, 10);
      this.dataSourceNew.next(data);
      //this.dataBinding.skip=0;
      this.loading = false;
    });
  }

  //neuen Eintrag erstellen
  addHandler({ sender, dataItem, rowIndex }: AddEvent): void {
    this.formGroup = new FormGroup({
      name: new FormControl('', [Validators.required, Validators.minLength(4)]),
      description: new FormControl('', [Validators.required, Validators.minLength(4)]),
      warehouse: new FormControl(this.categories.find(element => element != undefined), [Validators.required]),
    });
    sender.addRow(this.formGroup);
  }

  //Einen (neuen) Eintrag erstellen/editieren
  public saveHandler({ sender, rowIndex, dataItem, isNew }: SaveEvent): void {
    //const evaluation: Evaluation = dataItem;
    const evaluation = Object.assign({}, dataItem) as Evaluation;
    evaluation.name = this.formGroup.get('name').value;
    evaluation.description = this.formGroup.get('description').value;
    if (isNew) {
      evaluation.versions = [];
      this.evaluationService.save(evaluation).pipe(takeUntil(this.subject)).subscribe({
        next: (evaluationData) => {
          const data = this.dataSourceNew.value as GridDataResult;
          data.data.unshift(evaluationData);
          this.dataSourceNew.next(data);
          this.changeDetectorRefs.detectChanges();
          this.notificationService.success(this.messagesService.getMessage());
          this.store.dispatch(EvaluationActions.addItemAction({ payload: Object.assign({}, evaluation) }));
        },
        error: (error) => {
          this.error(error);
        },
      });
    } else {
      evaluation.warehouse = this.formGroup.get('warehouse').value;
      this.evaluationService.update(evaluation.index, evaluation).pipe(takeUntil(this.subject)).subscribe({
        next: (evaluationData) => {
          dataItem.name = evaluationData.name;
          dataItem.description = evaluationData.description;
          dataItem.warehouse = evaluationData.warehouse;
          const data = this.dataSourceNew.value as GridDataResult;
          this.dataSourceNew.next(data);
          this.store.dispatch(EvaluationActions.updateItemAction({ payload: Object.assign({}, evaluation) }));
          this.notificationService.success(this.messagesService.getMessage());
        },
        error: (error) => {
          this.error(error);
        },
      });
    }
    sender.closeRow(rowIndex);

  }

  public editHandler({ sender, rowIndex, dataItem }: EditEvent): void {
    this.formGroup = new FormGroup({
      name: new FormControl(dataItem.name, [Validators.required, Validators.minLength(4)]),
      description: new FormControl(dataItem.description, [Validators.required, Validators.minLength(4)]),
      warehouse: new FormControl(dataItem.warehouse, [Validators.required]),
    });

    sender.editRow(rowIndex, this.formGroup);
  }

  //Einen Eintrag entfernen
  removeHandler({ sender, rowIndex, dataItem }: RemoveEvent) {
    const evaluation: Evaluation = dataItem;
    const dialogRef: DialogRef = this.dialogService.open({ content: DeleteInfoDialog });
    const dataInfo = dialogRef.content.instance as DeleteInfoDialog;
    dataInfo.data = evaluation.name;
    dialogRef.result.subscribe((dialogResult) => {
      if (dialogResult == 'Yes') {
        this.evaluationService.delete(evaluation.index).pipe(takeUntil(this.subject)).subscribe({
          next: (evaluationData) => {
            //this.getEvaluations();
            const data = this.dataSourceNew.value as GridDataResult;
            data.data.forEach((item, index) => {
              if (item.index === evaluation.index) { data.data.splice(index, 1); }
            });
            this.dataSourceNew.next(data);
            this.store.dispatch(EvaluationActions.deleteItemAction({ payload: evaluation }));
            this.notificationService.success(this.messagesService.getMessage());
          },
          error: (error) => {
            const params = new HttpParams().set('index', evaluation?.index);
            this.parameterService.findItemsByEvaluation(params).pipe(takeUntil(this.subject)).subscribe({
              next: (parameters) => {
              }
            });
            this.error(error);
          },
        });
      }
    });
  }

  public cancelHandler({ sender, rowIndex }: CancelEvent): void {
    sender.closeRow(rowIndex);
    this.formGroup = null;
  }

  /** Save the node to database */
  saveEvaluationVersion(evaluation: Evaluation) {
    let evaluationVersion: EvaluationVersion = { index: 0, versionMajor: this.major, versionMinor: this.minor, versionRevision: this.revesion, evaluation: null, date: this.releaseDate };
    evaluationVersion.evaluation = evaluation;
    this.evaluationVersionService.saveByParam(evaluationVersion, "copyAssignments", this.versionLinked).pipe(takeUntil(this.subject)).subscribe({
      next: (evaluationVersionData) => {
        evaluation.versions = [evaluationVersionData, ...evaluation.versions];
        const data = this.dataSourceNew.value as GridDataResult;
        //data.data.unshift(evaluation);
        this.dataSourceNew.next(data);
        this.store.dispatch(EvaluationActions.addItemAction({ payload: Object.assign({}, evaluation) }));
        this.notificationService.success(this.messagesService.getMessage());
        this.showCreateVersion = false;
      }, // nextHandler
      error: (error) => {
        this.error(error);
      }, // errorHandler
      complete: () => { }, // completeHandler
    });
  }

  // entfernet eine Auswertungsversion.
  deleteEvaluationVersion(evaluation: Evaluation, evaluationVersion: EvaluationVersion): void {
    const dialogRef: DialogRef = this.dialogService.open({ content: DeleteInfoDialog });
    const dataInfo = dialogRef.content.instance as DeleteInfoDialog;
    dataInfo.data = evaluationVersion.versionAuto;
    dialogRef.result.subscribe((dialogResult) => {
      if (dialogResult == 'Yes') {
        this.evaluationVersionService.delete(evaluationVersion.index).pipe(takeUntil(this.subject)).subscribe({
          next: () => {
            const data = this.dataSourceNew.value as GridDataResult;
            evaluation.versions = evaluation.versions.filter((u: EvaluationVersion) => u.index !== evaluationVersion.index);
            evaluation.versions = [...evaluation.versions];
            this.dataSourceNew.next(data);
            this.store.dispatch(EvaluationActions.updateItemAction({ payload: Object.assign({}, evaluation) }));
            this.notificationService.success(this.messagesService.getMessage());
            this.showCreateVersion = false;
          },
          error: (error) => {
            const params = new HttpParams().set('index', evaluationVersion?.index);
            this.parameterService.findItemsByEvaluationVersion(params).pipe(takeUntil(this.subject)).subscribe({
              next: (parameters) => {
              }
            });
            this.error(error);
          },
          complete: () => { },
        });
      }
    });
  }

  versionsDetail(index: number, evaluation: Evaluation) {
    this.expandRow(index, evaluation);
  }

  public expandRow(index: number, dataItem: any) {
    if (dataItem.isRowExpanded === undefined) {
      dataItem.isRowExpanded = false;
    }
    dataItem.isRowExpanded ? this.grid.collapseRow(index) : this.grid.expandRow(index);
    dataItem.isRowExpanded = !dataItem.isRowExpanded;
  }

  parseDate() {
    if (this.releaseDate === undefined || ("" + this.releaseDate).length === 0) {
      return 0;
    }
    return 1;
  } 

  public showTooltip(e: MouseEvent): void {
    const element = e.target as HTMLElement;
    if ((element.nodeName === 'TD' || element.nodeName === 'TH') && element.offsetWidth < element.scrollWidth) {
      this.tooltipDir.toggle(element);
    } else {
      this.tooltipDir.hide();
    }
  }

  public rowCallback = (context: RowClassArgs) => {
    const isEven = context.index % 2 == 0;
    return {
      even: isEven,
      odd: !isEven
    };
  }

  ngOnDestroy(): void {
    this.subject.next(null);
    this.subject.complete();
  }

  error(error: any) {
    //const title = this.messagesService.getErrorMessage(Number(error?.message));
    this.notificationService.error(error?.message);
  }

}
