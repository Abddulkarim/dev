import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-evaluations-route',
  templateUrl: './evaluations.component.html',
  styleUrls: ['./evaluations.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EvaluationsComponent implements OnInit {
  routes = [
    { link: 'evaluation', label: 'Auswertung' },
    { link: 'parameter', label: 'Parameter' },
  ];

  constructor(public router: Router) {}

  ngOnInit(): void {}

  public onTabSelect(e: any) {
    let route = this.routes[e.index];
    this.router.navigate(['evaluations/' + route.link]);
  }

  public isRouteSelected(route: string): boolean {
    return this.router.url.endsWith(route);
  }
}
