import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { State } from '@progress/kendo-data-query';
import { DataStateChangeEvent, GridComponent, GridDataResult, RowClassArgs } from '@progress/kendo-angular-grid';
import { BehaviorSubject, Subject, takeUntil } from 'rxjs';
import { CategoryService, EvaluationService } from 'src/app/services/resource.service';
import { Evaluation, Warehouse } from 'src/app/models/entities';
import * as EvaluationActions from '../../store/actions/evaluation.action';
import Utils from 'src/app/shared/utils';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-parameters',
  templateUrl: './parameters.component.html',
  styleUrls: ['./parameters.component.css']
})
export class ParametersComponent implements OnInit, OnDestroy {
  private subject: Subject<any> = new Subject();
  @ViewChild(GridComponent) grid: GridComponent;
  dataSourceNew: BehaviorSubject<GridDataResult> = new BehaviorSubject(null);
  loading = false;
  public state: State = { skip: 0, take: 50, group: [], filter: { filters: [], logic: "and" }, sort: [{ field: "name", dir: "asc" }], };
  categories: Warehouse[];
  constructor(
    private categoryService: CategoryService,
    private evaluationService: EvaluationService,
    private store: Store) { }

  ngOnInit(): void {
    this.getCategories();
    this.evaluationService.findAll().subscribe((data: Evaluation[]) => {this.store.dispatch(EvaluationActions.loadItemsAction({ payload: data }));});
    this.categoryService.findAll().subscribe((data) => { this.categories = Utils.sort(data) });
  }

  dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.getCategories();
  }

  getCategories(): void {
    this.loading = true;
    this.categoryService.findItemsByParamsDataSource(this.state, null).pipe(takeUntil(this.subject)).subscribe((data) => {
      this.dataSourceNew.next(data);
      this.loading = false;
    });
  }


  public expandRow(index: number, dataItem: any) {
    if (dataItem.isRowExpanded === undefined) {
      dataItem.isRowExpanded = false;
    }
    dataItem.isRowExpanded ? this.grid.collapseRow(index) : this.grid.expandRow(index);
    dataItem.isRowExpanded = !dataItem.isRowExpanded;
  }

  public rowCallback = (context: RowClassArgs) => {
    const isEven = context.index % 2 == 0;
    return { even: isEven, odd: !isEven };
  }

  ngOnDestroy(): void {
    this.subject.next(null);
    this.subject.complete();
  }

}
