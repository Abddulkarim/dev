import { Component, OnInit } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';
import { EvaluationVersion, Parameter } from 'src/app/models/entities';

@Component({
  selector: 'app-evaluations-detail',
  templateUrl: './evaluations-detail.component.html',
  styleUrls: ['./evaluations-detail.component.css']
})
export class EvaluationsDetailComponent implements OnInit {
  private subject: Subject<any> = new Subject();
  evaluationsSelectActive = new BehaviorSubject<boolean>(false);
  evaluationVersionData: EvaluationVersion[] = [];
  evaluations: { index: number; evaluation: string; versionAuto: string; }[] = [];
  constructor() { }

  ngOnInit(): void {
  }

  addEvaluations(parameter:Parameter){
    //this.parameter=parameter;
    this.evaluationsSelectActive.next(true) ;
    this.evaluationVersionData = parameter.evaluationVersions;
  }

  onVersionCheck(item: { version: EvaluationVersion, checked: boolean }[]): void {
    this.evaluationVersionData= [];
    item.forEach(data=> {data
     if(data.checked===true){
      this.evaluationVersionData.push(data.version);
    }
  })
  }

  public onCancelAction(): void {
    this.evaluationsSelectActive.next(false) ;
  }
  
  //speichert die Versionen einer Auswertung
  public onConfirmAction(): void {
    // this.parameter.evaluationVersions=this.evaluationVersionData;
    // this.parameterService.update(this.parameter.index, this.parameter).subscribe( {
    //   next: (parameterData) => {
    //     this.onCancelAction();
    //     this.parameter=parameterData;
    //     this.notificationService.success($localize`${env.success}`);
    //   },
    //   error: (error) => {
    //     this.notificationService.error($localize`${env.error}`);
    //   },
    // });
  }

  ngOnDestroy(): void {
    this.subject.next(null);
    this.subject.complete();
  }
  

}
