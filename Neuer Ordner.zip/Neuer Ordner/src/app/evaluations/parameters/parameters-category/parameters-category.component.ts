import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { DialogRef, DialogService } from '@progress/kendo-angular-dialog';
import { AddEvent, CancelEvent, DataStateChangeEvent, EditEvent, GridComponent, GridDataResult, RemoveEvent, RowClassArgs, SaveEvent } from '@progress/kendo-angular-grid';
import { State } from '@progress/kendo-data-query';
import { BehaviorSubject, Subject, takeUntil } from 'rxjs';
import { Warehouse, DataType, EvaluationVersion, Parameter, Resolution, Type, Unit, Evaluation } from 'src/app/models/entities';
import { NotificationService } from 'src/app/services/notification.service';
import { DataTypeService, ParameterService, ResolutionService, TypeService, UnitService } from 'src/app/services/resource.service';
import { TooltipDirective } from '@progress/kendo-angular-tooltip';
import { MessagesService } from 'src/app/services/messages.service';
import { DeleteInfoDialog } from 'src/app/shared/dialogs/delete-info-dialog/delete-info-dialog.component';
import Utils from 'src/app/shared/utils';
import { EvaluationsDialog } from 'src/app/shared/dialogs/evaluations-dialog/evaluations-dialog';


@Component({
  selector: 'app-parameters-category',
  templateUrl: './parameters-category.component.html',
  styleUrls: ['./parameters-category.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ParametersCategoryComponent implements OnInit, OnDestroy {
  private subject: Subject<any> = new Subject();
  @Input() public categoryData: Warehouse;
  @ViewChild(GridComponent) grid: GridComponent;
  @ViewChild(TooltipDirective) public tooltipDir: TooltipDirective;
  dataSourceNew: BehaviorSubject<GridDataResult | Parameter[]> = new BehaviorSubject(null);
  loading = false;
  //evaluationsSelectActive = new BehaviorSubject<boolean>(false);
  evaluationVersionData: EvaluationVersion[] = [];
  evaluations: Array<Evaluation>;
  categories: Warehouse[] = [];
  types: Type[] = [];
  dataTypes: DataType[] = [];
  units: Unit[] = [];
  resolutions: Resolution[] = [];
  formGroup: FormGroup;
  public state: State = { skip: 0, take: 50, group: [], filter: { filters: [], logic: "and" }, sort: [{ field: "name", dir: "asc" }], };
  constructor(
    private messagesService: MessagesService,
    private dialogService: DialogService,
    private resolutionService: ResolutionService,
    private unitService: UnitService,
    private dataTypeService: DataTypeService,
    private typeService: TypeService,
    private parameterService: ParameterService,
    private notificationService: NotificationService,
    private changeDetectorRefs: ChangeDetectorRef,) { }

  ngOnInit(): void {
    this.getParameters();
    this.resolutionService.findAll().subscribe((data) => { this.resolutions = Utils.sort(data) });
    this.unitService.findAll().subscribe((data) => { this.units = Utils.sort(data) });
    this.dataTypeService.findAll().subscribe((data) => { this.dataTypes = Utils.sort(data) });
    this.typeService.findAll().subscribe((data) => { this.types = Utils.sort(data) });
  }

  dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.getParameters();
  }

  getParameters(): void {
    this.loading = true;
    this.parameterService.findItemsByParamsDataSource(this.state, { categoryIndex: this.categoryData.index, }).pipe(takeUntil(this.subject)).subscribe((data) => {
      this.loading = false;
      this.dataSourceNew.next(data);
    });
  }

  //neuen Eintrag erstellen
  addHandler({ sender, dataItem, rowIndex }: AddEvent): void {
    this.formGroup = new FormGroup({
      name: new FormControl('', [Validators.required]),
      description: new FormControl('', [Validators.required, Validators.minLength(4)]),
      type: new FormControl(this.types.find(element => element != undefined), [Validators.required]),
      dataType: new FormControl(this.dataTypes.find(element => element != undefined), [Validators.required]),
      unit: new FormControl(this.units.find(element => element != undefined), [Validators.required]),
      resolution: new FormControl(this.resolutions.find(element => element != undefined), [Validators.required]),
      evaluationVersions: new FormControl([]),
    });
    sender.addRow(this.formGroup);
  }

  //Einen (neuen) Eintrag erstellen/editieren
  public saveHandler({ sender, rowIndex, dataItem, isNew }: SaveEvent): void {
    const parameter: Parameter = dataItem;
    parameter.name = this.formGroup.get('name').value;
    parameter.description = this.formGroup.get('description').value;
    if (isNew) {
      this.parameterService.saveByParam(parameter, "categoryIndex", this.categoryData.index).pipe(takeUntil(this.subject)).subscribe({
        next: (parameterData) => {
          const data = this.dataSourceNew.value as GridDataResult;
          data.data.unshift(parameterData);
          this.dataSourceNew.next(data);
          this.changeDetectorRefs.detectChanges();
          this.notificationService.success(this.messagesService.getMessage());
        },
        error: (error) => {
          this.error(error);
        },
      });
    } else {
      parameter.type = this.formGroup.get('type').value;
      parameter.dataType = this.formGroup.get('dataType').value;
      parameter.unit = this.formGroup.get('unit').value;
      parameter.resolution = this.formGroup.get('resolution').value;
      this.parameterService.update(dataItem.index, parameter).pipe(takeUntil(this.subject)).subscribe({
        next: (parameterData) => {
          this.changeDetectorRefs.detectChanges();
          this.notificationService.success(this.messagesService.getMessage());
        },
        error: (error) => {
          this.error(error);
        },
      });
    }
    sender.closeRow(rowIndex);
  }

  public editHandler({ sender, rowIndex, dataItem }: EditEvent): void {
    this.formGroup = new FormGroup({
      name: new FormControl(dataItem.name, [Validators.required, Validators.minLength(2)]),
      description: new FormControl(dataItem.description, [Validators.required, Validators.minLength(2)]),
      type: new FormControl(dataItem.type, [Validators.required]),
      dataType: new FormControl(dataItem.dataType, [Validators.required]),
      unit: new FormControl(dataItem.unit, [Validators.required]),
      resolution: new FormControl(dataItem.resolution, [Validators.required]),
    });
    sender.editRow(rowIndex, this.formGroup);
  }

  //Einen Eintrag entfernen
  removeHandler({ sender, rowIndex, dataItem }: RemoveEvent) {
    const parameter: Parameter = dataItem;
    const dialogRef: DialogRef = this.dialogService.open({ content: DeleteInfoDialog });
    const dataInfo = dialogRef.content.instance as DeleteInfoDialog;
    dataInfo.data = parameter;
    dialogRef.result.subscribe((dialogResult) => {
      if (dialogResult == 'Yes') {
        this.parameterService.delete(parameter.index).pipe(takeUntil(this.subject)).subscribe({
          next: () => {
            this.getParameters();
            this.notificationService.success(this.messagesService.getMessage());
          },
          error: (error) => {
            this.getParameters();
            this.error(error);
          },
        });
      }
    });
  }

  public cancelHandler({ sender, rowIndex, dataItem }: CancelEvent): void {
    sender.closeRow(rowIndex);
    this.formGroup = null;
  }

  evaluationTrackByFn = (index: number, item: any) => item.evaluation;
  getEvaluations(parameter: Parameter): { index: number; evaluation: string; versionAuto: string; }[] {
    const evaluations: { index: number; evaluation: string; versionAuto: string; }[] = [];
    parameter?.evaluationVersions?.forEach(ev => {
      if (evaluations.findIndex(i => i.index === ev.evaluationIndex) < 0) {
        const version = parameter.evaluationVersions.filter(i => i.evaluationIndex === ev.evaluationIndex).map(i => i.versionAuto).join('\n');
        evaluations.push({ index: ev.evaluationIndex, evaluation: ev.evaluationName, versionAuto: version });
      }
    });
    return evaluations;
  }

  addEvaluations(parameter: Parameter) {
    this.evaluationVersionData = parameter.evaluationVersions;
    const dialogRef: DialogRef = this.dialogService.open({ content: EvaluationsDialog });
    const dataInfo = dialogRef.content.instance as EvaluationsDialog;
      dataInfo.evaluationVersionData = this.evaluationVersionData;
      dialogRef.result.subscribe((dialogResult) => {
        if (dialogResult!=undefined && dialogResult!='Cancel') {
          parameter.evaluationVersions = dialogResult as EvaluationVersion[];
          this.parameterService.update(parameter.index, parameter).pipe(takeUntil(this.subject)).subscribe({
            next: (parameterData) => {
              //this.onCancelAction();
              parameter.evaluationVersions = parameterData.evaluationVersions;
              this.changeDetectorRefs.detectChanges();
              this.notificationService.success(this.messagesService.getMessage());
            },
            error: (error) => {
              this.error(error);
            },
          });
        }
      });
  }

  public expandRow(index: number, dataItem: any) {
    if (dataItem.isRowExpanded === undefined) {
      dataItem.isRowExpanded = false;
    }
    dataItem.isRowExpanded ? this.grid.collapseRow(index) : this.grid.expandRow(index);
    dataItem.isRowExpanded = !dataItem.isRowExpanded;
  }

  public rowCallback = (context: RowClassArgs) => {
    const isEven = context.index % 2 == 0;
    return {
      even: isEven,
      odd: !isEven
    };
  }

  public showTooltip(e: MouseEvent): void {
    const element = e.target as HTMLElement;
    if ((element.nodeName === 'TD' || element.nodeName === 'TH') && element.offsetWidth < element.scrollWidth) {
      this.tooltipDir.toggle(element);
    } else {
      this.tooltipDir.hide();
    }
  }

  ngOnDestroy(): void {
    this.subject.next(null);
    this.subject.complete();
  }

  error(error: any) {
    //const title = this.messagesService.getErrorMessage(Number(error?.message));
    this.notificationService.error(error?.message);
  }
}

