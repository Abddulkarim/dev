import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EvaluationsRoutingModule } from './evaluations-routing.module';
import { SharedModule } from '../shared/shared.module';
import { EvaluationsComponent } from './evaluations.component';
import { EvaluationComponent } from './evaluation/evaluation.component';
import { ParametersComponent } from './parameters/parameters.component';
import { registerLocaleData } from '@angular/common';
import { ParametersCategoryComponent } from './parameters/parameters-category/parameters-category.component';
import { EvaluationsDetailComponent } from './parameters/parameters-category/evaluations-detail/evaluations-detail.component';
import { DateInputsModule } from "@progress/kendo-angular-dateinputs";
import localeEn from '@angular/common/locales/en';
import localeDE from '@angular/common/locales/de'
import { SignalParameterDialog } from '../shared/dialogs/signal-parameter-dialog/signal-parameter-dialog';
import { EvaluationsDialog } from '../shared/dialogs/evaluations-dialog/evaluations-dialog';
import { DeleteInfoDialog } from '../shared/dialogs/delete-info-dialog/delete-info-dialog.component';
registerLocaleData(localeEn);
registerLocaleData(localeDE);

@NgModule({
  declarations: [
    EvaluationsComponent,
    EvaluationComponent,
    ParametersComponent,
    ParametersCategoryComponent,
    //QuicklinkCategorySearchDialog,
    SignalParameterDialog,
    EvaluationsDialog,
    DeleteInfoDialog,
    EvaluationsDetailComponent,
  ],

  imports: [
    CommonModule,
    DateInputsModule,
    EvaluationsRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    //OverlayModule,
  ],
  providers: [
      // { provide: IntlService,useExisting: CldrIntlService,},
      // {provide: IntlService,useExisting: CldrIntlService,},
      // {provide: LOCALE_ID,useValue: "en",},
  ],
})
export class EvaluationsModule {}
