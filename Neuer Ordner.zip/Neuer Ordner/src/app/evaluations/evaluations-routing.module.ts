import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { EvaluationsComponent } from './evaluations.component';
import { ParametersComponent } from './parameters/parameters.component';
import { EvaluationComponent } from './evaluation/evaluation.component';
import { AuthGuard } from '../services/authGuard';


const routes: Routes = [
  {
    path: '',component: EvaluationsComponent,
    children: [
      {path: '',redirectTo: 'evaluation',pathMatch: 'full'},
      {path: 'evaluation',component: EvaluationComponent,data: { title: 'de.router.auswertung' },canActivate:[AuthGuard]},
      {path: 'parameter',component: ParametersComponent,data: { title: 'de.router.parameter' },canActivate:[AuthGuard]},
    ]
  }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class EvaluationsRoutingModule {}
