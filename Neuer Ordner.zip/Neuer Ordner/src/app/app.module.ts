import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SharedModule } from './shared/shared.module';
//import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NavbarComponent } from './navbar/navbar.component';
import { HomeComponent } from './home/home.component';
import { StoreModule } from '@ngrx/store';
import { metaReducerLocalStorage, reducers } from './store/store';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { OAuthModule } from 'angular-oauth2-oidc';
import {registerLocaleData } from '@angular/common';
import { AboutComponent } from './about/about.component';
import "@progress/kendo-angular-intl/locales/en/all";
import "@progress/kendo-angular-intl/locales/fr/all";
import "@progress/kendo-angular-intl/locales/de/all";
import localeEn from '@angular/common/locales/en';
import localeDE from '@angular/common/locales/de';
import localeFR from '@angular/common/locales/fr';
import { P3Interceptor } from './interceptor';
registerLocaleData(localeEn);
registerLocaleData(localeDE);
registerLocaleData(localeFR);
@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    HomeComponent,
    AboutComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    //FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    //ReactiveFormsModule,
    SharedModule,
    StoreModule.forRoot(reducers, { metaReducers: [metaReducerLocalStorage] }),
    // EffectsModule.forRoot([TodosEffect])
    OAuthModule.forRoot(
      {
        resourceServer: {
          allowedUrls: ['https://vision.wurm.de:44126'],
          sendAccessToken: true,
        },
      }
    ),
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: P3Interceptor, multi: true },
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
