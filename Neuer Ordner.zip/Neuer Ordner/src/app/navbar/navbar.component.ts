
import { Component, OnInit} from "@angular/core";
import { Store } from '@ngrx/store';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { environment as env } from '../../environments/environment';
import { Language } from '../models/entities';
import { AuthService } from '../services/auth.service';
import * as LanguageActions from '../store/actions/language.action';
import { selectLanguageCode } from '../store/selectors/language.selector';
import { WebLanguageService } from "../services/webLanguageService";
//import { selectLanguageState, selectSettingsLanguage } from '../store/selector';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
})
export class NavbarComponent implements OnInit {
  public loggedIn: boolean = false;
  isProd = env.production;
  envName = env.envName;
  version = env.version;
  year = new Date().getFullYear();
  logo = env.logo;
  //logo = require('./assets/logo.png');
  languages: string[] = this.webLanguageService.getLanguages();
  currentLanguage: string = this.webLanguageService.getLanguage("en");
  private isAuthenticatedSubject$ = new BehaviorSubject<boolean>(false);
  public isAuthenticated$ = this.isAuthenticatedSubject$.asObservable();

  //currentLanguage$ = this.store.select(selectLanguageState);
  selectSettingsLanguage$: Observable<Language>;
  constructor(
    private store: Store,
    private authService: AuthService,
    private webLanguageService: WebLanguageService,
  ) { }
  ngOnInit(): void {
    this.authService.isAuthenticated$.subscribe(data => {
      this.isAuthenticatedSubject$.next(data);
    });
  }

  onLanguageSelect(language: string) {
    this.store.dispatch(LanguageActions.addLanguageAction({ payload: language }));
    window.location.href = `/${language}/`;
    //window.location.href = window.location.href + `/${currentLanguage}/`;

  }

  onLogin(): void {
    this.authService.login();
  }

  onLogout() {
    this.authService.logout();
    this.store.dispatch(LanguageActions.defaultLaguageAction());
  }
}
