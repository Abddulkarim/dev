import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
import { AuthGuard } from './services/authGuard';


const routes: Routes = [
  { path: '', component: HomeComponent, pathMatch: 'full' },
  { path: 'home', redirectTo: '', pathMatch: 'full' },
  { path: 'evaluations',loadChildren: () =>import('./evaluations/evaluations.module').then((m) => m.EvaluationsModule),canActivate:[AuthGuard]},
  { path: 'devices',loadChildren: () =>import('./devices/devices.module').then((m) => m.SchemeReleasesModule),canActivate:[AuthGuard]},
  { path: 'admin', loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule), canActivate:[AuthGuard] },
  { path: 'about', component: AboutComponent, pathMatch:'full', canActivate:[AuthGuard]},
];


@NgModule({
  imports: [
  //RouterModule.forRoot(routes)
  RouterModule.forRoot(routes,{ onSameUrlNavigation: 'reload',useHash: true})
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
