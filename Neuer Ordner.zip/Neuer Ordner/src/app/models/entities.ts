import { HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { QueryParams } from './query.model';

export interface Language {
  id: number;
  name: string;
}

//#############################
export interface User {
  id: number;
  username: string;
  email: string;
  password: string;
  roles: string[];
  clientId: string;
  userId: number;
  firstname: string;
  lastname: string;
  companyName: string;
  token: string;
}
//#############################
export interface Warehouse {
  index: number;
  name: string;
  parameters?: Parameter[];
  hasProject?:boolean,
  isExpanded?: boolean;
}

//#############################

export class Evaluation {
  index: number;
  name: string;
  description?: string;
  warehouse?:Warehouse;
  versions?: EvaluationVersion[];
}

//#############################
export interface EvaluationVersion{
  index: number;
  evaluationName?: string;
  evaluationDescription?:string;
  evaluationIndex?: number
  evaluation:Evaluation;
  versionMajor: number;
  versionMinor: number;
  versionRevision: number;
  versionAuto?: string;
  date:Date;

}

//#############################
export interface Parameter {
  index: number;
  name: string;
  description: string;
  type?: Type;
  dataType?: DataType;
  unit?: Unit;
  resolution?: Resolution;
  evaluationVersions?: EvaluationVersion[];
  ignore?:IgnoreParameter;
  ignoreParameterGroups?:ParameterGroup[];
}

//#############################
export class ParameterGroup {
  index: number;
  name: string;
  constructor(index: number, name: string) {
    this.index = index;
    this.name = name;
  }
}

//#############################
export interface SchemeRelease {
  index: number;
  versionMajor: number;
  versionMinor: number;
  versionRevision: number;
  versionAuto: string;
  date: Date;
  evaluable: number;
  qlFile?:boolean;
  device: Device;
  deviceIndex?:number;
  project?: Project;
  parameterGroup?:ParameterGroup;
  evaluationVersions?: EvaluationVersion[];
  //signalParameters?:SignalParameter[];
  isExpanded?: boolean;
}

//#############################
//  export class ParameterEvaluationVersion {
//    parameter: Parameter;
//    constructor(parameter: Parameter){
//    this.parameter=parameter;
//   }
// }

//#############################
export interface Project {
  index: number;
  projectId: string;
  projectName: string;
  deviceIndex?: number;
  schemeReleases?:SchemeRelease[];
  warehouses?: Warehouse[];
}
export class ProjectNa implements Project {
  #na = 'n/a';
  index = 0;
  projectId = this.#na;
  projectName = this.#na;
}
export class SignalParameterNa implements SignalParameter {
  #na = 'n/a';
  index?: number;
  schemeReleaseIndex?:number;
  qlMaingroupId?: number;
  qlGroup1Id?: number;
  qlGroup2Id?: number;
  qlParameterId?: number;
  quicklinkAuto?: string;
  parameter?:Parameter;
  parameterGroup?:ParameterGroup;
  isRowExpanded?:boolean;
  quickLinkExists?:any;
  signalClass?: number;
  signalUnit?: number;
  sprachDBIndex?: number;

}

//#############################
export interface SignalParameter {
  index?: number;
  schemeReleaseIndex?:number;
  qlMaingroupId?: number;
  qlGroup1Id?: number;
  qlGroup2Id?: number;
  qlParameterId?: number;
  quicklinkAuto?: string;
  parameter?:Parameter;
  parameterGroup?:ParameterGroup;
  isRowExpanded?:boolean;
  quickLinkExists?:any;
  signalClass?: number;
  signalUnit?: number;
  sprachDBIndex?: number;
}

//#############################
export interface Quicklink {
  index: number;
  text:string;
  mainGroupId: number;
  group1Id: number;
  group2Id: number;
  parameterId: number;
  quicklinkId: string;
  unit?: string;
  canOpenIndex?: number;
}
//#############################
export interface Type {
  index: number;
  name: string;
}
//#############################
export interface DataType {
  index: number;
  name: string;
}
//#############################
export interface Unit {
  index: number;
  name: string;
}
//#############################
export interface Resolution {
  index: number;
  name: string;
}
//#############################
export interface Device {
  index: number;
  type: number;
  name: string;
  isVisulink:boolean;
  warehouses?: Warehouse[];
  rowIndex?:number;
}

//#############################
export interface ReleaseType {
  index: number;
  name: string;
}

export class QuicklinkParamGroupData {
  quicklink: Quicklink;
  parameterGroup: string;
  constructor(quicklink: Quicklink, parameterGroup: string) {
    this.quicklink = quicklink;
    this.parameterGroup = parameterGroup;
  }
}
//#############################
export interface CrudOperations<T, INDEX> {
  save(t: T): Observable<T>;
  //create1(index: INDEX, enity: T): Observable<T>;
  saveByParam(enity: T,property:string,value:any): Observable<T>;
  saveByParams(enity: T,params:HttpParams): Observable<T>;
  saveList(list: T[],params:HttpParams): Observable<T[]> 
  saveOrUpdateFile(index: INDEX, file:T): Observable<T>;
  update(index: INDEX, t: T): Observable<T>;
  findOne(index: INDEX): Observable<T>;
  findAll(): Observable<T[]>;
  delete(index: INDEX): Observable<any>;
  //findItemsByParam(index: INDEX, property:string):Observable<T[]>;
  findItemsByParams(map:Map<string,number>,queryParams?: QueryParams):Observable<T[]>;
  findFileBySchemerelease(index: INDEX): Observable<string>;
  //findItemsByCategoryIndex(index: INDEX):Observable<T[]>;
  //findItemsByEvaluation(index: INDEX):Observable<T[]>;
  //findItemsByCategoryAndSchemeRelease(categoryIndex: INDEX,schemeReleaseIndex: INDEX):Observable<T[]>;
  //findItemsByCategoryAndEvaluation(categoryIndex: INDEX, evaluationIndex: INDEX): Observable<T[]>;
}

export class Person {
  private _age: number;
  private _firstName: string;
  private _lastName: string;

  public get age() {
    return this._age;
  }

  public set age(theAge: number) {
    if (theAge <= 0 || theAge >= 200) {
      throw new Error('The age is invalid');
    }
    this._age = theAge;
  }

  public getFullName(): string {
    return `${this._firstName} ${this._lastName}`;
  }
}

export interface Statistics {
  index?: number;
  value: number;
  name: string;
}

export class StatisticsNa implements Statistics {
  #na = 'n/a';
  index = 0;
  value = 0;
  name = this.#na;
}
export class QuicklinkNa implements Quicklink {
  #na = 'n/a';
  index = 0;
  text="";
  mainGroupId=0;
  group1Id=0;
  group2Id=0;
  parameterId=0;
  quicklinkId="";
}

export enum IgnoreParameter {
  NONE = "NONE",
  SCHEMERELEASE = "SCHEMERELEASE",
  PRARAMTERGROUP = "PARAMETERGROUP"
}