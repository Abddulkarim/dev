import { FormGroup } from "@angular/forms";
import { EditEvent, GridComponent, SaveEvent } from "@progress/kendo-angular-grid";

export class EditEventImp implements EditEvent {
  dataItem: any;
  isNew: boolean;
  rowIndex: number;
  sender: GridComponent;
  constructor(dataItem: any, isNew: boolean, rowIndex: number, sender: GridComponent) {
    this.dataItem = dataItem, this.isNew = isNew, this.rowIndex = rowIndex, this.sender = sender
  }

}

export class SaveEventImp implements SaveEvent {
  dataItem: any;
  isNew: boolean;
  rowIndex: number;
  sender: GridComponent;
  formGroup: FormGroup;
  constructor(dataItem: any, isNew: boolean, rowIndex: number, sender: GridComponent) {
    this.dataItem = dataItem, this.isNew = isNew, this.rowIndex = rowIndex, this.sender = sender
  }

}