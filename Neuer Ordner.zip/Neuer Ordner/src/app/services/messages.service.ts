import { MessageService } from '@progress/kendo-angular-l10n';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class MessagesService extends MessageService {
  value: string;
  public getErrorMessage(key: number): string {
    switch (key) {
      case 1:
        this.value = $localize`Das Objekt hat noch Verknüpfungen!`;
        break;
      case 2:
        this.value = $localize`Dieser Name ist bereits vergeben!`;
        break;
      case 3:
        this.value = $localize`Das Objekt existiert bereits!`;
        break;
      case 4:
        this.value = $localize`Das Objekt wurde nicht gefunden.`;
        break;
      case 5:
        this.value = $localize`Bitte einen gültigen Wert angeben!`;
        break;
      default:
        this.value = $localize`Der Prozess wurde unerwartet beendet.`;
        break;
    }
    return this.value;
  }
  public getMessage(): string {
    let value = $localize`Der Prozess wurde erfolgreich durchgeführt.`;
    return value;
  }
}
