import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CurrentDeviceService {
  value:number = 0;
  deviceValue: BehaviorSubject<number>;
  constructor() {

    this.deviceValue  = new BehaviorSubject(this.value);
  }

  nextValue(data:number) {
    this.deviceValue.next(data);
  }
}
