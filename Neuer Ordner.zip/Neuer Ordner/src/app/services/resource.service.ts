import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { GridDataResult } from '@progress/kendo-angular-grid';
import { DataSourceRequestState, State } from '@progress/kendo-data-query';
import { Observable } from 'rxjs';

import { Evaluation, Warehouse, Parameter, Unit ,Type, DataType,Resolution, SchemeRelease, Device, EvaluationVersion, SignalParameter, Project, ParameterGroup} from '../models/entities';
import { CrudService } from './crud.service';
import { Constants } from '../shared/constants';


@Injectable({providedIn: 'root',})
export class CategoryService extends CrudService<Warehouse, number> {
  constructor(private http: HttpClient) {
    super(http, `${Constants.API_WAREHOUSES}`,`${Constants.API_WAREHOUSE}`);
  }
}

@Injectable({providedIn: 'root',})
export class EvaluationService extends CrudService<Evaluation, number> {
  constructor(private http: HttpClient) {
    super(http, `${Constants.API_EVALUATIONS}`,`${Constants.API_EVALUATION}`);
  }
}

@Injectable({providedIn: 'root',})
export class EvaluationVersionService extends CrudService<EvaluationVersion, number> {
  constructor(private http: HttpClient) {
    super(http, `${Constants.API_EVALUATION_VERSIONS}`,`${Constants.API_EVALUATION_VERSION}`);
  }
}

@Injectable({providedIn: 'root',})
export class ParameterService extends CrudService<Parameter, number> {
  constructor(private http: HttpClient) {
    super(http, `${Constants.API_PARAMETERS}`,`${Constants.API_PARAMETER}`);
  }

  findItemsByEvaluation(params:HttpParams): Observable<Parameter[]> {
    return this.http.get<Parameter[]>(Constants.API_PARAMETERS_BY_EVALUATION,{ params: params});
  }

  findItemsByEvaluationVersion(params:HttpParams): Observable<Parameter[]> {
    return this.http.get<Parameter[]>(Constants.API_PARAMETERS_BY_EVALUATION_VERSION,{ params: params});
  }
}

@Injectable({providedIn: 'root',})
export class SignalParameterService extends CrudService<SignalParameter, number> {
  constructor(private http: HttpClient) {
    super(http, `${Constants.API_SIGNAL_PARAMETERS}`,`${Constants.API_SIGNAL_PARAMETER}`);
  }

  findAssignableParameters(state: DataSourceRequestState, index: number,params: { onlyAssigned: boolean; parameterGroupIndex?: number; evaluationIndex?: number; categoryIndex?: any }): Observable<GridDataResult> {
    return super.findItemsByParamsDataSource(state, params, Constants.API_SCHEMA_RELEASE_BASE+`/${index}/signalparameters`);
  }
  deleteList(list: SignalParameter[]): Observable<SignalParameter[]> {
    const indexes = list.map(i => i.index).join(',');
    return this._http.delete<SignalParameter[]>(Constants.API_SIGNAL_PARAMETERS + `/${indexes}`);
  }

}



@Injectable({providedIn: 'root',})
export class TypeService extends CrudService<Type, number> {
  constructor(private http: HttpClient) {
    super(http, `${Constants.API_TYPES}`, `${Constants.API_TYPE}`);
  }
}

@Injectable({providedIn: 'root',})
export class DataTypeService extends CrudService<DataType, number> {
  constructor(private http: HttpClient) {
    super(http, `${Constants.API_DATATYPES}`,`${Constants.API_DATATYPE}`);
  }
}

@Injectable({providedIn: 'root',})
export class UnitService extends CrudService<Unit, number> {
  constructor(private http: HttpClient) {
    super(http, `${Constants.API_UNITS}`,`${Constants.API_UNIT}`);
  }
}

@Injectable({providedIn: 'root',})
export class ResolutionService extends CrudService<Resolution, number> {
  constructor(private http: HttpClient) {
    super(http, `${Constants.API_RESOLUTIONS}`,`${Constants.API_RESOLUTION}`);
  }
}

@Injectable({providedIn: 'root',})
export class SchemeReleaseService extends CrudService<SchemeRelease, number> {
  constructor(private http: HttpClient) {
    super(http, `${Constants.API_SCHEME_RELEASES}`,`${Constants.API_SCHEME_RELEASE}`);
  }
  findSignalParametersBySchemeRelease(index: number): Observable<SignalParameter[]> {
    return this._http.get<SignalParameter[]>(this.baseURL+`/${index}/`+Constants.API_SCHEME_RELEASES_SIGNAL_PARAMETERS);
  }

  findParameterGroupsBySchemeRelease(index: number): Observable<ParameterGroup[]> {
    return this._http.get<ParameterGroup[]>(this.baseURL+`/${index}/`+Constants.API_SCHEME_RELEASES_PARAMETERGROUPS);
  }

  saveSignalParameter(index:number,enity: SignalParameter,params:HttpParams): Observable<SignalParameter> {
    return this._http.post<SignalParameter>(this.baseURL+`/${index}/`+Constants.API_SCHEME_RELEASES_SIGNAL_PARAMETER, enity,{ params: params});
  }

  updateSignalParameter(index:number,enity: SignalParameter): Observable<SignalParameter> {
    return this._http.put<SignalParameter>(this.baseURL+`/${index}/`+Constants.API_SCHEME_RELEASES_SIGNAL_PARAMETER, enity);
  }

  saveParametergroupsWithContents(index:number,list: ParameterGroup[],params:HttpParams): Observable<ParameterGroup[]> {
    return this._http.post<ParameterGroup[]>(this.baseURL+`/${index}/`+Constants.API_SCHEME_RELEASES_PARAMETERGROUPS,{ params: params});
  }

  cloneSignalParameter(index:number,list: SignalParameter[],params:HttpParams): Observable<SignalParameter[]> {
    return this._http.post<SignalParameter[]>(this.baseURL+`/${index}/`+Constants.API_SCHEME_RELEASES_SIGNAL_PARAMETERS, list,{ params: params});
  }

  copySignalParameterFrom(index:number,fromIndex:number): Observable<SignalParameter[]> {
    return this._http.post<SignalParameter[]>(this.baseURL+`/${index}/`+Constants.API_SCHEME_RELEASES_SIGNAL_PARAMETERS+`/${fromIndex}`,{});
  }
  
  ignoreParameterInRelease(index:number,list: SignalParameter[],params:HttpParams): Observable<SignalParameter[]> {
    return this._http.post<SignalParameter[]>(Constants.API_PARAMETER_IGNORE+`/${index}/`+Constants.PARAMETERS+`/${Constants.IGNORE}`,list,{ params: params});
  }
  
  ignoreParameterInGroups(index:number,list: SignalParameter[],params:HttpParams): Observable<SignalParameter[]> {
    return this._http.post<SignalParameter[]>(Constants.API_PARAMETER_IGNORE+`/${index}/`+Constants.PARAMETERS+`/${Constants.PARAMETERGROUP}/${Constants.IGNORE}`,list,{ params: params});
  }
}
@Injectable({providedIn: 'root',})
export class DeviceService extends CrudService<Device, number> {
  constructor(private http: HttpClient) {
    super(http, `${Constants.API_DEVICES}`,`${Constants.API_DEVICE}`);
  }
}
@Injectable({providedIn: 'root',})
export class ProjectService extends CrudService<Project, number> {
  constructor(private http: HttpClient) {
    super(http, `${Constants.API_PROJECTS}`,`${Constants.API_PROJECT}`);
  }
}

@Injectable({providedIn: 'root',})
export class ParameterGroupService extends CrudService<ParameterGroup, number> {
  constructor(private http: HttpClient) {
    super(http, `${Constants.API_PARAMETERGROUPS}`,`${Constants.API_PARAMETERGROUP}`);
  }
}