import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Inject } from '@angular/core';
import { GridDataResult } from '@progress/kendo-angular-grid';
import { DataSourceRequestState, toDataSourceRequestString, translateDataSourceResultGroups } from '@progress/kendo-data-query';
import { map, Observable } from 'rxjs';
import { CrudOperations } from '../models/entities';
import { QueryParams } from '../models/query.model';
import { Constants } from '../shared/constants';

const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'application/json'})
}
export abstract class CrudService<Enity, INDEX> implements CrudOperations<Enity, INDEX> {

  constructor(protected _http: HttpClient, @Inject(String) protected baseURLs: string,@Inject(String) protected baseURL: string) {}

  save(enity: Enity): Observable<Enity> {
    return this._http.post<Enity>(this.baseURL, enity,httpOptions);
  }

  findOne(index: INDEX): Observable<Enity> {
    return this._http.get<Enity>(this.baseURL+ `/${index}`);
  }

  update(index: INDEX, enity: Enity): Observable<Enity> {
    return this._http.put<Enity>(this.baseURL+`/${index}`, enity,httpOptions);
  }

  delete(index: INDEX): Observable<Enity> {
    return this._http.delete<Enity>(this.baseURL + `/${index}`);
  }

  findAll(): Observable<Enity[]> {
    return this._http.get<Enity[]>(this.baseURLs);
  }

  saveByParam(enity: Enity,property:string,value:any): Observable<Enity> {
    const params = new HttpParams().set(property, value);
    return this._http.post<Enity>(this.baseURL, enity,{ params: params});
  }
  
  saveByParams(enity: Enity,params:HttpParams): Observable<Enity> {
    return this._http.post<Enity>(this.baseURL, enity,{ params: params});
  }

  saveList(list: Enity[],params:HttpParams): Observable<Enity[]> {
    return this._http.post<Enity[]>(this.baseURLs, list,{ params: params});
  }

  saveListUpdate(list: Enity[]): Observable<Enity[]> {
    return this._http.put<Enity[]>(this.baseURLs, list,httpOptions);
  }

  saveOrUpdateFile(index: INDEX,file: Enity): Observable<Enity> {
    return this._http.post<Enity>(Constants.API_SCHEME_RELEASE+`/${index}/`+Constants.API_SCHEME_RELEASE_QL_FILE, file);
  }

  findFileBySchemerelease(index: INDEX): Observable<string> {
    return this._http.get<string>(Constants.API_SCHEME_RELEASE+`/${index}/`+Constants.API_SCHEME_RELEASE_QL_FILE);
  }

  findItemsByParams(map:Map<string,number>,queryParams?: QueryParams): Observable<Enity[]> {
    let params =this.createQueryHttpParams(queryParams) ;
    map.forEach((value: number, key: string) => {params = params.append(key, value);});
    return this._http.get<Enity[]>(this.baseURLs,{ params: params});
  }

  findItemsByParamsDataSource(state: DataSourceRequestState, params: { [x: string]: string | number | boolean } = undefined, url: string = undefined): Observable<GridDataResult> {
    let httpParams: HttpParams = new HttpParams();

    if (params != null) {
      Object.keys(params).forEach(key => {
        httpParams = httpParams.append(key, params[key]);
      });
    }

    url = url != null ? url : this.baseURLs;

    return this.createDataSourceRequest(url, state, httpParams);
  }

  protected createDataSourceRequest(url: string, state: DataSourceRequestState, params: HttpParams = null): Observable<GridDataResult> {
    const queryStr = `${toDataSourceRequestString(state)}`;
    const hasGroups = state.group && state.group.length;

    return this._http.get<GridDataResult>(`${url}?dataSourceRequest=true&${queryStr}`, { params: params }).pipe(
      map(({ data, total }: GridDataResult): GridDataResult => {
        return {
          data: hasGroups ? translateDataSourceResultGroups(data) : data,
          total: total,
        };
      })
    );
  }

  protected createQueryHttpParams(queryParams: QueryParams): HttpParams {
    const queryResult = this.createQueryParams(queryParams);

    let result: HttpParams = new HttpParams();

    queryResult.forEach(i => {
      result = result.append(i.key, i.value);
    });

    return result;
  }

  protected createQueryParams(queryParams: QueryParams): { key: string; value: string }[] {
    const result: { key: string; value: string }[] = [];

    queryParams?.filter?.forEach(i => {
      result.push(...[
        { key: 'filter.field', value: i.field },
        { key: 'filter.operator', value: i.operator.toString() },
        { key: 'filter.value', value: i.value?.toString() },
      ]);
    });

    if (queryParams?.take != null) {
      result.push({ key: 'take', value: queryParams.take.toString() });
    }

    if (queryParams?.skip != null) {
      result.push({ key: 'skip', value: queryParams.skip.toString() });
    }

    return result;
  }
}