import { Injectable } from '@angular/core';
import { NotificationService as NotificationKendoService} from '@progress/kendo-angular-notification';
@Injectable({
  providedIn: 'root'
})
export class NotificationService {
  public durationIn = 200;
  public durationOut = 800;
  constructor(private notificationService:NotificationKendoService) {}


  default(message: string) {
  }

  info(message: string) {
    this.notificationService.show({
      content: 'Info',
      position: { horizontal: 'center', vertical: 'top' },
      animation: { type: 'fade', duration: this.durationIn },
      type: { style: 'info', icon: true },
      hideAfter: this.durationOut,
    });
  }

  success(message: string) {
    this.notificationService.show({
      content: 'Der Prozess wurde erfolgreich durchgeführt',
      position: { horizontal: 'center', vertical: 'top' },
      animation: { type: 'fade', duration: this.durationIn },
      type: { style: 'success', icon: true },
      hideAfter: this.durationOut,
    });
  }

  warn(message: string) { 
    this.notificationService.show({
      content: 'warn',
      position: { horizontal: 'center', vertical: 'top' },
      animation: { type: 'fade', duration: 800 },
      type: { style: 'warning', icon: true },
      closable: true,
    });
  }

  error(message: any='Der Prozess wurde unerwartet beendet') {
    if(message===undefined||message===null||message.length===0||message === '[object Object]'){
       message='Der Prozess wurde unerwartet beendet';
      }
    const notifInstance =this.notificationService.show({
      content: message,
      position: { horizontal: 'center', vertical: 'top' },
      animation: { type: 'fade', duration: this.durationIn },
      type: { style: 'error', icon: true },
      closable: true,
    });
    setTimeout(() => {
      if (notifInstance) {
          notifInstance.hide();
      }
  }, 3000);
  }
}
