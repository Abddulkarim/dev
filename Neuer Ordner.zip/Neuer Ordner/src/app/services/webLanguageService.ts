import { Injectable } from '@angular/core';


@Injectable({ providedIn: 'root' })
export class WebLanguageService {
  readonly SUPPORTED_LANGUAGES: string[] = ['de', 'en'];
  constructor() {
  }

  getLanguage(defaultLanguage: string): string {
    const deviceLanguage = window?.navigator.language?.substring(0, 2) as string;
    const currentLanguage = window.location.pathname.split('/')[1];
    if (currentLanguage && this.SUPPORTED_LANGUAGES.includes(currentLanguage)) {
      return currentLanguage;
    } else {
      return this.SUPPORTED_LANGUAGES.includes(deviceLanguage) ? deviceLanguage : defaultLanguage;
    }
  }

  getLanguages(): string[] {
    return this.SUPPORTED_LANGUAGES;
  }
}